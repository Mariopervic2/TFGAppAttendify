package menusPrincipales;

import menuAsistencias.controlador.MenuAsistenciasControladorEmpleados;
import menuInformes.vista.MenuInformesEmpleadoVista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import menuVacaciones.controlador.EmpleadoMenuVacacionesControlador;
import modelo.UsuarioDTO;
import varios.GestorIdioma;

public class MenuPrincipalEmpleadoVista extends JFrame {

    private UsuarioDTO usuarioActual;
    private JPanel panelPrincipal;
    private JPanel panelBotones;
    private JPanel panelSuperior;
    private JLabel lblBienvenida;
    private JButton btnIdioma;
    private List<JPanel> panelesBotones;
    private JButton btnSalir;

    private static final String KEY_BIENVENIDA = "BIENVENIDA_EMPLEADO";
    private static final String KEY_MENU_ASISTENCIAS = "MENU_ASISTENCIAS";
    private static final String KEY_MENU_INFORMES = "MENU_INFORMES";
    private static final String KEY_MENU_VACACIONES = "MENU_VACACIONES";
    private static final String KEY_CAMBIAR_IDIOMA = "CAMBIAR_IDIOMA";
    private static final String KEY_SALIR = "SALIR";

    public MenuPrincipalEmpleadoVista(UsuarioDTO usuario) {
        this.usuarioActual = usuario;
        initComponents();
        actualizarTextos();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        setTitle("Sistema de Control de Asistencia - Empleado");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(new EmptyBorder(20, 20, 20, 20));
        panelPrincipal.setBackground(new Color(240, 240, 240));

        panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(new Color(0, 102, 204));
        panelSuperior.setBorder(new EmptyBorder(10, 10, 10, 10));

        lblBienvenida = new JLabel();
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 18));
        lblBienvenida.setForeground(Color.WHITE);
        lblBienvenida.setText("Bienvenido, " + usuarioActual.getNombreEmpleado());

        btnIdioma = new JButton(GestorIdioma.getString(KEY_CAMBIAR_IDIOMA));
        btnIdioma.setBackground(new Color(255, 255, 255));
        btnIdioma.setForeground(new Color(0, 102, 204));
        btnIdioma.setFont(new Font("Arial", Font.BOLD, 14));
        btnIdioma.setFocusPainted(false);
        btnIdioma.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        ImageIcon iconoIdioma = new ImageIcon(getClass().getResource("/imagenes/idioma.jpg"));
        if (iconoIdioma.getIconWidth() > 0) {
            Image img = iconoIdioma.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            btnIdioma.setIcon(new ImageIcon(img));
        }
        btnIdioma.addActionListener(e -> cambiarIdioma());

        panelSuperior.add(lblBienvenida, BorderLayout.WEST);
        panelSuperior.add(btnIdioma, BorderLayout.EAST);

        panelBotones = new JPanel(new GridLayout(1, 3, 30, 30));
        panelBotones.setBackground(new Color(240, 240, 240));
        panelBotones.setBorder(new EmptyBorder(30, 30, 30, 30));
        panelesBotones = new ArrayList<>();

        crearBotonMenu("/imagenes/asistencias.png", KEY_MENU_ASISTENCIAS, e -> abrirMenuAsistencias());
        crearBotonMenu("/imagenes/informes.png", KEY_MENU_INFORMES, e -> abrirMenuInformes());
        crearBotonMenu("/imagenes/vacaciones.png", KEY_MENU_VACACIONES, e -> abrirMenuVacaciones());

        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelInferior.setBackground(new Color(240, 240, 240));

        btnSalir = new JButton(GestorIdioma.getString(KEY_SALIR));
        btnSalir.setBackground(new Color(204, 0, 0));
        btnSalir.setForeground(Color.BLACK);
        btnSalir.setFont(new Font("Arial", Font.BOLD, 14));
        btnSalir.setFocusPainted(false);
        btnSalir.addActionListener(e -> cerrarSesion());
        btnSalir.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(150, 0, 0), 1),
                BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        panelInferior.add(btnSalir);

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    private void crearBotonMenu(String rutaImagen, String textoKey, ActionListener action) {
        JPanel panelBoton = new JPanel(new BorderLayout(10, 10));
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));

        JLabel lblIcono = new JLabel();
        lblIcono.setHorizontalAlignment(SwingConstants.CENTER);
        lblIcono.setBorder(new EmptyBorder(15, 15, 5, 15));

        ImageIcon icono = new ImageIcon(getClass().getResource(rutaImagen));
        if (icono.getIconWidth() > 0) {
            Image img = icono.getImage().getScaledInstance(220, 220, Image.SCALE_SMOOTH);
            lblIcono.setIcon(new ImageIcon(img));
        } else {
            lblIcono.setText("Imagen no disponible");
        }

        JLabel lblTexto = new JLabel(GestorIdioma.getString(textoKey));
        lblTexto.setHorizontalAlignment(SwingConstants.CENTER);
        lblTexto.setFont(new Font("Arial", Font.BOLD, 16));
        lblTexto.setBorder(new EmptyBorder(5, 5, 15, 5));

        panelBoton.add(lblIcono, BorderLayout.CENTER);
        panelBoton.add(lblTexto, BorderLayout.SOUTH);

        panelBoton.setPreferredSize(new Dimension(280, 280));

        panelBoton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                panelBoton.setBackground(new Color(230, 240, 255));
                panelBoton.setBorder(BorderFactory.createLineBorder(new Color(100, 150, 255), 2));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                panelBoton.setBackground(Color.WHITE);
                panelBoton.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                action.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
            }
        });

        panelesBotones.add(panelBoton);
        panelBotones.add(panelBoton);
    }

    private void actualizarTextos() {
        setTitle(GestorIdioma.getString("TITULO_EMPLEADO"));
        lblBienvenida.setText(GestorIdioma.getString(KEY_BIENVENIDA) + " " + usuarioActual.getNombreEmpleado());
        if (panelesBotones.size() >= 3) {
            ((JLabel) panelesBotones.get(0).getComponent(1)).setText(GestorIdioma.getString(KEY_MENU_ASISTENCIAS));
            ((JLabel) panelesBotones.get(1).getComponent(1)).setText(GestorIdioma.getString(KEY_MENU_INFORMES));
            ((JLabel) panelesBotones.get(2).getComponent(1)).setText(GestorIdioma.getString(KEY_MENU_VACACIONES));
        }
        btnIdioma.setText(GestorIdioma.getString(KEY_CAMBIAR_IDIOMA));
        btnSalir.setText(GestorIdioma.getString(KEY_SALIR));
    }

    private void cambiarIdioma() {
        String[] opciones = {
                GestorIdioma.getString("SPANISH"),
                GestorIdioma.getString("ENGLISH")
        };
        int seleccion = JOptionPane.showOptionDialog(
                this,
                GestorIdioma.getString("SELECCIONA_EL_IDIOMA"),
                GestorIdioma.getString("CAMBIAR_IDIOMA"),
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );
        if (seleccion == 0) {
            GestorIdioma.cambiarIdioma("es", "ES");
            JOptionPane.showMessageDialog(this, "Se ha cambiado el idioma a Español");
        } else if (seleccion == 1) {
            GestorIdioma.cambiarIdioma("en", "US");
            JOptionPane.showMessageDialog(this, "Language changed to English");
        }
        actualizarTextos();
    }

    private void cerrarSesion() {
        dispose();
        java.awt.EventQueue.invokeLater(() -> new login.vista.LoginVista().setVisible(true));
    }

    private void abrirMenuAsistencias() {
        MenuAsistenciasControladorEmpleados.mostrarVentana(usuarioActual);

    }

    private void abrirMenuInformes() {
        MenuInformesEmpleadoVista vistaInformes = new MenuInformesEmpleadoVista(usuarioActual);
        vistaInformes.setVisible(true);
    }

    private void abrirMenuVacaciones() {
        new EmpleadoMenuVacacionesControlador(usuarioActual);
    }
}