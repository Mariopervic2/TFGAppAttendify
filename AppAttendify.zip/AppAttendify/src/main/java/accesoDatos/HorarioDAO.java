package accesoDatos;

import modelo.HorarioDTO;
import modelo.HorarioDiaTrabajoDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HorarioDAO {
    private Connection conexion;
    private HorarioDiaTrabajoDAO horarioDiaTrabajoDAO;

    public HorarioDAO(Connection conexion) {
        this.conexion = conexion;
        this.horarioDiaTrabajoDAO = new HorarioDiaTrabajoDAO(conexion);
    }

    public List<HorarioDTO> obtenerTodosHorarios() throws SQLException {
        List<HorarioDTO> horarios = new ArrayList<>();
        String sql = "SELECT idHorario, nombreHorario, horasMaxSemanales FROM Horario";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                HorarioDTO horario = new HorarioDTO();
                horario.setIdHorario(rs.getInt("idHorario"));
                horario.setNombreHorario(rs.getString("nombreHorario"));
                horario.setHorasMaxSemanales(rs.getInt("horasMaxSemanales"));

                List<HorarioDiaTrabajoDTO> diasTrabajo = horarioDiaTrabajoDAO.obtenerDiasTrabajoPorHorario(horario.getIdHorario());
                horario.setDiasTrabajo(diasTrabajo);

                horarios.add(horario);
            }
        }
        return horarios;
    }

    public HorarioDTO obtenerHorarioPorId(int idHorario) throws SQLException {
        String sql = "SELECT idHorario, nombreHorario, horasMaxSemanales FROM Horario WHERE idHorario = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idHorario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    HorarioDTO horario = new HorarioDTO();
                    horario.setIdHorario(rs.getInt("idHorario"));
                    horario.setNombreHorario(rs.getString("nombreHorario"));
                    horario.setHorasMaxSemanales(rs.getInt("horasMaxSemanales"));

                    List<HorarioDiaTrabajoDTO> diasTrabajo = horarioDiaTrabajoDAO.obtenerDiasTrabajoPorHorario(horario.getIdHorario());
                    horario.setDiasTrabajo(diasTrabajo);
                    return horario;
                }
            }
        }
        return null;
    }

    public boolean crearHorario(HorarioDTO horario) throws SQLException {
        String sql = "INSERT INTO Horario (nombreHorario, horasMaxSemanales) VALUES (?, ?)";
        conexion.setAutoCommit(false);
        try (PreparedStatement stmt = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, horario.getNombreHorario());
            stmt.setInt(2, horario.getHorasMaxSemanales());

            int filas = stmt.executeUpdate();
            if (filas == 0) {
                conexion.rollback();
                return false;
            }

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    horario.setIdHorario(rs.getInt(1));
                } else {
                    conexion.rollback();
                    return false;
                }
            }

            for (HorarioDiaTrabajoDTO diaTrabajo : horario.getDiasTrabajo()) {
                diaTrabajo.setIdHorario(horario.getIdHorario());
                if (!horarioDiaTrabajoDAO.crearHorarioDiaTrabajo(diaTrabajo)) {
                    conexion.rollback();
                    return false;
                }
            }

            conexion.commit();
            return true;
        } catch (SQLException e) {
            conexion.rollback();
            throw e;
        } finally {
            conexion.setAutoCommit(true);
        }
    }

    public boolean actualizarHorario(HorarioDTO horario) throws SQLException {
        String sql = "UPDATE Horario SET nombreHorario = ?, horasMaxSemanales = ? WHERE idHorario = ?";
        conexion.setAutoCommit(false);
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, horario.getNombreHorario());
            stmt.setInt(2, horario.getHorasMaxSemanales());
            stmt.setInt(3, horario.getIdHorario());

            int filas = stmt.executeUpdate();
            if (filas == 0) {
                conexion.rollback();
                return false;
            }

            horarioDiaTrabajoDAO.eliminarDiasTrabajoDeHorario(horario.getIdHorario());
            for (HorarioDiaTrabajoDTO diaTrabajo : horario.getDiasTrabajo()) {
                diaTrabajo.setIdHorario(horario.getIdHorario());
                if (!horarioDiaTrabajoDAO.crearHorarioDiaTrabajo(diaTrabajo)) {
                    conexion.rollback();
                    return false;
                }
            }

            conexion.commit();
            return true;
        } catch (SQLException e) {
            conexion.rollback();
            throw e;
        } finally {
            conexion.setAutoCommit(true);
        }
    }

    public boolean eliminarHorario(int idHorario) throws SQLException {
        String sql = "DELETE FROM Horario WHERE idHorario = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idHorario);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean existeNombreHorario(String nombre, Integer idExcluido) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Horario WHERE nombreHorario = ?";
        if (idExcluido != null) sql += " AND idHorario != ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            if (idExcluido != null) stmt.setInt(2, idExcluido);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }
}
