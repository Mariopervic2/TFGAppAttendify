package accesoDatos;

import modelo.DiaFestivoDTO;
import varios.ConexionBD;
import varios.GestorIdioma;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class DiaFestivoDAO {
    private Connection conexion;

    public DiaFestivoDAO() {
        try {
            conexion = ConexionBD.obtenerConexion();
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener la conexión a la base de datos", e);
        }
    }

    public DiaFestivoDAO(Connection conexion) {
        this.conexion = conexion;
    }

    private Connection getConexion() throws SQLException {
        if (conexion == null || conexion.isClosed()) {
            conexion = ConexionBD.obtenerConexion();
        }
        return conexion;
    }

    public List<DiaFestivoDTO> obtenerTodosFestivos() {
        List<DiaFestivoDTO> festivos = new ArrayList<>();
        String sql = "SELECT * FROM DiaFestivo ORDER BY fecha";
        try (Statement stmt = getConexion().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                DiaFestivoDTO festivo = new DiaFestivoDTO();
                festivo.setIdFestivo(rs.getInt("idFestivo"));
                festivo.setFecha(rs.getDate("fecha").toLocalDate());
                festivo.setNombre(rs.getString("nombre"));
                festivos.add(festivo);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener días festivos: " + e.getMessage());
        }
        return festivos;
    }

    public boolean crearFestivo(DiaFestivoDTO festivo) {
        String sql = "INSERT INTO DiaFestivo (fecha, nombre) VALUES (?, ?)";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setDate(1, java.sql.Date.valueOf(festivo.getFecha()));
            pstmt.setString(2, festivo.getNombre());
            return pstmt.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(
                    null,
                    GestorIdioma.getString("ERR_YA_FESTIVO"),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        } catch (SQLException e) {
            System.err.println("Error al crear día festivo: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarFestivo(DiaFestivoDTO festivo) {
        String sql = "UPDATE DiaFestivo SET fecha = ?, nombre = ? WHERE idFestivo = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setDate(1, java.sql.Date.valueOf(festivo.getFecha()));
            pstmt.setString(2, festivo.getNombre());
            pstmt.setInt(3, festivo.getIdFestivo());
            return pstmt.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(
                    null,
                    GestorIdioma.getString("ERR_YA_FESTIVO"),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        } catch (SQLException e) {
            System.err.println("Error al actualizar día festivo: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarFestivo(int idFestivo) {
        String sql = "DELETE FROM DiaFestivo WHERE idFestivo = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idFestivo);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar día festivo: " + e.getMessage());
            return false;
        }
    }

    public boolean esFechaFestiva(LocalDate fecha) {
        String sql = "SELECT COUNT(*) FROM DiaFestivo WHERE fecha = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setDate(1, java.sql.Date.valueOf(fecha));
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar fecha festiva: " + e.getMessage());
            return false;
        }
    }

    public DiaFestivoDTO obtenerFestivoPorId(int idFestivo) {
        String sql = "SELECT * FROM DiaFestivo WHERE idFestivo = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idFestivo);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    DiaFestivoDTO festivo = new DiaFestivoDTO();
                    festivo.setIdFestivo(rs.getInt("idFestivo"));
                    festivo.setFecha(rs.getDate("fecha").toLocalDate());
                    festivo.setNombre(rs.getString("nombre"));
                    return festivo;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener día festivo por ID: " + e.getMessage());
        }
        return null;
    }

    public List<DiaFestivoDTO> obtenerEntre(LocalDate inicio, LocalDate fin) throws SQLException {
        List<DiaFestivoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM DiaFestivo WHERE fecha BETWEEN ? AND ? ORDER BY fecha";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setDate(1, java.sql.Date.valueOf(inicio));
            pstmt.setDate(2, java.sql.Date.valueOf(fin));
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    DiaFestivoDTO festivo = new DiaFestivoDTO();
                    festivo.setIdFestivo(rs.getInt("idFestivo"));
                    festivo.setFecha(rs.getDate("fecha").toLocalDate());
                    festivo.setNombre(rs.getString("nombre"));
                    lista.add(festivo);
                }
            }
        }
        return lista;
    }

    public void cerrar() {
        ConexionBD.cerrarConexion();
    }
}
