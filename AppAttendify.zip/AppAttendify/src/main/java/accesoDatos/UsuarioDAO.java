package accesoDatos;

import modelo.UsuarioDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private Connection conexion;

    public UsuarioDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public List<UsuarioDTO> obtenerTodosUsuarios() throws SQLException {
        List<UsuarioDTO> usuarios = new ArrayList<>();
        String sql = "SELECT u.*, CONCAT(e.nombre, ' ', e.apellidos) as nombreEmpleado " +
                "FROM Usuario u JOIN Empleado e ON u.idEmpleado = e.idEmpleado";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                UsuarioDTO usuario = new UsuarioDTO();
                usuario.setIdUsuario(rs.getInt("idUsuario"));
                usuario.setIdEmpleado(rs.getInt("idEmpleado"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setRol(rs.getString("rol"));
                usuario.setNombreEmpleado(rs.getString("nombreEmpleado"));

                usuarios.add(usuario);
            }
        }

        return usuarios;
    }

    public UsuarioDTO autenticarUsuario(String username, String password) throws SQLException {
        String sql = "SELECT u.*, CONCAT(e.nombre, ' ', e.apellidos) as nombreEmpleado " +
                "FROM Usuario u JOIN Empleado e ON u.idEmpleado = e.idEmpleado " +
                "WHERE u.username = ? AND u.password = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    UsuarioDTO usuario = new UsuarioDTO();
                    usuario.setIdUsuario(rs.getInt("idUsuario"));
                    usuario.setIdEmpleado(rs.getInt("idEmpleado"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setPassword(rs.getString("password"));
                    usuario.setRol(rs.getString("rol"));
                    usuario.setNombreEmpleado(rs.getString("nombreEmpleado"));

                    return usuario;
                }
            }
        }

        return null;
    }

    public UsuarioDTO obtenerUsuarioPorId(int idUsuario) throws SQLException {
        String sql = "SELECT u.*, CONCAT(e.nombre, ' ', e.apellidos) as nombreEmpleado " +
                "FROM Usuario u JOIN Empleado e ON u.idEmpleado = e.idEmpleado " +
                "WHERE u.idUsuario = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    UsuarioDTO usuario = new UsuarioDTO();
                    usuario.setIdUsuario(rs.getInt("idUsuario"));
                    usuario.setIdEmpleado(rs.getInt("idEmpleado"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setPassword(rs.getString("password"));
                    usuario.setRol(rs.getString("rol"));
                    usuario.setNombreEmpleado(rs.getString("nombreEmpleado"));

                    return usuario;
                }
            }
        }

        return null;
    }

    public boolean crearUsuario(UsuarioDTO usuario) throws SQLException {
        String sql = "INSERT INTO Usuario (idEmpleado, username, password, rol) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, usuario.getIdEmpleado());
            stmt.setString(2, usuario.getUsername());
            stmt.setString(3, usuario.getPassword());
            stmt.setString(4, usuario.getRol());

            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        usuario.setIdUsuario(generatedKeys.getInt(1));
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean actualizarUsuario(UsuarioDTO usuario) throws SQLException {
        String sql = "UPDATE Usuario SET idEmpleado = ?, username = ?, password = ?, rol = ? WHERE idUsuario = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, usuario.getIdEmpleado());
            stmt.setString(2, usuario.getUsername());
            stmt.setString(3, usuario.getPassword());
            stmt.setString(4, usuario.getRol());
            stmt.setInt(5, usuario.getIdUsuario());

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }

    public boolean eliminarUsuario(int idUsuario) throws SQLException {
        String sql = "DELETE FROM Usuario WHERE idUsuario = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }

    public boolean existeUsername(String username, Integer idUsuarioExcluido) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Usuario WHERE username = ?";

        if (idUsuarioExcluido != null) {
            sql += " AND idUsuario != ?";
        }

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, username);

            if (idUsuarioExcluido != null) {
                stmt.setInt(2, idUsuarioExcluido);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false;
    }
}