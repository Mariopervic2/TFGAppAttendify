package accesoDatos;

import modelo.EmpleadoDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {
    private Connection conexion;

    public EmpleadoDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public List<EmpleadoDTO> obtenerTodosEmpleados() throws SQLException {
        List<EmpleadoDTO> empleados = new ArrayList<>();
        String sql = "SELECT * FROM Empleado";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EmpleadoDTO empleado = new EmpleadoDTO();
                empleado.setIdEmpleado(rs.getInt("idEmpleado"));
                empleado.setNombre(rs.getString("nombre"));
                empleado.setApellidos(rs.getString("apellidos"));
                empleado.setDni(rs.getString("dni"));
                empleado.setIdHorario(rs.getInt("idHorario"));
                empleado.setTelefono(rs.getString("telefono"));
                empleado.setEmail(rs.getString("email"));
                empleado.setPuesto(rs.getString("puesto"));

                empleados.add(empleado);
            }
        }

        return empleados;
    }

    public EmpleadoDTO obtenerEmpleadoPorId(int idEmpleado) throws SQLException {
        String sql = "SELECT * FROM Empleado WHERE idEmpleado = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idEmpleado);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    EmpleadoDTO empleado = new EmpleadoDTO();
                    empleado.setIdEmpleado(rs.getInt("idEmpleado"));
                    empleado.setNombre(rs.getString("nombre"));
                    empleado.setApellidos(rs.getString("apellidos"));
                    empleado.setDni(rs.getString("dni"));
                    empleado.setIdHorario(rs.getInt("idHorario"));
                    empleado.setTelefono(rs.getString("telefono"));
                    empleado.setEmail(rs.getString("email"));
                    empleado.setPuesto(rs.getString("puesto"));

                    return empleado;
                }
            }
        }

        return null;
    }

    public boolean crearEmpleado(EmpleadoDTO empleado) throws SQLException {
        String sql = "INSERT INTO Empleado (nombre, apellidos, dni, idHorario, telefono, email, puesto) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexion.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, empleado.getNombre());
            stmt.setString(2, empleado.getApellidos());
            stmt.setString(3, empleado.getDni());

            if (empleado.getIdHorario() > 0) {
                stmt.setInt(4, empleado.getIdHorario());
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            stmt.setString(5, empleado.getTelefono());
            stmt.setString(6, empleado.getEmail());
            stmt.setString(7, empleado.getPuesto());

            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        empleado.setIdEmpleado(generatedKeys.getInt(1));
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean actualizarEmpleado(EmpleadoDTO empleado) throws SQLException {
        String sql = "UPDATE Empleado SET nombre = ?, apellidos = ?, dni = ?, idHorario = ?, telefono = ?, email = ?, puesto = ? WHERE idEmpleado = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, empleado.getNombre());
            stmt.setString(2, empleado.getApellidos());
            stmt.setString(3, empleado.getDni());

            if (empleado.getIdHorario() > 0) {
                stmt.setInt(4, empleado.getIdHorario());
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            stmt.setString(5, empleado.getTelefono());
            stmt.setString(6, empleado.getEmail());
            stmt.setString(7, empleado.getPuesto());
            stmt.setInt(8, empleado.getIdEmpleado());

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }

    public boolean eliminarEmpleado(int idEmpleado) throws SQLException {
        String sql = "DELETE FROM Empleado WHERE idEmpleado = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idEmpleado);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }

    public boolean existeDNI(String dni, Integer idEmpleadoExcluido) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Empleado WHERE dni = ?";

        if (idEmpleadoExcluido != null) {
            sql += " AND idEmpleado != ?";
        }

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, dni);

            if (idEmpleadoExcluido != null) {
                stmt.setInt(2, idEmpleadoExcluido);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false;
    }

    public List<EmpleadoDTO> obtenerEmpleadosConHorario() throws SQLException {
        List<EmpleadoDTO> empleados = new ArrayList<>();
        String sql = "SELECT e.*, h.nombreHorario FROM Empleado e LEFT JOIN Horario h ON e.idHorario = h.idHorario";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EmpleadoDTO empleado = new EmpleadoDTO();
                empleado.setIdEmpleado(rs.getInt("idEmpleado"));
                empleado.setNombre(rs.getString("nombre"));
                empleado.setApellidos(rs.getString("apellidos"));
                empleado.setDni(rs.getString("dni"));
                empleado.setIdHorario(rs.getInt("idHorario"));
                empleado.setTelefono(rs.getString("telefono"));
                empleado.setEmail(rs.getString("email"));
                empleado.setPuesto(rs.getString("puesto"));
                empleados.add(empleado);
            }
        }

        return empleados;
    }

    public boolean debeTrabajareEnFecha(int idEmpleado, java.time.LocalDate fecha) {
        int idHorario = -1;
        String sql1 = "SELECT idHorario FROM Empleado WHERE idEmpleado = ?";

        try (PreparedStatement pstmt = conexion.prepareStatement(sql1)) {
            pstmt.setInt(1, idEmpleado);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    idHorario = rs.getInt("idHorario");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar horario del empleado: " + e.getMessage());
            return false;
        }

        if (idHorario == -1) {
            return false;
        }

        String sql2 = "SELECT hdt.activo FROM Horario_DiaTrabajo hdt " +
                "JOIN Dia d ON hdt.idDia = d.idDia " +
                "WHERE hdt.idHorario = ? AND DAYOFWEEK(?) = d.idDia";

        try (PreparedStatement pstmt = conexion.prepareStatement(sql2)) {
            pstmt.setInt(1, idHorario);
            pstmt.setDate(2, java.sql.Date.valueOf(fecha));

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBoolean("activo");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar día de trabajo: " + e.getMessage());
        }

        return false;
    }

    public List<EmpleadoDTO> obtenerTodosLosEmpleados() throws SQLException {
        List<EmpleadoDTO> empleados = new ArrayList<>();
        String sql = "SELECT * FROM Empleado ORDER BY apellidos, nombre";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EmpleadoDTO empleado = new EmpleadoDTO();
                empleado.setIdEmpleado(rs.getInt("idEmpleado"));
                empleado.setNombre(rs.getString("nombre"));
                empleado.setApellidos(rs.getString("apellidos"));
                empleado.setDni(rs.getString("dni"));
                empleado.setIdHorario(rs.getInt("idHorario"));
                empleado.setTelefono(rs.getString("telefono"));
                empleado.setEmail(rs.getString("email"));
                empleado.setPuesto(rs.getString("puesto"));

                empleados.add(empleado);
            }
        }

        return empleados;
    }


}