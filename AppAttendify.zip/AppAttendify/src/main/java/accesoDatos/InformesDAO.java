package accesoDatos;

import modelo.InformesDTO;
import modelo.RegistroDTO;
import modelo.EmpleadoDTO;
import modelo.HorarioDTO;
import modelo.HorarioDiaTrabajoDTO;
import accesoDatos.RegistroDAO;
import accesoDatos.EmpleadoDAO;
import accesoDatos.HorarioDAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.YearMonth;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class InformesDAO {
    private Connection conexion;

    public InformesDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public List<YearMonth> obtenerMesesConInforme(int idEmpleado) throws SQLException {
        String sql = "SELECT DISTINCT YEAR(fecha) AS anio, MONTH(fecha) AS mes " +
                "FROM Registro WHERE idEmpleado = ? ORDER BY anio DESC, mes DESC";
        List<YearMonth> meses = new ArrayList<>();
        try (var stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idEmpleado);
            try (var rs = stmt.executeQuery()) {
                while (rs.next()) {
                    meses.add(YearMonth.of(rs.getInt("anio"), rs.getInt("mes")));
                }
            }
        }
        return meses;
    }

    public InformesDTO obtenerInformeMensual(int idEmpleado, YearMonth mes) throws SQLException {
        InformesDTO informe = new InformesDTO();
        informe.setIdEmpleado(idEmpleado);
        informe.setMes(mes);

        EmpleadoDAO empDao = new EmpleadoDAO(conexion);
        EmpleadoDTO emp = empDao.obtenerEmpleadoPorId(idEmpleado);
        informe.setNombreEmpleado(emp.getNombre() + " " + emp.getApellidos());

        int idHorario = emp.getIdHorario();
        informe.setIdHorario(idHorario);

        HorarioDAO horDao = new HorarioDAO(conexion);
        HorarioDTO horario = horDao.obtenerHorarioPorId(idHorario);
        StringBuilder descHorario = new StringBuilder();
        for (HorarioDiaTrabajoDTO d : horario.getDiasTrabajo()) {
            if (d.isActivo()) {
                if (descHorario.length() > 0) descHorario.append(" ");
                descHorario.append(d.getNombreDia())
                        .append(" ")
                        .append(d.getHoraEntrada()).append("-").append(d.getHoraSalida());
            }
        }
        informe.setHorarioDescripcion(descHorario.toString());

        RegistroDAO regDao = new RegistroDAO(conexion);
        LocalDate inicio = mes.atDay(1);
        LocalDate fin = mes.atEndOfMonth();
        List<RegistroDTO> todos = regDao.obtenerTodosRegistros();
        List<RegistroDTO> registrosMes = new ArrayList<>();
        for (RegistroDTO r : todos) {
            if (r.getIdEmpleado() == idEmpleado
                    && !r.getFecha().isBefore(inicio)
                    && !r.getFecha().isAfter(fin)) {
                registrosMes.add(r);
            }
        }
        informe.setHorarioDescripcion(horario.getNombreHorario());


        double horasPrevistas = 0;
        LocalDate dia = inicio;
        while (!dia.isAfter(fin)) {
            for (HorarioDiaTrabajoDTO d : horario.getDiasTrabajo()) {
                if (d.isActivo() && dia.getDayOfWeek().getValue() == d.getIdDia()) {
                    horasPrevistas += ChronoUnit.MINUTES.between(d.getHoraEntrada(), d.getHoraSalida()) / 60.0;
                    break;
                }
            }
            dia = dia.plusDays(1);
        }
        informe.setHorasPrevistas(horasPrevistas);

        double horasTrabajadas = 0;
        for (RegistroDTO r : registrosMes) {
            if (r.getHoraEntrada() != null && r.getHoraSalida() != null) {
                horasTrabajadas += ChronoUnit.MINUTES.between(r.getHoraEntrada(), r.getHoraSalida()) / 60.0;
            }
        }
        informe.setHorasTrabajadas(horasTrabajadas);

        double horasExtra = horasTrabajadas - horasPrevistas;
        informe.setHorasExtra(Math.max(horasExtra, 0));

        return informe;
    }

}
