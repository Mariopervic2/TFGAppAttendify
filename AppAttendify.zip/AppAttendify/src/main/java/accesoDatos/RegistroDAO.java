package accesoDatos;

import modelo.RegistroDTO;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

import modelo.VacacionesDTO;
import varios.ConexionBD;

public class RegistroDAO {
    private Connection conexion;

    public RegistroDAO() {
        try {
            this.conexion = ConexionBD.obtenerConexion();
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener la conexión a la base de datos", e);
        }
    }

    public RegistroDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean existeRegistroPendiente(int idEmpleado, LocalDate fecha) {
        String sql = "SELECT COUNT(*) FROM Registro "
                + "WHERE idEmpleado = ? AND fecha = ? AND estado = 'Pendiente'";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setInt(1, idEmpleado);
            pstmt.setDate(2, Date.valueOf(fecha));
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error comprobando registro pendiente: " + e.getMessage());
            return false;
        }
    }

    public boolean crearRegistroEntrada(int idEmpleado, LocalDate fecha) {
        String sql = "INSERT INTO Registro (idEmpleado, estado, fecha, horaEntrada) "
                + "VALUES (?, 'Pendiente', ?, ?)";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setInt(1, idEmpleado);
            pstmt.setDate(2, Date.valueOf(fecha));
            pstmt.setTime(3, Time.valueOf(LocalTime.now()));
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creando registro de entrada: " + e.getMessage());
            return false;
        }
    }

    public boolean completarRegistroSalida(int idEmpleado, LocalDate fecha) {
        String sql = "UPDATE Registro "
                + "SET horaSalida = ?, estado = 'Completado' "
                + "WHERE idEmpleado = ? AND fecha = ? AND estado = 'Pendiente'";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setTime(1, Time.valueOf(LocalTime.now()));
            pstmt.setInt(2, idEmpleado);
            pstmt.setDate(3, Date.valueOf(fecha));
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error completando registro de salida: " + e.getMessage());
            return false;
        }
    }

    public boolean haySolapamiento(int idEmpleado,
                                   LocalDate fecha,
                                   LocalTime nuevaEntrada,
                                   LocalTime nuevaSalida,
                                   Integer idRegistroExcluido) throws SQLException {

        LocalDateTime nuevaInicio = LocalDateTime.of(fecha, nuevaEntrada);
        LocalDateTime nuevaFin = nuevaSalida.isAfter(nuevaEntrada)
                ? LocalDateTime.of(fecha, nuevaSalida)
                : LocalDateTime.of(fecha.plusDays(1), nuevaSalida);

        String sql = """
                SELECT COUNT(*) FROM Registro
                WHERE idEmpleado = ?
                  AND (
                    (TIMESTAMP(fecha, horaEntrada) < ? AND 
                     (CASE WHEN horaSalida > horaEntrada 
                           THEN TIMESTAMP(fecha, horaSalida)
                           ELSE TIMESTAMP(DATE_ADD(fecha, INTERVAL 1 DAY), horaSalida)
                      END) > ?)
                  )
                """ + (idRegistroExcluido != null ? " AND idRegistro <> ?" : "");

        try (PreparedStatement p = conexion.prepareStatement(sql)) {
            p.setInt(1, idEmpleado);
            p.setTimestamp(2, Timestamp.valueOf(nuevaFin));
            p.setTimestamp(3, Timestamp.valueOf(nuevaInicio));
            if (idRegistroExcluido != null) {
                p.setInt(4, idRegistroExcluido);
            }

            try (ResultSet rs = p.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }


    public void cerrar() {
        ConexionBD.cerrarConexion();
    }

    public List<RegistroDTO> obtenerTodosRegistros() throws SQLException {
        String sql = "SELECT idRegistro, idEmpleado, fecha, horaEntrada, horaSalida, estado, comentarios "
                + "FROM Registro ORDER BY fecha DESC, horaEntrada";
        List<RegistroDTO> lista = new ArrayList<>();
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                RegistroDTO dto = new RegistroDTO();
                dto.setIdRegistro(rs.getInt("idRegistro"));
                dto.setIdEmpleado(rs.getInt("idEmpleado"));
                dto.setFecha(rs.getDate("fecha").toLocalDate());
                Time he = rs.getTime("horaEntrada");
                if (he != null) dto.setHoraEntrada(he.toLocalTime());
                Time hs = rs.getTime("horaSalida");
                if (hs != null) dto.setHoraSalida(hs.toLocalTime());
                dto.setEstado(rs.getString("estado"));
                dto.setComentarios(rs.getString("comentarios"));
                lista.add(dto);
            }
        }
        return lista;
    }

    public boolean crearRegistroManual(RegistroDTO registro) throws SQLException {
        String sql = "INSERT INTO Registro (idEmpleado, fecha, horaEntrada, horaSalida, estado, comentarios) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setInt(1, registro.getIdEmpleado());
            pstmt.setDate(2, Date.valueOf(registro.getFecha()));
            pstmt.setTime(3, registro.getHoraEntrada() != null
                    ? Time.valueOf(registro.getHoraEntrada()) : null);
            pstmt.setTime(4, registro.getHoraSalida() != null
                    ? Time.valueOf(registro.getHoraSalida()) : null);
            pstmt.setString(5, registro.getEstado());
            pstmt.setString(6, registro.getComentarios());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean actualizarRegistro(RegistroDTO registro) throws SQLException {
        String sql = "UPDATE Registro SET idEmpleado = ?, fecha = ?, horaEntrada = ?, horaSalida = ?, "
                + "estado = ?, comentarios = ? WHERE idRegistro = ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setInt(1, registro.getIdEmpleado());
            pstmt.setDate(2, Date.valueOf(registro.getFecha()));
            pstmt.setTime(3, registro.getHoraEntrada() != null
                    ? Time.valueOf(registro.getHoraEntrada()) : null);
            pstmt.setTime(4, registro.getHoraSalida() != null
                    ? Time.valueOf(registro.getHoraSalida()) : null);
            pstmt.setString(5, registro.getEstado());
            pstmt.setString(6, registro.getComentarios());
            pstmt.setInt(7, registro.getIdRegistro());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean eliminarRegistro(int idRegistro) throws SQLException {
        String sql = "DELETE FROM Registro WHERE idRegistro = ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
            pstmt.setInt(1, idRegistro);
            return pstmt.executeUpdate() > 0;
        }
    }

    public List<RegistroDTO> obtenerRegistrosPorMes(int idEmpleado, YearMonth mes) throws SQLException {
        String sql = """
                    SELECT fecha, horaEntrada, horaSalida, estado, comentarios
                    FROM Registro
                    WHERE idEmpleado = ?
                      AND fecha BETWEEN ? AND ?
                    ORDER BY fecha, horaEntrada
                """;

        LocalDate desde = mes.atDay(1);
        LocalDate hasta = mes.atEndOfMonth();
        List<RegistroDTO> lista = new ArrayList<>();

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEmpleado);
            ps.setDate(2, Date.valueOf(desde));
            ps.setDate(3, Date.valueOf(hasta));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    RegistroDTO dto = new RegistroDTO();
                    dto.setFecha(rs.getDate("fecha").toLocalDate());
                    Time te = rs.getTime("horaEntrada");
                    dto.setHoraEntrada(te != null ? te.toLocalTime() : null);
                    Time ts = rs.getTime("horaSalida");
                    dto.setHoraSalida(ts != null ? ts.toLocalTime() : null);
                    dto.setEstado(rs.getString("estado"));
                    dto.setComentarios(rs.getString("comentarios"));
                    lista.add(dto);
                }
            }
        }
        return lista;
    }

    public List<VacacionesDTO> obtenerVacacionesEntre(int idEmpleado, LocalDate inicio, LocalDate fin) throws SQLException {
        List<VacacionesDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM Vacaciones WHERE idEmpleado = ? AND (fechaInicio <= ? AND fechaFin >= ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEmpleado);
            ps.setDate(2, java.sql.Date.valueOf(fin));
            ps.setDate(3, java.sql.Date.valueOf(inicio));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    VacacionesDTO vac = new VacacionesDTO();
                    vac.setIdVacaciones(rs.getInt("idVacaciones"));
                    vac.setIdEmpleado(rs.getInt("idEmpleado"));
                    vac.setNombreEmpleado("");
                    vac.setFechaInicio(rs.getDate("fechaInicio").toLocalDate());
                    vac.setFechaFin(rs.getDate("fechaFin").toLocalDate());
                    vac.setDescripcion(rs.getString("descripcion"));

                    lista.add(vac);
                }
            }
        }
        return lista;
    }


}
