package accesoDatos;

import modelo.HorarioDiaTrabajoDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class HorarioDiaTrabajoDAO {
    private final Connection conexion;

    public HorarioDiaTrabajoDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean crearHorarioDiaTrabajo(HorarioDiaTrabajoDTO diaTrabajo) throws SQLException {
        String sql = "INSERT INTO Horario_DiaTrabajo "
                + "(idHorario, idDia, horaEntrada, horaSalida, tiempoDescanso, activo) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, diaTrabajo.getIdHorario());
            stmt.setInt(2, diaTrabajo.getIdDia());
            stmt.setTime(3, Time.valueOf(diaTrabajo.getHoraEntrada()));
            stmt.setTime(4, Time.valueOf(diaTrabajo.getHoraSalida()));
            stmt.setInt(5, diaTrabajo.getTiempoDescanso());
            stmt.setBoolean(6, diaTrabajo.isActivo());
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean actualizarHorarioDiaTrabajo(HorarioDiaTrabajoDTO diaTrabajo) throws SQLException {
        String sql = "UPDATE Horario_DiaTrabajo "
                + "SET horaEntrada = ?, horaSalida = ?, tiempoDescanso = ?, activo = ? "
                + "WHERE idHorarioDiaTrabajo = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setTime(1, Time.valueOf(diaTrabajo.getHoraEntrada()));
            stmt.setTime(2, Time.valueOf(diaTrabajo.getHoraSalida()));
            stmt.setInt(3, diaTrabajo.getTiempoDescanso());
            stmt.setBoolean(4, diaTrabajo.isActivo());
            stmt.setInt(5, diaTrabajo.getIdHorarioDiaTrabajo());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<HorarioDiaTrabajoDTO> obtenerDiasTrabajoPorHorario(int idHorario) throws SQLException {
        List<HorarioDiaTrabajoDTO> diasTrabajo = new ArrayList<>();
        String sql = ""
                + "SELECT hdt.idHorarioDiaTrabajo, hdt.idHorario, hdt.idDia, "
                + "hdt.horaEntrada, hdt.horaSalida, hdt.tiempoDescanso, hdt.activo, d.nombre AS nombreDia "
                + "FROM Horario_DiaTrabajo hdt "
                + "JOIN Dia d ON hdt.idDia = d.idDia "
                + "WHERE hdt.idHorario = ? "
                + "ORDER BY hdt.idDia";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idHorario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    HorarioDiaTrabajoDTO dto = new HorarioDiaTrabajoDTO();
                    dto.setIdHorarioDiaTrabajo(rs.getInt("idHorarioDiaTrabajo"));
                    dto.setIdHorario(rs.getInt("idHorario"));
                    dto.setIdDia(rs.getInt("idDia"));
                    dto.setHoraEntrada(rs.getTime("horaEntrada").toLocalTime());
                    dto.setHoraSalida(rs.getTime("horaSalida").toLocalTime());
                    dto.setTiempoDescanso(rs.getInt("tiempoDescanso"));
                    dto.setActivo(rs.getBoolean("activo"));
                    dto.setNombreDia(rs.getString("nombreDia"));
                    diasTrabajo.add(dto);
                }
            }
        }
        return diasTrabajo;
    }

    public boolean eliminarDiasTrabajoDeHorario(int idHorario) throws SQLException {
        String sql = "DELETE FROM Horario_DiaTrabajo WHERE idHorario = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idHorario);
            return stmt.executeUpdate() > 0;
        }
    }
}