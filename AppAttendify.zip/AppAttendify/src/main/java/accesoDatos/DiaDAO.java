package accesoDatos;

import modelo.DiaDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DiaDAO {
    private Connection conexion;

    public DiaDAO(Connection conexion) {
        this.conexion = conexion;
    }


    public List<DiaDTO> obtenerTodosDias() throws SQLException {
        List<DiaDTO> dias = new ArrayList<>();
        String sql = "SELECT * FROM Dia ORDER BY idDia";

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                DiaDTO dia = new DiaDTO();
                dia.setIdDia(rs.getInt("idDia"));
                dia.setNombre(rs.getString("nombre"));

                dias.add(dia);
            }
        }

        return dias;
    }

    public DiaDTO obtenerDiaPorId(int idDia) throws SQLException {
        String sql = "SELECT * FROM Dia WHERE idDia = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idDia);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    DiaDTO dia = new DiaDTO();
                    dia.setIdDia(rs.getInt("idDia"));
                    dia.setNombre(rs.getString("nombre"));

                    return dia;
                }
            }
        }

        return null;
    }
}