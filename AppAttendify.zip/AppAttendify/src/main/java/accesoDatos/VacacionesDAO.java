package accesoDatos;

import modelo.VacacionesDTO;
import varios.ConexionBD;
import varios.GestorIdioma;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VacacionesDAO {
    private Connection conexion;

    public VacacionesDAO() {
        try {
            conexion = ConexionBD.obtenerConexion();
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener la conexión a la base de datos", e);
        }
    }

    public VacacionesDAO(Connection conexion) {
        this.conexion = conexion;
    }

    private Connection getConexion() throws SQLException {
        if (conexion == null || conexion.isClosed()) {
            conexion = ConexionBD.obtenerConexion();
        }
        return conexion;
    }

    public List<VacacionesDTO> obtenerTodasVacaciones() {
        List<VacacionesDTO> lista = new ArrayList<>();
        String sql = "SELECT v.*, CONCAT(e.nombre, ' ', e.apellidos) AS nombreCompleto " +
                "FROM Vacaciones v JOIN Empleado e ON v.idEmpleado = e.idEmpleado " +
                "ORDER BY v.fechaInicio";
        try (Statement stmt = getConexion().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                VacacionesDTO vac = new VacacionesDTO();
                vac.setIdVacaciones(rs.getInt("idVacaciones"));
                vac.setIdEmpleado(rs.getInt("idEmpleado"));
                vac.setNombreEmpleado(rs.getString("nombreCompleto"));
                vac.setFechaInicio(rs.getDate("fechaInicio").toLocalDate());
                vac.setFechaFin(rs.getDate("fechaFin").toLocalDate());
                vac.setDescripcion(rs.getString("descripcion"));
                lista.add(vac);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener vacaciones: " + e.getMessage());
        }
        return lista;
    }

    public boolean crearVacaciones(VacacionesDTO vacaciones) {
        if (estaDeVacaciones(vacaciones.getIdEmpleado(), vacaciones.getFechaInicio())) {
            JOptionPane.showMessageDialog(
                    null,
                    GestorIdioma.getString("ERR_YA_VACACIONES"),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }

        String sql = "INSERT INTO Vacaciones (idEmpleado, fechaInicio, fechaFin, descripcion) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, vacaciones.getIdEmpleado());
            pstmt.setDate(2, java.sql.Date.valueOf(vacaciones.getFechaInicio()));
            pstmt.setDate(3, java.sql.Date.valueOf(vacaciones.getFechaFin()));
            pstmt.setString(4, vacaciones.getDescripcion());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al crear vacaciones: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarVacaciones(VacacionesDTO vacaciones) {
        String sql = "UPDATE Vacaciones SET idEmpleado = ?, fechaInicio = ?, fechaFin = ?, descripcion = ? " +
                "WHERE idVacaciones = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, vacaciones.getIdEmpleado());
            pstmt.setDate(2, java.sql.Date.valueOf(vacaciones.getFechaInicio()));
            pstmt.setDate(3, java.sql.Date.valueOf(vacaciones.getFechaFin()));
            pstmt.setString(4, vacaciones.getDescripcion());
            pstmt.setInt(5, vacaciones.getIdVacaciones());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar vacaciones: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarVacaciones(int idVacaciones) {
        String sql = "DELETE FROM Vacaciones WHERE idVacaciones = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idVacaciones);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar vacaciones: " + e.getMessage());
            return false;
        }
    }

    public VacacionesDTO obtenerVacacionesPorId(int idVacaciones) {
        String sql = "SELECT v.*, CONCAT(e.nombre, ' ', e.apellidos) AS nombreCompleto " +
                "FROM Vacaciones v JOIN Empleado e ON v.idEmpleado = e.idEmpleado " +
                "WHERE v.idVacaciones = ?";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idVacaciones);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    VacacionesDTO vac = new VacacionesDTO();
                    vac.setIdVacaciones(rs.getInt("idVacaciones"));
                    vac.setIdEmpleado(rs.getInt("idEmpleado"));
                    vac.setNombreEmpleado(rs.getString("nombreCompleto"));
                    vac.setFechaInicio(rs.getDate("fechaInicio").toLocalDate());
                    vac.setFechaFin(rs.getDate("fechaFin").toLocalDate());
                    vac.setDescripcion(rs.getString("descripcion"));
                    return vac;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener vacaciones por ID: " + e.getMessage());
        }
        return null;
    }

    public List<VacacionesDTO> obtenerVacacionesEmpleado(int idEmpleado) {
        List<VacacionesDTO> vacaciones = new ArrayList<>();
        String sql = "SELECT v.*, CONCAT(e.nombre, ' ', e.apellidos) AS nombreCompleto " +
                "FROM Vacaciones v JOIN Empleado e ON v.idEmpleado = e.idEmpleado " +
                "WHERE v.idEmpleado = ? ORDER BY v.fechaInicio";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idEmpleado);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    VacacionesDTO vac = new VacacionesDTO();
                    vac.setIdVacaciones(rs.getInt("idVacaciones"));
                    vac.setIdEmpleado(rs.getInt("idEmpleado"));
                    vac.setNombreEmpleado(rs.getString("nombreCompleto"));
                    vac.setFechaInicio(rs.getDate("fechaInicio").toLocalDate());
                    vac.setFechaFin(rs.getDate("fechaFin").toLocalDate());
                    vac.setDescripcion(rs.getString("descripcion"));
                    vacaciones.add(vac);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener vacaciones del empleado: " + e.getMessage());
        }
        return vacaciones;
    }

    public boolean estaDeVacaciones(int idEmpleado, LocalDate fecha) {
        String sql = "SELECT COUNT(*) FROM Vacaciones WHERE idEmpleado = ? AND ? BETWEEN fechaInicio AND fechaFin";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idEmpleado);
            pstmt.setDate(2, java.sql.Date.valueOf(fecha));
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar vacaciones: " + e.getMessage());
            return false;
        }
    }

    public List<VacacionesDTO> obtenerEntre(int idEmpleado, LocalDate inicio, LocalDate fin) throws SQLException {
        List<VacacionesDTO> lista = new ArrayList<>();
        String sql = ""
                + "SELECT * FROM Vacaciones "
                + "WHERE idEmpleado = ? "
                + "  AND fechaInicio <= ? "
                + "  AND fechaFin    >= ? "
                + "ORDER BY fechaInicio";
        try (PreparedStatement pstmt = getConexion().prepareStatement(sql)) {
            pstmt.setInt(1, idEmpleado);
            pstmt.setDate(2, java.sql.Date.valueOf(fin));
            pstmt.setDate(3, java.sql.Date.valueOf(inicio));
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    VacacionesDTO vac = new VacacionesDTO();
                    vac.setIdVacaciones(rs.getInt("idVacaciones"));
                    vac.setIdEmpleado(rs.getInt("idEmpleado"));
                    vac.setFechaInicio(rs.getDate("fechaInicio").toLocalDate());
                    vac.setFechaFin(rs.getDate("fechaFin").toLocalDate());
                    vac.setDescripcion(rs.getString("descripcion"));
                    lista.add(vac);
                }
            }
        }
        return lista;
    }

    public void cerrar() {
        ConexionBD.cerrarConexion();
    }
}
