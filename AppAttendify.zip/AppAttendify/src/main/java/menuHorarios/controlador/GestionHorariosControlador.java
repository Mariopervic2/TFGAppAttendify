package menuHorarios.controlador;

import accesoDatos.DiaDAO;
import accesoDatos.HorarioDAO;
import modelo.DiaDTO;
import modelo.HorarioDTO;
import menuHorarios.vista.GestionHorariosVista;
import varios.GestorIdioma;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GestionHorariosControlador {
    private static final String KEY_MSG_LOAD_SCHEDULES_ERROR     = "GH_MSG_LOAD_SCHEDULES_ERROR";
    private static final String KEY_MSG_LOAD_DAYS_ERROR          = "GH_MSG_LOAD_DAYS_ERROR";
    private static final String KEY_MSG_NAME_IN_USE              = "GH_MSG_NAME_IN_USE";
    private static final String KEY_MSG_CREATE_SUCCESS           = "GH_MSG_CREATE_SUCCESS";
    private static final String KEY_MSG_CREATE_FAIL              = "GH_MSG_CREATE_FAIL";
    private static final String KEY_MSG_CREATE_ERROR             = "GH_MSG_CREATE_ERROR";
    private static final String KEY_MSG_UPDATE_SUCCESS           = "GH_MSG_UPDATE_SUCCESS";
    private static final String KEY_MSG_UPDATE_FAIL              = "GH_MSG_UPDATE_FAIL";
    private static final String KEY_MSG_UPDATE_ERROR             = "GH_MSG_UPDATE_ERROR";
    private static final String KEY_MSG_DELETE_SUCCESS           = "GH_MSG_DELETE_SUCCESS";
    private static final String KEY_MSG_DELETE_FAIL              = "GH_MSG_DELETE_FAIL";
    private static final String KEY_MSG_DELETE_ERROR             = "GH_MSG_DELETE_ERROR";
    private static final String KEY_DIALOG_ERROR                 = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOG_INFO                  = "DIALOGO_TITULO_INFORMACION";

    private GestionHorariosVista vista;
    private HorarioDAO horarioDAO;
    private DiaDAO diaDAO;
    private JPanel contenedor;
    private JPanel panelAnterior;

    public GestionHorariosControlador(Connection conexion, JPanel contenedor, JPanel panelAnterior) {
        this.horarioDAO = new HorarioDAO(conexion);
        this.diaDAO = new DiaDAO(conexion);
        this.contenedor = contenedor;
        this.panelAnterior = panelAnterior;

        this.vista = new GestionHorariosVista();
        this.vista.setControlador(this);

        cargarHorarios();
    }

    public void mostrar() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        contenedor.add(vista, "menuHorarios");
        cl.show(contenedor, "menuHorarios");
    }

    public void volverMenuPrincipal() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, "principal");
    }

    public void cargarHorarios() {
        try {
            List<HorarioDTO> horarios = horarioDAO.obtenerTodosHorarios();
            vista.actualizarTablaHorarios(horarios);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_LOAD_SCHEDULES_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public HorarioDTO obtenerHorarioPorId(int idHorario) throws SQLException {
        return horarioDAO.obtenerHorarioPorId(idHorario);
    }

    public List<DiaDTO> obtenerDias() {
        try {
            return diaDAO.obtenerTodosDias();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_LOAD_DAYS_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return new ArrayList<>();
        }
    }

    public boolean crearHorario(HorarioDTO horario) {
        try {
            if (horarioDAO.existeNombreHorario(horario.getNombreHorario(), null)) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_NAME_IN_USE),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = horarioDAO.crearHorario(horario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_CREATE_SUCCESS),
                        GestorIdioma.getString(KEY_DIALOG_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarHorarios();
                return true;
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_CREATE_FAIL),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_CREATE_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean actualizarHorario(HorarioDTO horario) {
        try {
            if (horarioDAO.existeNombreHorario(horario.getNombreHorario(), horario.getIdHorario())) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_NAME_IN_USE),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = horarioDAO.actualizarHorario(horario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_UPDATE_SUCCESS),
                        GestorIdioma.getString(KEY_DIALOG_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarHorarios();
                return true;
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_UPDATE_FAIL),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_UPDATE_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean eliminarHorario(int idHorario) {
        try {
            boolean resultado = horarioDAO.eliminarHorario(idHorario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_DELETE_SUCCESS),
                        GestorIdioma.getString(KEY_DIALOG_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarHorarios();
                return true;
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_DELETE_FAIL),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_DELETE_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}