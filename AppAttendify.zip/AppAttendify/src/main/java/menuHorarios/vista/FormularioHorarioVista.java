package menuHorarios.vista;

import menuHorarios.controlador.GestionHorariosControlador;
import modelo.DiaDTO;
import modelo.HorarioDTO;
import modelo.HorarioDiaTrabajoDTO;
import varios.GestorIdioma;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class FormularioHorarioVista extends JDialog {
    private static final String KEY_TITLE_CREATE = "FH_TITLE_CREATE";
    private static final String KEY_TITLE_EDIT = "FH_TITLE_EDIT";
    private static final String KEY_LABEL_NAME = "FH_LABEL_NAME";
    private static final String KEY_LABEL_HOURS_MAX = "FH_LABEL_HOURS_MAX";
    private static final String KEY_HOURS_TOTAL = "FH_HOURS_TOTAL";
    private static final String KEY_LABEL_DAY_BREAK = "FH_LABEL_DAY_BREAK";
    private static final String KEY_PANEL_DAYS_TITLE = "FH_PANEL_DAYS_TITLE";
    private static final String KEY_LABEL_RANGE = "FH_LABEL_RANGE";
    private static final String KEY_BTN_SAVE = "FH_BTN_SAVE";
    private static final String KEY_BTN_CANCEL = "FH_BTN_CANCEL";
    private static final String KEY_MSG_NAME_REQUIRED = "FH_MSG_NAME_REQUIRED";
    private static final String KEY_MSG_VAL_NUM = "FH_MSG_VAL_NUM";
    private static final String KEY_MSG_TIME_ORDER = "FH_MSG_TIME_ORDER";
    private static final String KEY_MSG_TIME_FORMAT = "FH_MSG_TIME_FORMAT";
    private static final String KEY_MSG_SAVE_ERROR = "FH_MSG_SAVE_ERROR";
    private static final String KEY_DIALOG_ERROR = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOG_WARNING = "DIALOGO_TITULO_ADVERTENCIA";
    private static final String KEY_MSG_HOURS_EXCEEDED = "HORAS_EXCEDIDAS_AVISO";
    private static final String KEY_MSG_REST_PERIOD = "FH_MSG_REST_PERIOD";
    private static final String KEY_LABEL_NIGHT_SHIFT = "FH_LABEL_NIGHT_SHIFT";
    private static final String KEY_TOOLTIP_NIGHT_SHIFT = "FH_TOOLTIP_NIGHT_SHIFT";
    private static final String KEY_MSG_NIGHT_SHIFT_HINT = "FH_MSG_NIGHT_SHIFT_HINT";
    private static final String KEY_BETWEEN = "FH_BETWEEN";
    private static final String KEY_AND = "FH_AND";

    private GestionHorariosControlador controlador;
    private HorarioDTO horario;
    private JTextField txtNombreHorario;
    private JTextField txtHorasMaxSemanales;
    private JLabel lblTotalHoras;
    private Map<Integer, JCheckBox> checkboxesDia = new HashMap<>();
    private Map<Integer, JCheckBox> checkboxesNocturno = new HashMap<>();
    private Map<Integer, JTextField> camposHoraEntrada = new HashMap<>();
    private Map<Integer, JTextField> camposHoraSalida = new HashMap<>();
    private Map<Integer, JTextField> camposDescanso = new HashMap<>();
    private List<DiaDTO> listaDias;

    public FormularioHorarioVista(GestionHorariosControlador controlador, HorarioDTO horario) {
        this.controlador = controlador;
        this.horario = horario;
        this.listaDias = controlador.obtenerDias();
        setTitle(horario == null
                ? GestorIdioma.getString(KEY_TITLE_CREATE)
                : GestorIdioma.getString(KEY_TITLE_EDIT));
        setModal(true);
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        inicializarComponentes();
        if (horario != null) cargarDatosHorario();
        calcularTotalHorasSemanales();
    }

    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel panelFormulario = new JPanel(new GridLayout(3, 2, 10, 10));
        panelFormulario.add(new JLabel(GestorIdioma.getString(KEY_LABEL_NAME)));
        txtNombreHorario = new JTextField(20);
        panelFormulario.add(txtNombreHorario);

        panelFormulario.add(new JLabel(GestorIdioma.getString(KEY_LABEL_HOURS_MAX)));
        txtHorasMaxSemanales = new JTextField("0", 5);
        txtHorasMaxSemanales.setEditable(false);
        panelFormulario.add(txtHorasMaxSemanales);

        panelFormulario.add(new JLabel(GestorIdioma.getString(KEY_HOURS_TOTAL)));
        lblTotalHoras = new JLabel("0");
        lblTotalHoras.setFont(lblTotalHoras.getFont().deriveFont(Font.BOLD));
        panelFormulario.add(lblTotalHoras);

        JPanel panelDias = new JPanel();
        panelDias.setLayout(new BoxLayout(panelDias, BoxLayout.Y_AXIS));
        panelDias.setBorder(BorderFactory.createTitledBorder(
                GestorIdioma.getString(KEY_PANEL_DAYS_TITLE)));

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
        for (DiaDTO dia : listaDias) {
            JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            JCheckBox chk = new JCheckBox(traducirNombreDia(dia.getNombre()) + ":");
            boolean esFinDeSemana = dia.getNombre().equalsIgnoreCase("Sábado") || dia.getNombre().equalsIgnoreCase("Domingo");
            chk.setSelected(!esFinDeSemana);
            checkboxesDia.put(dia.getIdDia(), chk);

            JCheckBox chkNocturno = new JCheckBox(GestorIdioma.getString(KEY_LABEL_NIGHT_SHIFT));
            chkNocturno.setToolTipText(GestorIdioma.getString(KEY_TOOLTIP_NIGHT_SHIFT));
            chkNocturno.setEnabled(!esFinDeSemana);
            checkboxesNocturno.put(dia.getIdDia(), chkNocturno);

            JTextField entrada = new JTextField("09:00", 5);
            JTextField salida = new JTextField("17:00", 5);
            JTextField descanso = new JTextField("0", 3);
            camposHoraEntrada.put(dia.getIdDia(), entrada);
            camposHoraSalida.put(dia.getIdDia(), salida);
            camposDescanso.put(dia.getIdDia(), descanso);

            FocusAdapter focusListener = new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent e) {
                    calcularTotalHorasSemanales();
                }
            };
            entrada.addFocusListener(focusListener);
            salida.addFocusListener(focusListener);
            descanso.addFocusListener(focusListener);

            chkNocturno.addItemListener(e -> calcularTotalHorasSemanales());

            chk.addItemListener(e -> {
                boolean sel = e.getStateChange() == ItemEvent.SELECTED;
                entrada.setEnabled(sel);
                salida.setEnabled(sel);
                descanso.setEnabled(sel);
                chkNocturno.setEnabled(sel);
                calcularTotalHorasSemanales();
            });

            p.add(chk);
            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_RANGE)));
            p.add(entrada);
            p.add(new JLabel("-"));
            p.add(salida);
            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_DAY_BREAK)));
            p.add(descanso);
            p.add(chkNocturno);
            panelDias.add(p);
        }

        JScrollPane scrollDias = new JScrollPane(panelDias);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnGuardar = new JButton(GestorIdioma.getString(KEY_BTN_SAVE));
        JButton btnCancelar = new JButton(GestorIdioma.getString(KEY_BTN_CANCEL));
        btnGuardar.addActionListener((ActionEvent e) -> guardarHorario());
        btnCancelar.addActionListener(e -> dispose());
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);
        panelPrincipal.add(scrollDias, BorderLayout.CENTER);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        setContentPane(panelPrincipal);
    }

    private void calcularTotalHorasSemanales() {
        double totalHoras = 0;
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");

        for (DiaDTO dia : listaDias) {
            JCheckBox chk = checkboxesDia.get(dia.getIdDia());
            if (chk.isSelected()) {
                JTextField ent = camposHoraEntrada.get(dia.getIdDia());
                JTextField sal = camposHoraSalida.get(dia.getIdDia());
                JTextField desc = camposDescanso.get(dia.getIdDia());
                JCheckBox chkNocturno = checkboxesNocturno.get(dia.getIdDia());

                try {
                    LocalTime horaEntrada = LocalTime.parse(ent.getText().trim(), fmt);
                    LocalTime horaSalida = LocalTime.parse(sal.getText().trim(), fmt);
                    int descansoMin = Integer.parseInt(desc.getText().trim());

                    LocalDate fecha = LocalDate.of(2000, 1, 1);
                    LocalDateTime entradaDT = LocalDateTime.of(fecha, horaEntrada);
                    LocalDateTime salidaDT;

                    if (horaSalida.isBefore(horaEntrada) || chkNocturno.isSelected()) {
                        salidaDT = LocalDateTime.of(fecha.plusDays(1), horaSalida);
                        chkNocturno.setSelected(true);
                    } else {
                        salidaDT = LocalDateTime.of(fecha, horaSalida);
                    }

                    Duration duracion = Duration.between(entradaDT, salidaDT);

                    double horasDia = duracion.toMinutes() / 60.0;
                    double horasEfectivas = horasDia - (descansoMin / 60.0);
                    totalHoras += Math.max(0, horasEfectivas);
                } catch (Exception e) {
                }
            }
        }

        lblTotalHoras.setText(String.format("%.1f", totalHoras));
        txtHorasMaxSemanales.setText(String.valueOf((int) Math.ceil(totalHoras)));
        lblTotalHoras.setForeground(totalHoras > 40 ? Color.RED : Color.BLACK);
    }


    private void cargarDatosHorario() {
        txtNombreHorario.setText(horario.getNombreHorario());
        txtHorasMaxSemanales.setText(String.valueOf(horario.getHorasMaxSemanales()));
        lblTotalHoras.setText(String.valueOf(horario.getHorasMaxSemanales()));

        listaDias.forEach(d -> {
            JCheckBox chk = checkboxesDia.get(d.getIdDia());
            JTextField ent = camposHoraEntrada.get(d.getIdDia());
            JTextField sal = camposHoraSalida.get(d.getIdDia());
            JTextField desc = camposDescanso.get(d.getIdDia());
            JCheckBox chkNocturno = checkboxesNocturno.get(d.getIdDia());

            chk.setSelected(false);
            ent.setEnabled(false);
            sal.setEnabled(false);
            desc.setEnabled(false);
            chkNocturno.setEnabled(false);
            chkNocturno.setSelected(false);
        });

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
        for (HorarioDiaTrabajoDTO dt : horario.getDiasTrabajo()) {
            JCheckBox chk = checkboxesDia.get(dt.getIdDia());
            JTextField ent = camposHoraEntrada.get(dt.getIdDia());
            JTextField sal = camposHoraSalida.get(dt.getIdDia());
            JTextField desc = camposDescanso.get(dt.getIdDia());
            JCheckBox chkNocturno = checkboxesNocturno.get(dt.getIdDia());

            if (dt.isActivo()) {
                chk.setSelected(true);
                ent.setEnabled(true);
                sal.setEnabled(true);
                desc.setEnabled(true);
                chkNocturno.setEnabled(true);

                boolean esNocturno = dt.getHoraSalida().isBefore(dt.getHoraEntrada());
                chkNocturno.setSelected(esNocturno);

                ent.setText(dt.getHoraEntrada().format(fmt));
                sal.setText(dt.getHoraSalida().format(fmt));
                desc.setText(String.valueOf(dt.getTiempoDescanso()));
            }
        }

        calcularTotalHorasSemanales();
    }

    private boolean verificarDescansoMinimo(List<HorarioDiaTrabajoDTO> dias) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");

        Map<Integer, HorarioDiaTrabajoDTO> diasMap = dias.stream()
                .filter(HorarioDiaTrabajoDTO::isActivo)
                .collect(Collectors.toMap(HorarioDiaTrabajoDTO::getIdDia, dto -> dto));

        if (diasMap.size() <= 1) {
            return true;
        }

        List<Integer> diasOrdenados = new ArrayList<>(diasMap.keySet());
        Collections.sort(diasOrdenados);

        for (int i = 0; i < diasOrdenados.size(); i++) {
            int idDiaActual = diasOrdenados.get(i);
            int idDiaSiguiente = (i < diasOrdenados.size() - 1) ?
                    diasOrdenados.get(i + 1) :
                    diasOrdenados.get(0);

            boolean sonConsecutivos = (idDiaSiguiente == idDiaActual + 1) ||
                    (idDiaActual == 7 && idDiaSiguiente == 1);

            if (sonConsecutivos) {
                HorarioDiaTrabajoDTO diaActual = diasMap.get(idDiaActual);
                HorarioDiaTrabajoDTO diaSiguiente = diasMap.get(idDiaSiguiente);

                LocalDate fechaBase = LocalDate.of(2023, 1, 2);

                LocalDate fechaActual = fechaBase.plusDays(idDiaActual - 1);
                LocalDate fechaSiguiente = fechaBase.plusDays(idDiaSiguiente - 1);

                if (fechaSiguiente.isBefore(fechaActual)) {
                    fechaSiguiente = fechaSiguiente.plusWeeks(1);
                }

                LocalDateTime finPrimerTurno = LocalDateTime.of(fechaActual, diaActual.getHoraSalida());
                LocalDateTime inicioSegundoTurno = LocalDateTime.of(fechaSiguiente, diaSiguiente.getHoraEntrada());

                if (diaActual.getHoraSalida().isBefore(diaActual.getHoraEntrada())) {
                    finPrimerTurno = finPrimerTurno.plusDays(1);
                }

                Duration descanso = Duration.between(finPrimerTurno, inicioSegundoTurno);
                long horasDescanso = descanso.toHours();


                if (horasDescanso < 12) {
                    JOptionPane.showMessageDialog(this,
                            GestorIdioma.getString(KEY_MSG_REST_PERIOD)
                                    + "\n" + GestorIdioma.getString(KEY_BETWEEN) + " "
                                    + traducirNombreDia(diaActual.getNombreDia()) + " (" + diaActual.getHoraSalida().format(fmt)
                                    + ") " + GestorIdioma.getString(KEY_AND) + " "
                                    + traducirNombreDia(diaSiguiente.getNombreDia()) + " (" + diaSiguiente.getHoraEntrada().format(fmt) + ")",
                            GestorIdioma.getString(KEY_DIALOG_WARNING),
                            JOptionPane.WARNING_MESSAGE);
                    return false;
                }
            }
        }

        return true;
    }


    private boolean esDiaConsecutivo(int idDia1, int idDia2) {

        if (idDia2 == idDia1 + 1) {
            return true;
        }

        if (idDia1 == 7 && idDia2 == 1) {
            return true;
        }
        return false;
    }

    private void guardarHorario() {
        try {
            if (txtNombreHorario.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_NAME_REQUIRED),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (horario == null) horario = new HorarioDTO();
            horario.setNombreHorario(txtNombreHorario.getText().trim());
            horario.setHorasMaxSemanales(Integer.parseInt(txtHorasMaxSemanales.getText()));

            List<HorarioDiaTrabajoDTO> dias = new ArrayList<>();
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");

            for (DiaDTO dia : listaDias) {
                JCheckBox chk = checkboxesDia.get(dia.getIdDia());
                JTextField ent = camposHoraEntrada.get(dia.getIdDia());
                JTextField sal = camposHoraSalida.get(dia.getIdDia());
                JTextField desc = camposDescanso.get(dia.getIdDia());
                JCheckBox chkNocturno = checkboxesNocturno.get(dia.getIdDia());

                HorarioDiaTrabajoDTO dto = new HorarioDiaTrabajoDTO();
                dto.setIdDia(dia.getIdDia());
                dto.setNombreDia(dia.getNombre());
                if (chk.isSelected()) {
                    try {
                        LocalTime tIn = LocalTime.parse(ent.getText().trim(), fmt);
                        LocalTime tOut = LocalTime.parse(sal.getText().trim(), fmt);
                        int descansoMin = Integer.parseInt(desc.getText().trim());

                        if (tOut.isBefore(tIn) && !chkNocturno.isSelected()) {
                            JOptionPane.showMessageDialog(this,
                                    GestorIdioma.getString(KEY_MSG_TIME_ORDER).replace("{0}", dia.getNombre()) +
                                            "\n" + GestorIdioma.getString(KEY_MSG_NIGHT_SHIFT_HINT),
                                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        LocalDate fecha = LocalDate.of(2000, 1, 1);
                        LocalDateTime iniDT = LocalDateTime.of(fecha, tIn);
                        LocalDateTime finDT = tOut.isBefore(tIn)
                                ? LocalDateTime.of(fecha.plusDays(1), tOut)
                                : LocalDateTime.of(fecha, tOut);
                        Duration dur = Duration.between(iniDT, finDT);

                        long minutosTotales = dur.toMinutes();
                        double horasDia = minutosTotales / 60.0;

                        if (minutosTotales > 8 * 60 && descansoMin < 30) {
                            JOptionPane.showMessageDialog(this,
                                    GestorIdioma.getString("JORN_MAS_8H") + traducirNombreDia(dia.getNombre()),
                                    GestorIdioma.getString(KEY_DIALOG_WARNING), JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                        if (minutosTotales > 6 * 60 && descansoMin < 15) {
                            JOptionPane.showMessageDialog(this,
                                    GestorIdioma.getString("JORN_MAS_6H") + traducirNombreDia(dia.getNombre()),
                                    GestorIdioma.getString(KEY_DIALOG_WARNING), JOptionPane.WARNING_MESSAGE);
                            return;
                        }


                        dto.setHoraEntrada(tIn);
                        dto.setHoraSalida(tOut);
                        dto.setTiempoDescanso(descansoMin);
                        dto.setActivo(true);
                    } catch (DateTimeParseException | NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this,
                                GestorIdioma.getString(KEY_MSG_TIME_FORMAT).replace("{0}", traducirNombreDia(dia.getNombre())),
                                GestorIdioma.getString(KEY_DIALOG_ERROR),
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } else {
                    dto.setHoraEntrada(LocalTime.of(0, 0));
                    dto.setHoraSalida(LocalTime.of(0, 0));
                    dto.setTiempoDescanso(0);
                    dto.setActivo(false);
                }
                dias.add(dto);
            }

            if (!verificarDescansoMinimo(dias)) return;

            horario.setDiasTrabajo(dias);
            boolean ok = horario.getIdHorario() == 0
                    ? controlador.crearHorario(horario)
                    : controlador.actualizarHorario(horario);

            if (ok) dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_SAVE_ERROR) + e.getMessage(),
                    GestorIdioma.getString(KEY_DIALOG_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String traducirNombreDia(String nombreDia) {
        String nombreDiaSinTildes = nombreDia
                .replace("á", "a")
                .replace("é", "e")
                .replace("í", "i")
                .replace("ó", "o")
                .replace("ú", "u")
                .replace("Á", "A")
                .replace("É", "E")
                .replace("Í", "I")
                .replace("Ó", "O")
                .replace("Ú", "U");

        return GestorIdioma.getString("DIA_" + nombreDiaSinTildes.toUpperCase());
    }

}