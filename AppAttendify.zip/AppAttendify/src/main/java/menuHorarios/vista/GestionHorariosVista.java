package menuHorarios.vista;

import menuHorarios.controlador.GestionHorariosControlador;
import modelo.HorarioDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class GestionHorariosVista extends JPanel {
    private static final String KEY_TITLE            = "GH_TITLE";
    private static final String KEY_COL_ID           = "GH_COL_ID";
    private static final String KEY_COL_NAME         = "GH_COL_NAME";
    private static final String KEY_COL_HOURS        = "GH_COL_HOURS";
    private static final String KEY_BTN_EDIT         = "GH_BTN_EDIT";
    private static final String KEY_BTN_DELETE       = "GH_BTN_DELETE";
    private static final String KEY_BTN_CREATE       = "GH_BTN_CREATE";
    private static final String KEY_BTN_BACK         = "GH_BTN_BACK";
    private static final String KEY_MSG_LOAD_ERROR   = "GH_MSG_LOAD_ERROR";
    private static final String KEY_DIALOG_ERROR     = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOG_CONFIRM   = "DIALOGO_TITULO_CONFIRMAR";

    private GestionHorariosControlador controlador;
    private JTable tablaHorarios;
    private DefaultTableModel modeloTabla;
    private JButton btnCrearHorario, btnVolver;

    public GestionHorariosVista() {
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        JPanel panelNorte = new JPanel();
        JLabel lblTitulo = new JLabel(GestorIdioma.getString(KEY_TITLE));
        lblTitulo.setFont(new Font("Dialog", Font.BOLD, 18));
        panelNorte.add(lblTitulo);
        add(panelNorte, BorderLayout.NORTH);

        String[] cols = {
                GestorIdioma.getString(KEY_COL_ID),
                GestorIdioma.getString(KEY_COL_NAME),
                GestorIdioma.getString(KEY_COL_HOURS),
                GestorIdioma.getString(KEY_BTN_EDIT),
                GestorIdioma.getString(KEY_BTN_DELETE)
        };
        modeloTabla = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){
                return c>=3;
            }
            @Override public Class<?> getColumnClass(int c){ return String.class;}
        };
        tablaHorarios = new JTable(modeloTabla);

        int[] w={40,150,100,80,80};
        for(int i=0;i<w.length;i++){
            tablaHorarios.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
        }
        tablaHorarios.getColumnModel().getColumn(0).setMinWidth(0);
        tablaHorarios.getColumnModel().getColumn(0).setMaxWidth(0);
        tablaHorarios.getColumnModel().getColumn(0).setWidth(0);

        JTableHeader header = tablaHorarios.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD));
        header.setBackground(new Color(220,220,220));

        tablaHorarios.getColumnModel().getColumn(3)
                .setCellRenderer(new BotonRenderer(GestorIdioma.getString(KEY_BTN_EDIT)));
        tablaHorarios.getColumnModel().getColumn(4)
                .setCellRenderer(new BotonRenderer(GestorIdioma.getString(KEY_BTN_DELETE)));

        tablaHorarios.addMouseListener(new MouseAdapter(){
            @Override public void mouseClicked(MouseEvent e){
                int row = tablaHorarios.rowAtPoint(e.getPoint());
                int col = tablaHorarios.columnAtPoint(e.getPoint());
                if(row<0) return;
                int id = (int)tablaHorarios.getValueAt(row,0);
                if(col==3){
                    try{
                        HorarioDTO h = controlador.obtenerHorarioPorId(id);
                        if(h!=null) mostrarFormularioHorario(h);
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null,
                                GestorIdioma.getString(KEY_MSG_LOAD_ERROR)+ex.getMessage(),
                                GestorIdioma.getString(KEY_DIALOG_ERROR),
                                JOptionPane.ERROR_MESSAGE);
                    }
                } else if(col==4){
                    String nombre = tablaHorarios.getValueAt(row,1).toString();
                    if(JOptionPane.showConfirmDialog(null,
                            GestorIdioma.getString(KEY_BTN_DELETE)+" "+nombre+"?",
                            GestorIdioma.getString(KEY_DIALOG_CONFIRM),
                            JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                        controlador.eliminarHorario(id);
                    }
                }
            }
        });

        add(new JScrollPane(tablaHorarios), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnCrearHorario = new JButton(GestorIdioma.getString(KEY_BTN_CREATE));
        btnVolver        = new JButton(GestorIdioma.getString(KEY_BTN_BACK));
        btnCrearHorario.addActionListener((ActionEvent e)-> mostrarFormularioHorario(null));
        btnVolver.addActionListener(e-> controlador.volverMenuPrincipal());
        panelBotones.add(btnCrearHorario);
        panelBotones.add(btnVolver);
        add(panelBotones, BorderLayout.SOUTH);
    }

    public void setControlador(GestionHorariosControlador controlador){
        this.controlador = controlador;
    }

    public void actualizarTablaHorarios(List<HorarioDTO> list){
        modeloTabla.setRowCount(0);
        list.forEach(h -> modeloTabla.addRow(new Object[]{
                h.getIdHorario(),
                h.getNombreHorario(),
                h.getHorasMaxSemanales(),
                GestorIdioma.getString(KEY_BTN_EDIT),
                GestorIdioma.getString(KEY_BTN_DELETE)
        }));
        tablaHorarios.setRowHeight(30);
    }

    private void mostrarFormularioHorario(HorarioDTO horario){
        FormularioHorarioVista form = new FormularioHorarioVista(controlador, horario);
        form.setVisible(true);
    }

    class BotonRenderer extends JButton implements TableCellRenderer {
        public BotonRenderer(String txt){
            setText(txt);
            setOpaque(true);
        }
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c){
            return this;
        }
    }
}