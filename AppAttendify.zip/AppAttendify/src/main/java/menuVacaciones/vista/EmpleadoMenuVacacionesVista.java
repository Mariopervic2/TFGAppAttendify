package menuVacaciones.vista;

import menuVacaciones.controlador.EmpleadoMenuVacacionesControlador;
import modelo.DiaFestivoDTO;
import modelo.VacacionesDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class EmpleadoMenuVacacionesVista extends JFrame {
    private static final String KEY_MES_LABEL = "VACACIONES_LABEL_MES";
    private static final String KEY_ANO_LABEL = "VACACIONES_LABEL_ANO";
    private static final String KEY_COL_FECHA = "VACACIONES_COL_FECHA";
    private static final String KEY_COL_TIPO = "VACACIONES_COL_TIPO";
    private static final String KEY_COL_DESCRIPCION = "VACACIONES_COL_DESCRIPCION";
    private static final String KEY_TIPO_FESTIVO = "VACACIONES_TIPO_FESTIVO";
    private static final String KEY_TIPO_VACACIONES = "VACACIONES_TIPO_VACACIONES";
    private static final String KEY_RANGO_A = "VACACIONES_RANGO_A";
    private static final String KEY_ERROR_TITULO = "DIALOGO_TITULO_ERROR";

    private JComboBox<String> cbMes;
    private JComboBox<String> cbAno;
    private JTable tabla;
    private DefaultTableModel modelo;
    private EmpleadoMenuVacacionesControlador controller;

    public EmpleadoMenuVacacionesVista() {
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        actualizarTextos();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        JPanel panelFiltros = new JPanel();
        cbMes = new JComboBox<>();
        cbAno = new JComboBox<>();
        panelFiltros.add(new JLabel());
        panelFiltros.add(cbMes);
        panelFiltros.add(new JLabel());
        panelFiltros.add(cbAno);

        modelo = new DefaultTableModel(
                new Object[]{"", "", ""}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        tabla = new JTable(modelo);
        tabla.setDefaultRenderer(Object.class, new FechaCellRenderer());
        JScrollPane scroll = new JScrollPane(tabla);

        getContentPane().setLayout(new BorderLayout(5, 5));
        getContentPane().add(panelFiltros, BorderLayout.NORTH);
        getContentPane().add(scroll, BorderLayout.CENTER);
    }

    private void actualizarTextos() {
        JPanel panelFiltros = (JPanel) getContentPane().getComponent(0);
        ((JLabel) panelFiltros.getComponent(0)).setText(GestorIdioma.getString(KEY_MES_LABEL));
        ((JLabel) panelFiltros.getComponent(2)).setText(GestorIdioma.getString(KEY_ANO_LABEL));

        tabla.getColumnModel().getColumn(0).setHeaderValue(GestorIdioma.getString(KEY_COL_FECHA));
        tabla.getColumnModel().getColumn(1).setHeaderValue(GestorIdioma.getString(KEY_COL_TIPO));
        tabla.getColumnModel().getColumn(2).setHeaderValue(GestorIdioma.getString(KEY_COL_DESCRIPCION));
        tabla.getTableHeader().repaint();
    }

    public void setController(EmpleadoMenuVacacionesControlador controller) {
        this.controller = controller;
        ItemListener reloadListener = e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                controller.recargarDatos();
            }
        };
        cbMes.addItemListener(reloadListener);
        cbAno.addItemListener(reloadListener);
    }

    public void llenarComboMes() {
        Locale loc = GestorIdioma.getCurrentLocale();
        DateTimeFormatter fmtMes = DateTimeFormatter.ofPattern("MMMM", loc);
        cbMes.removeAllItems();

        for (int m = 1; m <= 12; m++) {
            String nombreMes = fmtMes.format(LocalDate.of(2000, m, 1));
            nombreMes = nombreMes.substring(0, 1).toUpperCase() + nombreMes.substring(1);
            cbMes.addItem(nombreMes);
        }

        cbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
    }

    public void llenarComboAno(List<Integer> anos) {
        cbAno.removeAllItems();
        for (Integer a : anos) {
            cbAno.addItem(a.toString());
        }
        String actual = String.valueOf(LocalDate.now().getYear());
        if (anos.contains(LocalDate.now().getYear())) {
            cbAno.setSelectedItem(actual);
        } else if (!anos.isEmpty()) {
            cbAno.setSelectedIndex(0);
        }
    }

    public int getMesSeleccionado() {
        int idx = cbMes.getSelectedIndex();
        return idx < 0 ? LocalDate.now().getMonthValue() : idx + 1;
    }

    public int getAnoSeleccionado() {
        Object sel = cbAno.getSelectedItem();
        if (sel == null) return LocalDate.now().getYear();
        try {
            return Integer.parseInt(sel.toString());
        } catch (NumberFormatException e) {
            return LocalDate.now().getYear();
        }
    }

    public void actualizarTabla(List<DiaFestivoDTO> festivos, List<VacacionesDTO> vacaciones) {
        modelo.setRowCount(0);
        festivos.forEach(f ->
                modelo.addRow(new Object[]{
                        f.getFecha().toString(),
                        GestorIdioma.getString(KEY_TIPO_FESTIVO),
                        f.getNombre()
                })
        );
        vacaciones.forEach(v -> {
            String rango = v.getFechaInicio().toString()
                    + " " + GestorIdioma.getString(KEY_RANGO_A) + " "
                    + v.getFechaFin().toString();
            modelo.addRow(new Object[]{
                    rango,
                    GestorIdioma.getString(KEY_TIPO_VACACIONES),
                    v.getDescripcion()
            });
        });
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                GestorIdioma.getString(KEY_ERROR_TITULO),
                JOptionPane.ERROR_MESSAGE
        );
    }

    private class FechaCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int col) {
            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, col
            );
            if (col == 0 && value instanceof String) {
                String texto = (String) value;
                LocalDate fechaFinal;
                String sep = " " + GestorIdioma.getString(KEY_RANGO_A) + " ";
                if (texto.contains(sep)) {
                    String fin = texto.substring(texto.indexOf(sep) + sep.length());
                    fechaFinal = LocalDate.parse(fin);
                } else {
                    fechaFinal = LocalDate.parse(texto);
                }
                if (fechaFinal.isBefore(LocalDate.now())) {
                    c.setForeground(Color.RED);
                } else {
                    c.setForeground(new Color(100, 150, 255));
                }
                setText(texto);
            } else {
                c.setForeground(Color.BLACK);
            }
            return c;
        }
    }
}
