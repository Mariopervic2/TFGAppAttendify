package menuVacaciones.vista;

import menuVacaciones.controlador.GestionFestivosVacacionesControlador;
import modelo.DiaFestivoDTO;
import modelo.EmpleadoDTO;
import modelo.VacacionesDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class GestionFestivosVacacionesVista extends JPanel {
    private static final long serialVersionUID = 1L;

    private static final String KEY_TITULO_MENU = "GFV_TITULO_MENU";
    private static final String KEY_BTN_FESTIVOS = "GFV_BTN_FESTIVOS";
    private static final String KEY_BTN_VACACIONES = "GFV_BTN_VACACIONES";
    private static final String KEY_BTN_REGRESAR = "GFV_BTN_REGRESAR";

    private static final String KEY_PANEL_TIT_FESTIVOS = "GFV_PANEL_FESTIVOS_TIT";
    private static final String[] KEYS_COL_F = {
            "GFV_COL_F_ID", "GFV_COL_F_FECHA", "GFV_COL_F_NOMBRE"
    };
    private static final String KEY_LABEL_F_FECHA = "GFV_LABEL_F_FECHA";
    private static final String KEY_LABEL_F_NOMBRE = "GFV_LABEL_F_NOMBRE";
    private static final String KEY_BTN_F_AGREGAR = "GFV_BTN_F_AGREGAR";
    private static final String KEY_BTN_F_EDITAR = "GFV_BTN_F_EDITAR";
    private static final String KEY_BTN_F_ELIMINAR = "GFV_BTN_F_ELIMINAR";
    private static final String KEY_BTN_F_VOLVER = "GFV_BTN_F_VOLVER";

    private static final String KEY_PANEL_TIT_VACACIONES = "GFV_PANEL_VAC_TIT";
    private static final String[] KEYS_COL_V = {
            "GFV_COL_V_ID", "GFV_COL_V_EMPLEADO", "GFV_COL_V_FI",
            "GFV_COL_V_FF", "GFV_COL_V_DESC"
    };
    private static final String KEY_LABEL_V_EMPLEADO = "GFV_LABEL_V_EMPLEADO";
    private static final String KEY_LABEL_V_FI = "GFV_LABEL_V_FI";
    private static final String KEY_LABEL_V_FF = "GFV_LABEL_V_FF";
    private static final String KEY_LABEL_V_DESC = "GFV_LABEL_V_DESC";
    private static final String KEY_BTN_V_AGREGAR = "GFV_BTN_V_AGREGAR";
    private static final String KEY_BTN_V_EDITAR = "GFV_BTN_V_EDITAR";
    private static final String KEY_BTN_V_ELIMINAR = "GFV_BTN_V_ELIMINAR";
    private static final String KEY_BTN_V_VOLVER = "GFV_BTN_V_VOLVER";

    private static final String KEY_MSG_ERROR_COMPLETAR = "GFV_MSG_ERROR_COMPLETAR";
    private static final String KEY_MSG_ERROR_FECHA_FORMATO = "GFV_MSG_ERROR_FECHA_FORMATO";
    private static final String KEY_MSG_ERROR_FECHA_ORDEN = "GFV_MSG_ERROR_FECHA_ORDEN";
    private static final String KEY_MSG_ERROR_SELEC_F = "GFV_MSG_ERROR_SELEC_F";
    private static final String KEY_MSG_ERROR_SELEC_V = "GFV_MSG_ERROR_SELEC_V";
    private static final String KEY_MSG_ERROR_SELEC_EMP = "GFV_MSG_ERROR_SELEC_EMP";

    private static final String KEY_MSG_SUCCESS_F_AGREGAR = "GFV_MSG_SUCCESS_F_AGREGAR";
    private static final String KEY_MSG_SUCCESS_F_EDITAR = "GFV_MSG_SUCCESS_F_EDITAR";
    private static final String KEY_MSG_SUCCESS_F_ELIMINAR = "GFV_MSG_SUCCESS_F_ELIMINAR";
    private static final String KEY_MSG_CONFIRM_F_ELIMINAR = "GFV_MSG_CONFIRM_F_ELIMINAR";

    private static final String KEY_MSG_SUCCESS_V_AGREGAR = "GFV_MSG_SUCCESS_V_AGREGAR";
    private static final String KEY_MSG_SUCCESS_V_EDITAR = "GFV_MSG_SUCCESS_V_EDITAR";
    private static final String KEY_MSG_SUCCESS_V_ELIMINAR = "GFV_MSG_SUCCESS_V_ELIMINAR";

    private static final String KEY_DIALOGO_TITULO_ERROR = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOGO_TITULO_INFO = "DIALOGO_TITULO_INFO";
    private static final String KEY_DIALOGO_TITULO_CONFIRMAR = "DIALOGO_TITULO_CONFIRMAR";

    private GestionFestivosVacacionesControlador controller;
    private JPanel panelPrincipal;
    private CardLayout cardLayout;
    private JPanel panelMenu, panelFestivos, panelVacaciones;

    private JTable tablaFestivos;
    private DefaultTableModel modeloTablaFestivos;
    private JTextField txtFechaFestivo, txtNombreFestivo;
    private JComboBox<String> comboAnoF, comboMesF;
    private TableRowSorter<DefaultTableModel> sorterFest;

    private JTable tablaVacaciones;
    private DefaultTableModel modeloTablaVacaciones;
    private JComboBox<EmpleadoDTO> comboEmpleados;
    private JTextField txtFechaInicio, txtFechaFin, txtDescripcion;
    private JComboBox<String> comboAnoV, comboMesV;
    private JTextField txtBuscarEmpleado;
    private TableRowSorter<DefaultTableModel> sorterVac;

    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public GestionFestivosVacacionesVista(GestionFestivosVacacionesControlador controller) {
        this.controller = controller;
        configurarPanelPrincipal();
        configurarPanelMenu();
        configurarPanelFestivos();
        configurarPanelVacaciones();
        addAncestorListener(new AncestorListener() {
            @Override
            public void ancestorAdded(AncestorEvent e) {
            }

            @Override
            public void ancestorMoved(AncestorEvent e) {
            }

            @Override
            public void ancestorRemoved(AncestorEvent e) {
                controller.cerrarConexiones();
            }
        });
        cardLayout.show(panelPrincipal, "menu");
    }

    private void configurarPanelPrincipal() {
        setLayout(new BorderLayout());
        panelPrincipal = new JPanel(cardLayout = new CardLayout());
        panelMenu = new JPanel();
        panelFestivos = new JPanel();
        panelVacaciones = new JPanel();
        panelPrincipal.add(panelMenu, "menu");
        panelPrincipal.add(panelFestivos, "festivos");
        panelPrincipal.add(panelVacaciones, "vacaciones");
        add(panelPrincipal, BorderLayout.CENTER);
    }

    private void configurarPanelMenu() {
        panelMenu.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lblTitulo = new JLabel(GestorIdioma.getString(KEY_TITULO_MENU));
        lblTitulo.setFont(lblTitulo.getFont().deriveFont(20f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 0, 40, 0);
        panelMenu.add(lblTitulo, gbc);

        JButton btnFest = new JButton(GestorIdioma.getString(KEY_BTN_FESTIVOS));
        btnFest.setPreferredSize(new Dimension(250, 60));
        btnFest.setHorizontalAlignment(SwingConstants.LEFT);
        btnFest.addActionListener(e -> cardLayout.show(panelPrincipal, "festivos"));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panelMenu.add(btnFest, gbc);

        JButton btnVac = new JButton(GestorIdioma.getString(KEY_BTN_VACACIONES));
        btnVac.setPreferredSize(new Dimension(250, 60));
        btnVac.setHorizontalAlignment(SwingConstants.LEFT);
        btnVac.addActionListener(e -> cardLayout.show(panelPrincipal, "vacaciones"));
        gbc.gridx = 1;
        gbc.gridy = 1;
        panelMenu.add(btnVac, gbc);

        JButton btnReg = new JButton(GestorIdioma.getString(KEY_BTN_REGRESAR));
        btnReg.setPreferredSize(new Dimension(250, 40));
        btnReg.addActionListener(e -> controller.regresarPanelAnterior());
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(40, 0, 20, 0);
        panelMenu.add(btnReg, gbc);
    }

    private void
    configurarPanelFestivos() {
        panelFestivos.setLayout(new BorderLayout(10, 10));
        panelFestivos.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel pFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboAnoF = new JComboBox<>();
        comboMesF = new JComboBox<>();
        comboAnoF.addItem("Todos");
        for (int a = 2000; a <= 2100; a++) comboAnoF.addItem(String.valueOf(a));
        comboMesF.addItem("Todos");
        for (int m = 1; m <= 12; m++) comboMesF.addItem(String.format("%02d", m));
        pFiltros.add(new JLabel("Año:"));
        pFiltros.add(comboAnoF);
        pFiltros.add(new JLabel("Mes:"));
        pFiltros.add(comboMesF);
        panelFestivos.add(pFiltros, BorderLayout.NORTH);

        JPanel pTabla = new JPanel(new BorderLayout(5, 5));
        pTabla.setBorder(BorderFactory.createTitledBorder(
                GestorIdioma.getString(KEY_PANEL_TIT_FESTIVOS)));
        modeloTablaFestivos = new DefaultTableModel(
                new Object[]{
                        GestorIdioma.getString(KEYS_COL_F[0]),
                        GestorIdioma.getString(KEYS_COL_F[1]),
                        GestorIdioma.getString(KEYS_COL_F[2])
                }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tablaFestivos = new JTable(modeloTablaFestivos);
        tablaFestivos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaFestivos.removeColumn(tablaFestivos.getColumnModel().getColumn(0));

        JTableHeader hFest = tablaFestivos.getTableHeader();
        hFest.setFont(hFest.getFont().deriveFont(Font.BOLD));
        hFest.setBackground(new Color(220, 220, 220));
        pTabla.add(new JScrollPane(tablaFestivos), BorderLayout.CENTER);
        panelFestivos.add(pTabla, BorderLayout.CENTER);

        sorterFest = new TableRowSorter<>(modeloTablaFestivos);
        tablaFestivos.setRowSorter(sorterFest);
        ActionListener actFest = e -> sorterFest.setRowFilter(crearFiltroFestivos());
        comboAnoF.addActionListener(actFest);
        comboMesF.addActionListener(actFest);

        JPanel pForm = new JPanel(new GridBagLayout());
        pForm.setBorder(BorderFactory.createTitledBorder(
                GestorIdioma.getString(KEY_PANEL_TIT_FESTIVOS)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_F_FECHA)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtFechaFestivo = new JTextField(15);
        pForm.add(txtFechaFestivo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_F_NOMBRE)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtNombreFestivo = new JTextField(30);
        pForm.add(txtNombreFestivo, gbc);

        JPanel pButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton bAdd = new JButton(GestorIdioma.getString(KEY_BTN_F_AGREGAR));
        bAdd.addActionListener(e -> agregarFestivo());
        JButton bEdit = new JButton(GestorIdioma.getString(KEY_BTN_F_EDITAR));
        bEdit.addActionListener(e -> editarFestivo());
        JButton bDel = new JButton(GestorIdioma.getString(KEY_BTN_F_ELIMINAR));
        bDel.addActionListener(e -> eliminarFestivo());
        pButtons.add(bAdd);
        pButtons.add(bEdit);
        pButtons.add(bDel);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        pForm.add(pButtons, gbc);

        JPanel pSur = new JPanel(new BorderLayout(5, 5));
        pSur.add(pForm, BorderLayout.CENTER);
        JPanel pNav = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton bBack = new JButton(GestorIdioma.getString(KEY_BTN_F_VOLVER));
        bBack.addActionListener(e -> cardLayout.show(panelPrincipal, "menu"));
        pNav.add(bBack);
        pSur.add(pNav, BorderLayout.SOUTH);
        panelFestivos.add(pSur, BorderLayout.SOUTH);

        tablaFestivos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaFestivos.getSelectedRow() >= 0) {
                int row = tablaFestivos.getSelectedRow();
                int modelRow = tablaFestivos.convertRowIndexToModel(row);
                String fecha = (String) modeloTablaFestivos.getValueAt(modelRow, 1);
                String nombre = (String) modeloTablaFestivos.getValueAt(modelRow, 2);
                txtFechaFestivo.setText(fecha);
                txtNombreFestivo.setText(nombre);
            }
        });

    }

    private void configurarPanelVacaciones() {
        panelVacaciones.setLayout(new BorderLayout(10, 10));
        panelVacaciones.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel pFiltrosV = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboAnoV = new JComboBox<>();
        comboMesV = new JComboBox<>();
        comboAnoV.addItem("Todos");
        for (int a = 2000; a <= 2100; a++) comboAnoV.addItem(String.valueOf(a));
        comboMesV.addItem("Todos");
        for (int m = 1; m <= 12; m++) comboMesV.addItem(String.format("%02d", m));
        txtBuscarEmpleado = new JTextField(15);
        pFiltrosV.add(new JLabel("Año:"));
        pFiltrosV.add(comboAnoV);
        pFiltrosV.add(new JLabel("Mes:"));
        pFiltrosV.add(comboMesV);
        pFiltrosV.add(new JLabel(GestorIdioma.getString("EMPLEADO")));
        pFiltrosV.add(txtBuscarEmpleado);
        panelVacaciones.add(pFiltrosV, BorderLayout.NORTH);

        JPanel pTabla = new JPanel(new BorderLayout(5, 5));
        pTabla.setBorder(BorderFactory.createTitledBorder(
                GestorIdioma.getString(KEY_PANEL_TIT_VACACIONES)));
        modeloTablaVacaciones = new DefaultTableModel(
                new Object[]{
                        GestorIdioma.getString(KEYS_COL_V[0]),
                        GestorIdioma.getString(KEYS_COL_V[1]),
                        GestorIdioma.getString(KEYS_COL_V[2]),
                        GestorIdioma.getString(KEYS_COL_V[3]),
                        GestorIdioma.getString(KEYS_COL_V[4])
                }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tablaVacaciones = new JTable(modeloTablaVacaciones);
        tablaVacaciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaVacaciones.removeColumn(tablaVacaciones.getColumnModel().getColumn(0));

        JTableHeader hVac = tablaVacaciones.getTableHeader();
        hVac.setFont(hVac.getFont().deriveFont(Font.BOLD));
        hVac.setBackground(new Color(220, 220, 220));
        pTabla.add(new JScrollPane(tablaVacaciones), BorderLayout.CENTER);
        panelVacaciones.add(pTabla, BorderLayout.CENTER);

        sorterVac = new TableRowSorter<>(modeloTablaVacaciones);
        tablaVacaciones.setRowSorter(sorterVac);
        ActionListener actVac = e -> sorterVac.setRowFilter(crearFiltroVacaciones());
        comboAnoV.addActionListener(actVac);
        comboMesV.addActionListener(actVac);
        txtBuscarEmpleado.getDocument().addDocumentListener(new DocumentListener() {
            public void any(DocumentEvent e) {
                sorterVac.setRowFilter(crearFiltroVacaciones());
            }

            public void insertUpdate(DocumentEvent e) {
                any(e);
            }

            public void removeUpdate(DocumentEvent e) {
                any(e);
            }

            public void changedUpdate(DocumentEvent e) {
                any(e);
            }
        });

        JPanel pForm = new JPanel(new GridBagLayout());
        pForm.setBorder(BorderFactory.createTitledBorder(
                GestorIdioma.getString(KEY_PANEL_TIT_VACACIONES)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_V_EMPLEADO)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        comboEmpleados = new JComboBox<>();
        pForm.add(comboEmpleados, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_V_FI)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtFechaInicio = new JTextField(15);
        pForm.add(txtFechaInicio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_V_FF)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtFechaFin = new JTextField(15);
        pForm.add(txtFechaFin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.NONE;
        pForm.add(new JLabel(GestorIdioma.getString(KEY_LABEL_V_DESC)), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtDescripcion = new JTextField(30);
        pForm.add(txtDescripcion, gbc);

        JPanel pButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton bAddV = new JButton(GestorIdioma.getString(KEY_BTN_V_AGREGAR));
        bAddV.addActionListener(e -> agregarVacaciones());
        JButton bEditV = new JButton(GestorIdioma.getString(KEY_BTN_V_EDITAR));
        bEditV.addActionListener(e -> editarVacaciones());
        JButton bDelV = new JButton(GestorIdioma.getString(KEY_BTN_V_ELIMINAR));
        bDelV.addActionListener(e -> eliminarVacaciones());
        pButtons.add(bAddV);
        pButtons.add(bEditV);
        pButtons.add(bDelV);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        pForm.add(pButtons, gbc);

        JPanel pSur = new JPanel(new BorderLayout(5, 5));
        pSur.add(pForm, BorderLayout.CENTER);
        JPanel pNav = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton bBackV = new JButton(GestorIdioma.getString(KEY_BTN_V_VOLVER));
        bBackV.addActionListener(e -> cardLayout.show(panelPrincipal, "menu"));
        pNav.add(bBackV);
        pSur.add(pNav, BorderLayout.SOUTH);
        panelVacaciones.add(pSur, BorderLayout.SOUTH);

        tablaVacaciones.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaVacaciones.getSelectedRow() >= 0) {
                int row = tablaVacaciones.getSelectedRow();
                int modelRow = tablaVacaciones.convertRowIndexToModel(row);
                String empleadoNombre = (String) modeloTablaVacaciones.getValueAt(modelRow, 1);
                String fechaInicio = (String) modeloTablaVacaciones.getValueAt(modelRow, 2);
                String fechaFin = (String) modeloTablaVacaciones.getValueAt(modelRow, 3);
                String descripcion = (String) modeloTablaVacaciones.getValueAt(modelRow, 4);

                txtFechaInicio.setText(fechaInicio);
                txtFechaFin.setText(fechaFin);
                txtDescripcion.setText(descripcion);

                for (int i = 0; i < comboEmpleados.getItemCount(); i++) {
                    EmpleadoDTO emp = comboEmpleados.getItemAt(i);
                    if (emp.getNombreCompleto().equals(empleadoNombre)) {
                        comboEmpleados.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });
    }

    private static final String KEY_FILTRO_TODOS = "FILTRO_TODOS";


    private RowFilter<DefaultTableModel, Integer> crearFiltroFestivos() {
        String selAno = (String) comboAnoF.getSelectedItem();
        String selMes = (String) comboMesF.getSelectedItem();
        String todosTxt = GestorIdioma.getString(KEY_FILTRO_TODOS);

        return new RowFilter<>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                String fecha = (String) entry.getValue(1);
                try {
                    LocalDate d = LocalDate.parse(fecha, formatter);
                    if (!todosTxt.equals(selAno) && selAno != null) {
                        try {
                            if (d.getYear() != Integer.parseInt(selAno)) return false;
                        } catch (NumberFormatException e) {
                        }
                    }

                    if (!todosTxt.equals(selMes) && selMes != null) {
                        try {
                            if (d.getMonthValue() != Integer.parseInt(selMes)) return false;
                        } catch (NumberFormatException e) {
                        }
                    }
                    return true;
                } catch (DateTimeParseException ex) {
                    return false;
                }
            }
        };
    }


    private RowFilter<DefaultTableModel, Integer> crearFiltroVacaciones() {
        String selAno = (String) comboAnoV.getSelectedItem();
        String selMes = (String) comboMesV.getSelectedItem();
        String todosTxt = GestorIdioma.getString(KEY_FILTRO_TODOS);
        String texto = txtBuscarEmpleado.getText().trim().toLowerCase();

        return new RowFilter<>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                String fechaInicio = (String) entry.getValue(2);
                String nombre = entry.getValue(1).toString().toLowerCase();
                try {
                    LocalDate d = LocalDate.parse(fechaInicio, formatter);
                    if (!todosTxt.equals(selAno) && selAno != null) {
                        try {
                            if (d.getYear() != Integer.parseInt(selAno)) return false;
                        } catch (NumberFormatException e) {
                        }
                    }

                    if (!todosTxt.equals(selMes) && selMes != null) {
                        try {
                            if (d.getMonthValue() != Integer.parseInt(selMes)) return false;
                        } catch (NumberFormatException e) {
                        }
                    }

                    if (!texto.isEmpty() && !nombre.contains(texto)) return false;
                    return true;
                } catch (DateTimeParseException ex) {
                    return false;
                }
            }
        };
    }

    private void agregarFestivo() {
        String f = txtFechaFestivo.getText().trim();
        String n = txtNombreFestivo.getText().trim();
        if (f.isEmpty() || n.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_COMPLETAR),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            LocalDate fecha = LocalDate.parse(f, formatter);
            DiaFestivoDTO dto = new DiaFestivoDTO();
            dto.setFecha(fecha);
            dto.setNombre(n);
            if (controller.agregarFestivo(dto)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_F_AGREGAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaFestivos();
                txtFechaFestivo.setText("");
                txtNombreFestivo.setText("");
            }
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_FECHA_FORMATO),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editarFestivo() {
        int row = tablaFestivos.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_SELEC_F),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int id = (int) modeloTablaFestivos.getValueAt(row, 0);
            LocalDate fecha = LocalDate.parse(txtFechaFestivo.getText().trim(), formatter);
            String n = txtNombreFestivo.getText().trim();
            if (n.isEmpty()) throw new IllegalArgumentException();
            DiaFestivoDTO dto = new DiaFestivoDTO();
            dto.setIdFestivo(id);
            dto.setFecha(fecha);
            dto.setNombre(n);
            if (controller.actualizarFestivo(dto)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_F_EDITAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaFestivos();
                txtFechaFestivo.setText("");
                txtNombreFestivo.setText("");
            }
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_FECHA_FORMATO),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarFestivo() {
        int row = tablaFestivos.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_SELEC_F),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JOptionPane.showConfirmDialog(this,
                GestorIdioma.getString(KEY_MSG_CONFIRM_F_ELIMINAR),
                GestorIdioma.getString(KEY_DIALOGO_TITULO_CONFIRMAR),
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int id = (int) modeloTablaFestivos.getValueAt(row, 0);
            if (controller.eliminarFestivo(id)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_F_ELIMINAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaFestivos();
            }
        }
    }

    public void actualizarTablaFestivos() {
        modeloTablaFestivos.setRowCount(0);
        controller.obtenerTodosFestivos().forEach(f ->
                modeloTablaFestivos.addRow(new Object[]{
                        f.getIdFestivo(),
                        f.getFecha().format(formatter),
                        f.getNombre()
                })
        );
        sorterFest.setRowFilter(crearFiltroFestivos());
    }

    private void agregarVacaciones() {
        if (comboEmpleados.getSelectedIndex() < 0) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_SELEC_EMP),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        String fi = txtFechaInicio.getText().trim();
        String ff = txtFechaFin.getText().trim();
        String desc = txtDescripcion.getText().trim();
        if (fi.isEmpty() || ff.isEmpty() || desc.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_COMPLETAR),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            LocalDate inicio = LocalDate.parse(fi, formatter);
            LocalDate fin = LocalDate.parse(ff, formatter);
            if (inicio.isAfter(fin)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_ERROR_FECHA_ORDEN),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            EmpleadoDTO emp = (EmpleadoDTO) comboEmpleados.getSelectedItem();
            VacacionesDTO dto = new VacacionesDTO();
            dto.setIdEmpleado(emp.getIdEmpleado());
            dto.setNombreEmpleado(emp.getNombreCompleto());
            dto.setFechaInicio(inicio);
            dto.setFechaFin(fin);
            dto.setDescripcion(desc);
            if (controller.agregarVacaciones(dto)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_V_AGREGAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaVacaciones();
                txtFechaInicio.setText("");
                txtFechaFin.setText("");
                txtDescripcion.setText("");
            }
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_FECHA_FORMATO),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editarVacaciones() {
        int row = tablaVacaciones.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_SELEC_V),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            LocalDate fi = LocalDate.parse(txtFechaInicio.getText().trim(), formatter);
            LocalDate ff = LocalDate.parse(txtFechaFin.getText().trim(), formatter);
            if (fi.isAfter(ff)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_ERROR_FECHA_ORDEN),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            EmpleadoDTO emp = (EmpleadoDTO) comboEmpleados.getSelectedItem();
            int id = (int) modeloTablaVacaciones.getValueAt(row, 0);
            VacacionesDTO dto = new VacacionesDTO();
            dto.setIdVacaciones(id);
            dto.setIdEmpleado(emp.getIdEmpleado());
            dto.setNombreEmpleado(emp.getNombreCompleto());
            dto.setFechaInicio(fi);
            dto.setFechaFin(ff);
            dto.setDescripcion(txtDescripcion.getText().trim());
            if (controller.actualizarVacaciones(dto)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_V_EDITAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaVacaciones();
            }
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_FECHA_FORMATO),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarVacaciones() {
        int row = tablaVacaciones.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString(KEY_MSG_ERROR_SELEC_V),
                    GestorIdioma.getString(KEY_DIALOGO_TITULO_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JOptionPane.showConfirmDialog(this,
                GestorIdioma.getString(KEY_MSG_CONFIRM_F_ELIMINAR).replace("festivo", "periodo vacacional"),
                GestorIdioma.getString(KEY_DIALOGO_TITULO_CONFIRMAR),
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int id = (int) modeloTablaVacaciones.getValueAt(row, 0);
            if (controller.eliminarVacaciones(id)) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_V_ELIMINAR),
                        GestorIdioma.getString(KEY_DIALOGO_TITULO_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                actualizarTablaVacaciones();
            }
        }
    }

    public void actualizarTablaVacaciones() {
        modeloTablaVacaciones.setRowCount(0);
        controller.obtenerTodasVacaciones().forEach(v ->
                modeloTablaVacaciones.addRow(new Object[]{
                        v.getIdVacaciones(),
                        v.getNombreEmpleado(),
                        v.getFechaInicio().format(formatter),
                        v.getFechaFin().format(formatter),
                        v.getDescripcion()
                })
        );
        sorterVac.setRowFilter(crearFiltroVacaciones());
    }

    public void cargarEmpleados() {
        comboEmpleados.removeAllItems();
        controller.obtenerTodosEmpleados().forEach(comboEmpleados::addItem);
        comboEmpleados.setSelectedIndex(-1);
    }

    private void setIcon(AbstractButton b, String path) {
        URL url = getClass().getResource(path);
        if (url != null) {
            Image img = new ImageIcon(url).getImage()
                    .getScaledInstance(24, 24, Image.SCALE_SMOOTH);
            b.setIcon(new ImageIcon(img));
        }
    }
}
