package menuVacaciones.controlador;

import java.awt.*;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.List;
import javax.swing.*;

import menuVacaciones.vista.GestionFestivosVacacionesVista;
import accesoDatos.DiaFestivoDAO;
import accesoDatos.EmpleadoDAO;
import accesoDatos.VacacionesDAO;
import modelo.DiaFestivoDTO;
import modelo.EmpleadoDTO;
import modelo.VacacionesDTO;

public class GestionFestivosVacacionesControlador {
    private GestionFestivosVacacionesVista vista;
    private DiaFestivoDAO festivoDAO;
    private VacacionesDAO vacacionesDAO;
    private EmpleadoDAO empleadoDAO;
    private JPanel contenedor;
    private String panelAnterior;

    public GestionFestivosVacacionesControlador(Connection conexion, JPanel contenedor, String panelAnterior) {
        this.contenedor = contenedor;
        this.panelAnterior = panelAnterior;

        this.vista = new GestionFestivosVacacionesVista(this);
        this.festivoDAO = new DiaFestivoDAO(conexion);
        this.vacacionesDAO = new VacacionesDAO(conexion);
        this.empleadoDAO = new EmpleadoDAO(conexion);

        contenedor.add(vista, "festivosVacaciones");

        configurarListenersVista();
        cargarDatosIniciales();
    }

    public void navegarA(String nombrePanel) {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, nombrePanel);
    }

    public void regresarPanelAnterior() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, panelAnterior);
    }

    public void mostrar() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, "festivosVacaciones");
    }


    public boolean agregarFestivo(DiaFestivoDTO festivo) {
        try {
            return festivoDAO.crearFestivo(festivo);
        } catch (Exception e) {
            mostrarError("Error al agregar festivo", e);
            return false;
        }
    }

    public boolean actualizarFestivo(DiaFestivoDTO festivo) {
        try {
            return festivoDAO.actualizarFestivo(festivo);
        } catch (Exception e) {
            mostrarError("Error al actualizar festivo", e);
            return false;
        }
    }

    public boolean eliminarFestivo(int idFestivo) {
        try {
            return festivoDAO.eliminarFestivo(idFestivo);
        } catch (Exception e) {
            mostrarError("Error al eliminar festivo", e);
            return false;
        }
    }

    public List<DiaFestivoDTO> obtenerTodosFestivos() {
        try {
            return festivoDAO.obtenerTodosFestivos();
        } catch (Exception e) {
            mostrarError("Error al obtener festivos", e);
            return null;
        }
    }

    public boolean esFechaFestiva(LocalDate fecha) {
        try {
            return festivoDAO.esFechaFestiva(fecha);
        } catch (Exception e) {
            mostrarError("Error al verificar si la fecha es festiva", e);
            return false;
        }
    }

    public DiaFestivoDTO obtenerFestivoPorId(int idFestivo) {
        return festivoDAO.obtenerFestivoPorId(idFestivo);
    }

    public boolean agregarVacaciones(VacacionesDTO vacaciones) {
        try {
            return vacacionesDAO.crearVacaciones(vacaciones);
        } catch (Exception e) {
            mostrarError("Error al agregar vacaciones", e);
            return false;
        }
    }

    public boolean actualizarVacaciones(VacacionesDTO vacaciones) {
        try {
            return vacacionesDAO.actualizarVacaciones(vacaciones);
        } catch (Exception e) {
            mostrarError("Error al actualizar vacaciones", e);
            return false;
        }
    }

    public boolean eliminarVacaciones(int idVacaciones) {
        try {
            return vacacionesDAO.eliminarVacaciones(idVacaciones);
        } catch (Exception e) {
            mostrarError("Error al eliminar vacaciones", e);
            return false;
        }
    }

    public List<VacacionesDTO> obtenerTodasVacaciones() {
        try {
            return vacacionesDAO.obtenerTodasVacaciones();
        } catch (Exception e) {
            mostrarError("Error al obtener vacaciones", e);
            return null;
        }
    }

    public List<VacacionesDTO> obtenerVacacionesEmpleado(int idEmpleado) {
        try {
            return vacacionesDAO.obtenerVacacionesEmpleado(idEmpleado);
        } catch (Exception e) {
            mostrarError("Error al obtener vacaciones del empleado", e);
            return null;
        }
    }

    public boolean estaDeVacaciones(int idEmpleado, LocalDate fecha) {
        try {
            return vacacionesDAO.estaDeVacaciones(idEmpleado, fecha);
        } catch (Exception e) {
            mostrarError("Error al verificar si está de vacaciones", e);
            return false;
        }
    }

    public VacacionesDTO obtenerVacacionesPorId(int idVacaciones) {
        return vacacionesDAO.obtenerVacacionesPorId(idVacaciones);
    }

    public List<EmpleadoDTO> obtenerTodosEmpleados() {
        try {
            return empleadoDAO.obtenerTodosEmpleados();
        } catch (Exception e) {
            mostrarError("Error al obtener empleados", e);
            return null;
        }
    }

    public EmpleadoDTO obtenerEmpleadoPorId(int idEmpleado) {
        try {
            return empleadoDAO.obtenerEmpleadoPorId(idEmpleado);
        } catch (Exception e) {
            mostrarError("Error al obtener empleado", e);
            return null;
        }
    }

    public boolean debeTrabajareEnFecha(int idEmpleado, LocalDate fecha) {
        try {
            return empleadoDAO.debeTrabajareEnFecha(idEmpleado, fecha);
        } catch (Exception e) {
            mostrarError("Error al verificar si debe trabajar en fecha", e);
            return false;
        }
    }

    private void configurarListenersVista() {
        vista.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }

            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
                cerrarConexiones();
            }

            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
        });
    }

    private void cargarDatosIniciales() {
        vista.actualizarTablaFestivos();
        vista.actualizarTablaVacaciones();
        vista.cargarEmpleados();
    }

    public void cerrarConexiones() {
        festivoDAO.cerrar();
        vacacionesDAO.cerrar();
    }

    private void mostrarError(String mensaje, Exception e) {
        JOptionPane.showMessageDialog(vista, mensaje + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }

    public GestionFestivosVacacionesVista getVista() {
        return vista;
    }
}