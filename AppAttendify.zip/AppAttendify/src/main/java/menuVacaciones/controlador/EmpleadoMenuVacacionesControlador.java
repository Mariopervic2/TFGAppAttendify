package menuVacaciones.controlador;

import accesoDatos.DiaFestivoDAO;
import accesoDatos.VacacionesDAO;
import modelo.DiaFestivoDTO;
import modelo.VacacionesDTO;
import modelo.EmpleadoDTO;
import modelo.UsuarioDTO;
import menuVacaciones.vista.EmpleadoMenuVacacionesVista;
import varios.GestorIdioma;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class EmpleadoMenuVacacionesControlador {
    private static final Map<Integer, EmpleadoMenuVacacionesVista> ventanasAbiertas = new ConcurrentHashMap<>();

    private EmpleadoDTO empleado;
    private DiaFestivoDAO festivoDAO;
    private VacacionesDAO vacacionesDAO;
    private EmpleadoMenuVacacionesVista vista;

    public EmpleadoMenuVacacionesControlador(EmpleadoDTO empleado) {
        this.empleado = empleado;
        init();
    }

    public EmpleadoMenuVacacionesControlador(UsuarioDTO usuario) {
        EmpleadoDTO emp = new EmpleadoDTO();
        emp.setIdEmpleado(usuario.getIdEmpleado());

        emp.setNombre(usuario.getNombreEmpleado());
        emp.setApellidos("");
        this.empleado = emp;
        init();
    }


    private void init() {

        if (ventanasAbiertas.containsKey(empleado.getIdEmpleado())) {

            EmpleadoMenuVacacionesVista ventanaExistente = ventanasAbiertas.get(empleado.getIdEmpleado());
            ventanaExistente.toFront();
            ventanaExistente.requestFocus();

            return;
        }

        this.festivoDAO = new DiaFestivoDAO();
        this.vacacionesDAO = new VacacionesDAO();
        this.vista = new EmpleadoMenuVacacionesVista();

        vista.setTitle(GestorIdioma.getString("VACACIONES_Y_FESTIVOS_DE") + " " + empleado.getNombreCompleto());
        vista.setController(this);
        cargarFiltros();
        recargarDatos();

        ventanasAbiertas.put(empleado.getIdEmpleado(), vista);

        vista.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                ventanasAbiertas.remove(empleado.getIdEmpleado());
            }
        });

        vista.setVisible(true);
    }

    private void cargarFiltros() {
        vista.llenarComboMes();
        vista.llenarComboAno(obtenerAniosDisponibles());
    }

    public void recargarDatos() {
        int mes = vista.getMesSeleccionado();
        int ano = vista.getAnoSeleccionado();
        LocalDate inicio = LocalDate.of(ano, mes, 1);
        LocalDate fin = inicio.withDayOfMonth(inicio.lengthOfMonth());

        try {
            List<DiaFestivoDTO> festivos =
                    festivoDAO.obtenerEntre(inicio, fin);
            List<VacacionesDTO> vacaciones =
                    vacacionesDAO.obtenerEntre(empleado.getIdEmpleado(), inicio, fin);

            vista.actualizarTabla(festivos, vacaciones);
        } catch (Exception e) {
            vista.mostrarError("Error cargando datos: " + e.getMessage());
        }
    }

    private List<Integer> obtenerAniosDisponibles() {
        Set<Integer> anos = new TreeSet<>();
        try {
            List<DiaFestivoDTO> festivos =
                    festivoDAO.obtenerTodosFestivos();
            List<VacacionesDTO> vacaciones =
                    vacacionesDAO.obtenerVacacionesEmpleado(empleado.getIdEmpleado());

            anos.addAll(festivos.stream()
                    .map(f -> f.getFecha().getYear())
                    .collect(Collectors.toSet()));
            anos.addAll(vacaciones.stream()
                    .map(v -> v.getFechaInicio().getYear())
                    .collect(Collectors.toSet()));
        } catch (Exception e) {
            vista.mostrarError("Error obteniendo años disponibles: " + e.getMessage());
        }
        return List.copyOf(anos);
    }
}