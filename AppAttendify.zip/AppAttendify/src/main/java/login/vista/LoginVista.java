package login.vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import login.controlador.LoginControlador;
import varios.GestorIdioma;
import varios.Utilidades;

public class LoginVista extends JFrame {

    private static final String KEY_TITLE = "LOGIN_TITLE";
    private static final String KEY_USERNAME = "LOGIN_USERNAME";
    private static final String KEY_PASSWORD = "LOGIN_PASSWORD";
    private static final String KEY_BTN_LOGIN = "LOGIN_BTN_LOGIN";
    private static final String KEY_BTN_EXIT = "LOGIN_BTN_EXIT";
    private static final String KEY_ERR_EMPTY_USERNAME = "LOGIN_ERR_EMPTY_USERNAME";
    private static final String KEY_ERR_EMPTY_PASSWORD = "LOGIN_ERR_EMPTY_PASSWORD";

    private JPanel panelPrincipal;
    private JLabel lblLogo;
    private JLabel lblUsuario;
    private JLabel lblContrasena;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JButton btnSalir;

    private LoginControlador controlador;

    public LoginVista() {
        controlador = new LoginControlador(this);
        initComponents();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());

        setTitle(GestorIdioma.getString(KEY_TITLE));
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(null);
        panelPrincipal.setBackground(new Color(240, 240, 240));
        panelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel panelTitulo = new JPanel();
        panelTitulo.setBounds(0, 0, 500, 80);
        panelTitulo.setBackground(new Color(0, 76, 149));
        panelTitulo.setLayout(null);

        ImageIcon originalIcon = new ImageIcon(getClass().getResource("/imagenes/AttendifyBanda.png"));
        Image imagenEscalada = originalIcon.getImage().getScaledInstance(400, 70, Image.SCALE_SMOOTH);
        ImageIcon imagenFinal = new ImageIcon(imagenEscalada);

        lblLogo = new JLabel(imagenFinal);
        lblLogo.setBounds(5, 5, 490, 70);
        panelTitulo.add(lblLogo);

        lblUsuario = new JLabel(GestorIdioma.getString(KEY_USERNAME) + ":");
        lblUsuario.setBounds(100, 130, 100, 25);
        lblUsuario.setFont(new Font("Arial", Font.PLAIN, 14));

        lblContrasena = new JLabel(GestorIdioma.getString(KEY_PASSWORD) + ":");
        lblContrasena.setBounds(100, 180, 100, 25);
        lblContrasena.setFont(new Font("Arial", Font.PLAIN, 14));

        txtUsuario = new JTextField();
        txtUsuario.setBounds(200, 130, 200, 25);
        txtUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        txtUsuario.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    txtContrasena.requestFocus();
                }
            }
        });

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(200, 180, 200, 25);
        txtContrasena.setFont(new Font("Arial", Font.PLAIN, 14));
        txtContrasena.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    iniciarSesion();
                }
            }
        });

        btnIngresar = new JButton(GestorIdioma.getString(KEY_BTN_LOGIN));
        btnIngresar.setBounds(130, 240, 100, 30);
        btnIngresar.setBackground(new Color(0, 153, 102));
        btnIngresar.setForeground(Color.BLACK);
        btnIngresar.setFont(new Font("Arial", Font.BOLD, 14));
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });

        btnSalir = new JButton(GestorIdioma.getString(KEY_BTN_EXIT));
        btnSalir.setBounds(270, 240, 100, 30);
        btnSalir.setBackground(new Color(204, 0, 0));
        btnSalir.setForeground(Color.BLACK);
        btnSalir.setFont(new Font("Arial", Font.BOLD, 14));
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        panelPrincipal.add(panelTitulo);
        panelPrincipal.add(lblUsuario);
        panelPrincipal.add(lblContrasena);
        panelPrincipal.add(txtUsuario);
        panelPrincipal.add(txtContrasena);
        panelPrincipal.add(btnIngresar);
        panelPrincipal.add(btnSalir);

        add(panelPrincipal);
    }

    public void actualizarTextos() {
        setTitle(GestorIdioma.getString(KEY_TITLE));
        lblUsuario.setText(GestorIdioma.getString(KEY_USERNAME) + ":");
        lblContrasena.setText(GestorIdioma.getString(KEY_PASSWORD) + ":");
        btnIngresar.setText(GestorIdioma.getString(KEY_BTN_LOGIN));
        btnSalir.setText(GestorIdioma.getString(KEY_BTN_EXIT));
    }

    private void iniciarSesion() {
        if (validarCampos()) {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());
            controlador.autenticarUsuario(usuario, contrasena);
        }
    }

    private boolean validarCampos() {
        if (Utilidades.campoVacio(txtUsuario)) {
            Utilidades.mostrarError(GestorIdioma.getString(KEY_ERR_EMPTY_USERNAME));
            txtUsuario.requestFocus();
            return false;
        }

        if (Utilidades.campoVacio(txtContrasena)) {
            Utilidades.mostrarError(GestorIdioma.getString(KEY_ERR_EMPTY_PASSWORD));
            txtContrasena.requestFocus();
            return false;
        }

        return true;
    }

    public void limpiarCampos() {
        txtUsuario.setText("");
        txtContrasena.setText("");
        txtUsuario.requestFocus();
    }

    public JTextField getTxtUsuario() {
        return txtUsuario;
    }

    public JPasswordField getTxtContrasena() {
        return txtContrasena;
    }
}
