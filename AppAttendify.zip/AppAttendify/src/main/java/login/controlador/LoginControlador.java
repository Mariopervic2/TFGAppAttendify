package login.controlador;

import accesoDatos.UsuarioDAO;
import login.vista.LoginVista;
import menusPrincipales.MenuPrincipalAdministradorVista;
import menusPrincipales.MenuPrincipalEmpleadoVista;
import modelo.UsuarioDTO;
import varios.GestorIdioma;
import varios.Utilidades;

import java.sql.Connection;
import java.sql.SQLException;

public class LoginControlador {

    private LoginVista vista;
    private UsuarioDAO usuarioDAO;

    public LoginControlador(LoginVista vista) {
        this.vista = vista;

        try {
            Connection conexion = varios.ConexionBD.obtenerConexion();
            this.usuarioDAO = new UsuarioDAO(conexion);
        } catch (SQLException e) {
            Utilidades.mostrarError("Error al conectar con la base de datos: " + e.getMessage());
        }
    }

    public void autenticarUsuario(String nombreUsuario, String contrasena) {
        try {
            UsuarioDTO usuario = usuarioDAO.autenticarUsuario(nombreUsuario, contrasena);

            if (usuario != null) {
                abrirMenuPrincipal(usuario);
            } else {
                Utilidades.mostrarError(GestorIdioma.getString("USU_CON_INCORRECTOS"));
                vista.limpiarCampos();
            }
        } catch (SQLException e) {
            Utilidades.mostrarError("Error al autenticar el usuario: " + e.getMessage());
        }
    }

    private void abrirMenuPrincipal(UsuarioDTO usuario) {
        vista.dispose();

        if ("Administrador".equals(usuario.getTipoUsuario())) {
            java.awt.EventQueue.invokeLater(() -> {
                new MenuPrincipalAdministradorVista(usuario).setVisible(true);
            });
        } else {
            java.awt.EventQueue.invokeLater(() -> {
                new MenuPrincipalEmpleadoVista(usuario).setVisible(true);
            });
        }
    }
}
