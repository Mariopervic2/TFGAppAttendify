package menuInformes.controlador;

import modelo.HorarioDiaTrabajoDTO;
import modelo.InformesDTO;
import modelo.RegistroDTO;

import java.net.URL;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.stream.Collectors;

public final class HtmlBuilder {
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");
    private static final long DESVIACION_MINUTOS = 20;

    private HtmlBuilder() { }

    public static String build(InformesDTO informe, Locale locale, ResourceBundle bundle) {
        YearMonth mes = informe.getMes();
        String mesNombre = mes.getMonth().getDisplayName(TextStyle.FULL, locale);
        mesNombre = mesNombre.substring(0,1).toUpperCase(locale) + mesNombre.substring(1);

        List<RegistroDTO> registros = informe.getRegistrosDiarios();
        Map<java.time.LocalDate, List<RegistroDTO>> porFecha = registros.stream()
                .collect(Collectors.groupingBy(RegistroDTO::getFecha, TreeMap::new, Collectors.toList()));

        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html lang=\"").append(locale.getLanguage())
                .append("\"><head><meta charset=\"UTF-8\"/><style>")
                .append("body{font-family:sans-serif;background-color:#f5f9ff;} .dia{border:1px solid #aaa;margin-bottom:10px;padding:5px;border-radius:5px;background-color:white;box-shadow:0 1px 3px rgba(0,0,0,0.1);} ")
                .append(".cabecera{background:#ddd;padding:8px;border-radius:3px;display:flex;justify-content:space-between;align-items:center;} ")
                .append(".horario-dia{font-weight:bold;padding:2px 8px;color:#1a5fb4;background-color:#d1e3fa;border-radius:4px;} ")
                .append("table{width:100%;border-collapse:collapse;margin-top:5px;} th,td{border:1px solid #ccc;padding:4px;text-align:center;} th{background:#e8f0fe;} ")
                .append(".ok{background:#c8e6c9;padding:3px 8px;border-radius:3px;} .late{background:#fff3e0;padding:3px 8px;border-radius:3px;} .over{background:#ffcdd2;padding:3px 8px;border-radius:3px;} ")
                .append(".horas-info{display:flex;justify-content:space-between;margin:15px 0;padding:6px;background-color:#f0f5ff;border-radius:4px;} .horas-label{font-weight:bold;color:#2c5aa0;} ")
                .append(".correspondientes{background-color:#bbdefb;padding:3px 8px;border-radius:3px;font-weight:bold;} ")
                .append("</style></head><body>");

        sb.append("<h1>").append(bundle.getString("informe.titulo")).append(": ")
                .append(mesNombre).append(" ").append(mes.getYear()).append("</h1>");
        sb.append("<h2>").append(informe.getNombreEmpleado()).append("</h2>");
        sb.append("<h3>").append(informe.getHorarioNombre()).append("</h3>");

        // Lista de horario por día
        sb.append("<ul>");
        for (HorarioDiaTrabajoDTO d : informe.getHorarioDias()) {
            if (!d.isActivo()) continue;
            DayOfWeek dow = DayOfWeek.of(d.getIdDia());
            String raw = dow.getDisplayName(TextStyle.FULL, locale);
            String dia = raw.substring(0,1).toUpperCase(locale) + raw.substring(1);
            sb.append("<li>")
                    .append(dia).append(" ")
                    .append(d.getHoraEntrada().format(TIME_FMT))
                    .append("-")
                    .append(d.getHoraSalida().format(TIME_FMT))
                    .append(" (descanso ").append(d.getTiempoDescanso()).append(" min)")
                    .append("</li>");
        }
        sb.append("</ul>");

        // Procesar cada fecha
        for (Map.Entry<java.time.LocalDate, List<RegistroDTO>> entry : porFecha.entrySet()) {
            java.time.LocalDate fecha = entry.getKey();
            List<RegistroDTO> lista = entry.getValue();
            DayOfWeek dow = fecha.getDayOfWeek();
            String rawDay = dow.getDisplayName(TextStyle.FULL, locale);
            String diaSemana = rawDay.substring(0,1).toUpperCase(locale) + rawDay.substring(1);

            int esperadoMin = lista.get(0).getMinutosEsperados();
            String horarioDia = esperadoMin > 0
                    ? (esperadoMin/60 + ":" + String.format("%02d", esperadoMin%60) + " h")
                    : "";

            sb.append("<div class=\"dia\">")
                    .append("<div class=\"cabecera\">")
                    .append("<div>").append(DATE_FMT.format(fecha)).append(" (").append(diaSemana).append(")</div>")
                    .append("<span class=\"horario-dia\">").append(horarioDia).append("</span>")
                    .append("</div>")
                    .append("<table><thead><tr><th>")
                    .append(bundle.getString("columna.entrada")).append("</th><th>")
                    .append(bundle.getString("columna.salida")).append("</th></tr></thead><tbody>");

            // Filas de registros
            for (RegistroDTO r : lista) {
                String ent = r.getHoraEntrada() != null ? TIME_FMT.format(r.getHoraEntrada()) : "-";
                String sal = "-";
                if (r.getHoraSalida() != null) {
                    sal = TIME_FMT.format(r.getHoraSalida()) + " ";
                    sal += DATE_FMT.format(
                            r.getHoraSalida().isBefore(r.getHoraEntrada())
                                    ? fecha.plusDays(1)
                                    : fecha);
                }
                sb.append("<tr><td>").append(ent).append("</td><td>").append(sal).append("</td></tr>");
            }
            sb.append("</tbody></table>");

            // --- Cálculo minutos descontando descanso ---
            long minutosBrutos = lista.stream()
                    .filter(r -> r.getHoraEntrada()!=null && r.getHoraSalida()!=null)
                    .mapToLong(r -> {
                        LocalDateTime ini = LocalDateTime.of(fecha, r.getHoraEntrada());
                        LocalDateTime fin = LocalDateTime.of(fecha, r.getHoraSalida());
                        if (fin.isBefore(ini)) fin = fin.plusDays(1);
                        return Duration.between(ini, fin).toMinutes();
                    }).sum();

            int diaValor = fecha.getDayOfWeek().getValue();
            HorarioDiaTrabajoDTO horarioDelDia = informe.getHorarioDias().stream()
                    .filter(h -> h.isActivo() && h.getIdDia() == diaValor)
                    .findFirst().orElse(null);

            long descanso = horarioDelDia != null
                    ? horarioDelDia.getTiempoDescanso()
                    : 0L;

            long minutosDia = Math.max(0, minutosBrutos - descanso);

            // Formateo
            String horasStr = minutosDia/60 + ":" + String.format("%02d", minutosDia%60);
            String descansoStr = String.format("%02d:%02d", descanso/60, descanso%60);
            String horasEsperadasStr = esperadoMin/60 + ":" + String.format("%02d", esperadoMin%60);

            String clase = Math.abs(minutosDia - esperadoMin) <= DESVIACION_MINUTOS ? "ok"
                    : minutosDia < esperadoMin ? "late" : "over";

            sb.append("<div class=\"horas-info\">")
                    .append("<span class=\"horas-label\">")
                    .append(bundle.getString("detalle.trabajadas")).append(": </span>")
                    .append("<span class=\"").append(clase).append("\">").append(horasStr).append("</span>")

                    .append("<span class=\"horas-label\" style=\"margin-left:20px;\">")
                    .append(bundle.getString("detalle.descanso")).append(": </span>")
                    .append("<span class=\"correspondientes\">").append(descansoStr).append("</span>")

                    .append("<span class=\"horas-label\" style=\"margin-left:auto;\">")
                    .append(bundle.getString("detalle.correspondientes")).append(": </span>")
                    .append("<span class=\"correspondientes\">").append(horasEsperadasStr).append("</span>")
                    .append("</div>");

            // Icono y motivo
            boolean corresponde = lista.get(0).isCorrespondeTrabajar();
            URL checkUrl = HtmlBuilder.class.getResource("/imagenes/check.png");
            URL crossUrl = HtmlBuilder.class.getResource("/imagenes/cross.png");
            String icon = corresponde
                    ? "<img src='"+(checkUrl!=null?checkUrl.toExternalForm():"")+"' width='16'/>"
                    : "<img src='"+(crossUrl!=null?crossUrl.toExternalForm():"")+"' width='16'/>";

            String motivoKey;
            if (corresponde) {
                motivoKey = "motivo.laboral";
            } else if (lista.get(0).isFestivo()) {
                motivoKey = "motivo.festivo";
            } else if (lista.get(0).isVacaciones()) {
                motivoKey = "motivo.vacaciones";
            } else {
                motivoKey = "motivo.nolaboralhorario";
            }

            sb.append("<p>")
                    .append(bundle.getString("label.corresponde")).append(": ")
                    .append(icon).append(" ")
                    .append(bundle.getString(motivoKey))
                    .append("</p>")
                    .append("</div>");
        }

        // --- Resumen mensual con descuento de descansos ---
        long totalEsperado = registros.stream().mapToLong(RegistroDTO::getMinutosEsperados).sum();

        long totalTrabajado = porFecha.entrySet().stream()
                .mapToLong(e -> {
                    java.time.LocalDate fecha = e.getKey();
                    List<RegistroDTO> lista = e.getValue();

                    long brutos = lista.stream()
                            .filter(r -> r.getHoraEntrada()!=null && r.getHoraSalida()!=null)
                            .mapToLong(r -> {
                                LocalDateTime ini = LocalDateTime.of(fecha, r.getHoraEntrada());
                                LocalDateTime fin = LocalDateTime.of(fecha, r.getHoraSalida());
                                if (fin.isBefore(ini)) fin = fin.plusDays(1);
                                return Duration.between(ini, fin).toMinutes();
                            }).sum();

                    int diaValor = fecha.getDayOfWeek().getValue();
                    HorarioDiaTrabajoDTO horarioDelDia = informe.getHorarioDias().stream()
                            .filter(h -> h.isActivo() && h.getIdDia() == diaValor)
                            .findFirst().orElse(null);

                    long descanso = horarioDelDia != null
                            ? horarioDelDia.getTiempoDescanso()
                            : 0L;

                    return Math.max(0, brutos - descanso);
                }).sum();

        long diferencia = totalTrabajado - totalEsperado;
        String claseResumen = Math.abs(diferencia) <= DESVIACION_MINUTOS ? "ok"
                : diferencia < 0 ? "late" : "over";

        String horasEsperadasTot = totalEsperado/60 + ":" + String.format("%02d", totalEsperado%60);
        String horasTrabajadasTot = totalTrabajado/60 + ":" + String.format("%02d", totalTrabajado%60);
        String horasExtraStr = Math.abs(diferencia)/60 + ":" + String.format("%02d", Math.abs(diferencia)%60);

        sb.append("<hr/><h3>").append(bundle.getString("resumen.mensual")).append("</h3>")
                .append("<div class=\"horas-info\"><span class=\"horas-label\">")
                .append(bundle.getString("resumen.esperadas")).append(":</span>")
                .append("<span class=\"correspondientes\">").append(horasEsperadasTot).append("</span></div>")
                .append("<div class=\"horas-info\"><span class=\"horas-label\">")
                .append(bundle.getString("resumen.trabajadas")).append(":</span>")
                .append("<span class=\"ok\">").append(horasTrabajadasTot).append("</span></div>")
                .append("<div class=\"horas-info\"><span class=\"horas-label\">")
                .append(bundle.getString("resumen.extra")).append(":</span>")
                .append("<span class=\"").append(claseResumen).append("\">")
                .append((diferencia>=0?"+":"-")).append(horasExtraStr)
                .append("</span></div>");

        sb.append("</body></html>");
        return sb.toString();
    }
}
