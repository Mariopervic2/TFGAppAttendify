package menuInformes.controlador;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import modelo.InformesDTO;
import varios.CalendarioLaboralUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.time.YearMonth;
import java.util.Locale;
import java.util.ResourceBundle;
import java.net.URL;


public final class GeneradorInformes {
    private static final String HTML_CHARSET = "UTF-8";

    private GeneradorInformes() {

    }


    public static String generarHtml(InformesDTO informe) {
        Locale locale = informe.getLocale();
        ResourceBundle bundle = informe.getBundle();

        informe.getRegistrosDiarios().forEach(reg -> {
            int esperados = CalendarioLaboralUtil.calcularMinutosEsperados(
                    reg.getFecha(),
                    informe.getHorarioDias(),
                    informe.getDiasFestivos(),
                    informe.getVacaciones());
            reg.setMinutosEsperados(esperados);
            reg.setCorrespondeTrabajar(CalendarioLaboralUtil.esDiaLaborable(
                    reg.getFecha(),
                    informe.getHorarioDias(),
                    informe.getDiasFestivos(),
                    informe.getVacaciones()));
        });

        return HtmlBuilder.build(informe, locale, bundle);
    }

    public static File writeHtmlToFile(String html, InformesDTO informe) throws IOException {
        YearMonth ym = informe.getMes();
        File temp = Files.createTempFile(
                "informe_" + ym.getYear() + "-" + String.format("%02d", ym.getMonthValue()),
                ".html"
        ).toFile();
        try (FileWriter fw = new FileWriter(temp, false)) {
            fw.write(html);
        }
        return temp;
    }

    public static File htmlToPdf(File htmlFile, InformesDTO informe) throws IOException {
        YearMonth ym = informe.getMes();
        File pdf = Files.createTempFile(
                "informe_" + ym.getYear() + "-" + String.format("%02d", ym.getMonthValue()),
                ".pdf"
        ).toFile();
        try (OutputStream os = Files.newOutputStream(pdf.toPath())) {
            String html = new String(Files.readAllBytes(htmlFile.toPath()), HTML_CHARSET);
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.withHtmlContent(html, null);
            builder.toStream(os);
            builder.run();
        } catch (Exception e) {
            throw new IOException("Error generando PDF", e);
        }
        return pdf;
    }
}
