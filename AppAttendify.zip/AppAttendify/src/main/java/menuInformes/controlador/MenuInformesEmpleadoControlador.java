package menuInformes.controlador;

import menuInformes.vista.MenuInformesEmpleadoVista;
import modelo.InformesDTO;
import modelo.RegistroDTO;
import modelo.HorarioDiaTrabajoDTO;
import modelo.DiaFestivoDTO;
import modelo.VacacionesDTO;
import modelo.UsuarioDTO;
import accesoDatos.InformesDAO;
import accesoDatos.HorarioDiaTrabajoDAO;
import accesoDatos.DiaFestivoDAO;
import accesoDatos.RegistroDAO;
import accesoDatos.VacacionesDAO;
import varios.ConexionBD;
import varios.GestorIdioma;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MenuInformesEmpleadoControlador {

    private final MenuInformesEmpleadoVista vista;
    private final UsuarioDTO usuario;
    private final InformesDAO informesDAO;
    private final HorarioDiaTrabajoDAO hdtDAO;
    private final DiaFestivoDAO festivoDAO;
    private final RegistroDAO registroDAO;
    private final VacacionesDAO vacacionesDAO;

    private InformesDTO currentInforme;
    private String currentHtml;

    public MenuInformesEmpleadoControlador(MenuInformesEmpleadoVista vista, UsuarioDTO usuario) {
        this.vista   = vista;
        this.usuario = usuario;
        try {
            Connection con = ConexionBD.obtenerConexion();
            informesDAO = new InformesDAO(con);
            hdtDAO      = new HorarioDiaTrabajoDAO(con);
            festivoDAO  = new DiaFestivoDAO(con);
            registroDAO = new RegistroDAO(con);
            vacacionesDAO = new VacacionesDAO(con);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void cargarAnios() {
        try {
            List<YearMonth> meses = informesDAO.obtenerMesesConInforme(usuario.getIdEmpleado());
            List<Integer> anios = meses.stream()
                    .map(YearMonth::getYear)
                    .distinct()
                    .sorted((a,b)->b-a)
                    .collect(Collectors.toList());
            vista.mostrarAnios(anios);
        } catch (SQLException e) {
            vista.mostrarError("Error cargando años: " + e.getMessage());
        }
    }

    public void cargarMesesPorAnio(int anio) {
        try {
            List<YearMonth> meses = informesDAO.obtenerMesesConInforme(usuario.getIdEmpleado());
            List<YearMonth> filtrados = meses.stream()
                    .filter(ym -> ym.getYear() == anio)
                    .sorted()
                    .collect(Collectors.toList());
            vista.mostrarMesesPorAnio(filtrados);
        } catch (SQLException e) {
            vista.mostrarError("Error cargando meses: " + e.getMessage());
        }
    }

    public void abrirInforme(YearMonth ym) {
        try {
            currentInforme = informesDAO.obtenerInformeMensual(usuario.getIdEmpleado(), ym);

            currentInforme.setLocale(GestorIdioma.getCurrentLocale());
            currentInforme.setBundle(GestorIdioma.getBundle());

            List<HorarioDiaTrabajoDTO> plantilla =
                    hdtDAO.obtenerDiasTrabajoPorHorario(currentInforme.getIdEmpleado());
            currentInforme.setHorarioDias(plantilla);

            LocalDate inicio = ym.atDay(1);
            LocalDate fin    = ym.atEndOfMonth();
            List<DiaFestivoDTO> diasFest = festivoDAO.obtenerEntre(inicio, fin);
            currentInforme.setDiasFestivos(diasFest);

            List<VacacionesDTO> vacs = vacacionesDAO.obtenerEntre(
                    currentInforme.getIdEmpleado(), inicio, fin
            );
            currentInforme.setVacaciones(vacs);

            List<RegistroDTO> registros =
                    registroDAO.obtenerRegistrosPorMes(currentInforme.getIdEmpleado(), ym);

            List<LocalDate> fechasFestivos = diasFest.stream()
                    .map(DiaFestivoDTO::getFecha)
                    .collect(Collectors.toList());
            for (RegistroDTO r : registros) {
                LocalDate fecha = r.getFecha();
                boolean isFestivo = fechasFestivos.contains(fecha);
                r.setFestivo(isFestivo);

                DayOfWeek dow = fecha.getDayOfWeek();
                Optional<HorarioDiaTrabajoDTO> op = plantilla.stream()
                        .filter(p -> DayOfWeek.of(p.getIdDia()) == dow && p.isActivo())
                        .findFirst();

                if (op.isPresent() && !isFestivo) {
                    r.setCorrespondeTrabajar(true);
                    int mins = (int) Duration
                            .between(op.get().getHoraEntrada(), op.get().getHoraSalida())
                            .toMinutes();
                    r.setMinutosEsperados(mins);
                } else {
                    r.setCorrespondeTrabajar(false);
                    r.setMinutosEsperados(0);
                }
            }

            currentInforme.setRegistrosDiarios(registros);
            currentHtml = GeneradorInformes.generarHtml(currentInforme);
            vista.mostrarDetalleHtml(currentHtml);

        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains("horario")) {
                vista.mostrarError(GestorIdioma.getString("NO_HORARIO_ASIGNADO_EMPLE"));
            } else {
                vista.mostrarError("No se pudo abrir el informe: " + e.getMessage());
            }
        }
    }

    public void abrirEnNavegador() {
        try {
            File htmlFile = GeneradorInformes.writeHtmlToFile(currentHtml, currentInforme);
            Desktop.getDesktop().browse(htmlFile.toURI());
        } catch (IOException e) {
            vista.mostrarError("Error abriendo navegador: " + e.getMessage());
        }
    }

    public void exportarPdf() {
        try {
            File htmlFile = GeneradorInformes.writeHtmlToFile(currentHtml, currentInforme);
            File pdf      = GeneradorInformes.htmlToPdf(htmlFile, currentInforme);
            Desktop.getDesktop().open(pdf);
        } catch (IOException e) {
            vista.mostrarError("Error exportando PDF: " + e.getMessage());
        }
    }
}
