package menuInformes.vista;

import menuInformes.controlador.MenuInformesAdministradorControlador;
import modelo.EmpleadoDTO;
import modelo.UsuarioDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

public class MenuInformesAdministradorVista extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelContainer;

    private JTable tablaEmpleados;
    private JButton btnConsultarInformes;
    private JButton btnCerrar;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private TableRowSorter<DefaultTableModel> sorter;
    private List<EmpleadoDTO> empleados;

    private JComboBox<Integer> cbAnios;
    private JPanel panelMeses;
    private JButton btnVolverListaEmpleados;
    private JLabel lblEmpleadoSeleccionado;

    private JEditorPane editorHtml;
    private JButton btnVolverDetalle;
    private JButton btnAbrirNavegador;
    private JButton btnExportarPdf;

    private MenuInformesAdministradorControlador controlador;

    public MenuInformesAdministradorVista(UsuarioDTO usuario) {
        super(GestorIdioma.getString("TITULO_INFORMES_ADMIN"));
        controlador = new MenuInformesAdministradorControlador(this, usuario);
        initComponents();
        controlador.cargarEmpleados();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        panelContainer = new JPanel(cardLayout);

        JPanel panelSelEmpleado = new JPanel(new BorderLayout(10, 10));
        panelSelEmpleado.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblTitulo = new JLabel(GestorIdioma.getString("SELECCIONA_EMPLEADO"));
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelSelEmpleado.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.add(new JLabel(GestorIdioma.getString("BUSCAR_EMPLEADO") + ":"));
        txtBuscar = new JTextField(20);
        panelBusqueda.add(txtBuscar);
        panelSelEmpleado.add(panelBusqueda, BorderLayout.BEFORE_FIRST_LINE);

        String[] columnas = {GestorIdioma.getString("NOMBRE"), GestorIdioma.getString("PUESTO")};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaEmpleados = new JTable(modeloTabla);
        tablaEmpleados.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaEmpleados.getTableHeader().setReorderingAllowed(false);

        JTableHeader header = tablaEmpleados.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD));


        sorter = new TableRowSorter<>(modeloTabla);
        tablaEmpleados.setRowSorter(sorter);

        panelSelEmpleado.add(new JScrollPane(tablaEmpleados), BorderLayout.CENTER);


        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrar(); }
            public void removeUpdate(DocumentEvent e) { filtrar(); }
            public void changedUpdate(DocumentEvent e) { filtrar(); }
        });


        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnConsultarInformes = new JButton(GestorIdioma.getString("BTN_CONSULTAR_INFORMES"));
        btnConsultarInformes.addActionListener(e -> {
            int fila = tablaEmpleados.getSelectedRow();
            if (fila != -1) {
                int modeloRow = tablaEmpleados.convertRowIndexToModel(fila);
                EmpleadoDTO emp = empleados.get(modeloRow);
                controlador.seleccionarEmpleado(emp.getIdEmpleado(), emp.getNombreCompleto());
            } else {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("SELECCIONA_EMP_ALERT"),
                        GestorIdioma.getString("ERROR"), JOptionPane.WARNING_MESSAGE);
            }
        });

        btnCerrar = new JButton(GestorIdioma.getString("VOLVER_MENU"));
        btnCerrar.addActionListener(e -> dispose());

        panelBotones.add(btnConsultarInformes);
        panelBotones.add(btnCerrar);
        panelSelEmpleado.add(panelBotones, BorderLayout.SOUTH);

        JPanel panelSelInforme = new JPanel(new BorderLayout(10, 10));
        panelSelInforme.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel panelSuperior = new JPanel(new BorderLayout());
        JPanel panelEmpleado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelEmpleado.add(new JLabel(GestorIdioma.getString("EMPLEADO") + ":"));
        lblEmpleadoSeleccionado = new JLabel();
        lblEmpleadoSeleccionado.setFont(new Font("Arial", Font.BOLD, 14));
        panelEmpleado.add(lblEmpleadoSeleccionado);
        panelSuperior.add(panelEmpleado, BorderLayout.NORTH);

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filtro.add(new JLabel(GestorIdioma.getString("ANIO") + ":"));
        cbAnios = new JComboBox<>();
        cbAnios.addActionListener((ActionEvent e) -> {
            Integer anio = (Integer) cbAnios.getSelectedItem();
            if (anio != null) controlador.cargarMesesPorAnio(anio);
        });
        filtro.add(cbAnios);
        panelSuperior.add(filtro, BorderLayout.CENTER);
        panelSelInforme.add(panelSuperior, BorderLayout.NORTH);

        panelMeses = new JPanel(new GridLayout(0, 3, 10, 10));
        panelSelInforme.add(new JScrollPane(panelMeses), BorderLayout.CENTER);

        JPanel footerSel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnVolverListaEmpleados = new JButton("← " + GestorIdioma.getString("VOLVER"));
        btnVolverListaEmpleados.addActionListener(e -> cardLayout.show(panelContainer, "SELECCION_EMPLEADO"));
        footerSel.add(btnVolverListaEmpleados);
        panelSelInforme.add(footerSel, BorderLayout.SOUTH);

        JPanel panelDet = new JPanel(new BorderLayout(10, 10));
        panelDet.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel headerDet = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnVolverDetalle = new JButton("← " + GestorIdioma.getString("VOLVER"));
        btnAbrirNavegador = new JButton(GestorIdioma.getString("BTN_NAVEGADOR"));
        btnExportarPdf = new JButton(GestorIdioma.getString("BTN_EXPORTAR_PDF"));

        btnVolverDetalle.addActionListener(e -> cardLayout.show(panelContainer, "SELECCION_INFORME"));
        btnAbrirNavegador.addActionListener(e -> controlador.abrirEnNavegador());
        btnExportarPdf.addActionListener(e -> controlador.exportarPdf());

        headerDet.add(btnVolverDetalle);
        headerDet.add(btnAbrirNavegador);
        headerDet.add(btnExportarPdf);
        panelDet.add(headerDet, BorderLayout.NORTH);

        editorHtml = new JEditorPane();
        editorHtml.setContentType("text/html");
        editorHtml.setEditable(false);
        panelDet.add(new JScrollPane(editorHtml), BorderLayout.CENTER);

        panelContainer.add(panelSelEmpleado, "SELECCION_EMPLEADO");
        panelContainer.add(panelSelInforme, "SELECCION_INFORME");
        panelContainer.add(panelDet, "DETALLE");
        setContentPane(panelContainer);
        cardLayout.show(panelContainer, "SELECCION_EMPLEADO");
    }


    public void mostrarEmpleados(List<EmpleadoDTO> listaEmp) {
        this.empleados = listaEmp;
        modeloTabla.setRowCount(0);
        for (EmpleadoDTO emp : listaEmp) {
            Object[] fila = {
                    emp.getNombreCompleto(),
                    emp.getPuesto()
            };
            modeloTabla.addRow(fila);
        }
    }

    public void mostrarInformesEmpleado(String nombreEmpleado) {
        lblEmpleadoSeleccionado.setText(nombreEmpleado);
        cardLayout.show(panelContainer, "SELECCION_INFORME");
    }

    public void mostrarAnios(List<Integer> anios) {
        cbAnios.removeAllItems();
        for (Integer a : anios) cbAnios.addItem(a);
        if (cbAnios.getItemCount() > 0) cbAnios.setSelectedIndex(0);
    }

    public void mostrarMesesPorAnio(List<YearMonth> meses) {
        panelMeses.removeAll();
        Locale locale = GestorIdioma.getCurrentLocale();

        for (YearMonth ym : meses) {
            String nombreMes = ym.getMonth().getDisplayName(TextStyle.FULL, locale);
            String nombreMesCapitalizado = nombreMes.substring(0, 1).toUpperCase(locale) + nombreMes.substring(1);
            String texto = nombreMesCapitalizado + " " + ym.getYear();

            JButton btn = new JButton(texto);
            btn.addActionListener(e -> controlador.abrirInforme(ym));
            panelMeses.add(btn);
        }

        panelMeses.revalidate();
        panelMeses.repaint();
    }

    public void mostrarDetalleHtml(String html) {
        editorHtml.setText(html);
        editorHtml.setCaretPosition(0);
        cardLayout.show(panelContainer, "DETALLE");
    }

    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();
        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }
        RowFilter<DefaultTableModel, Object> rf = new RowFilter<DefaultTableModel, Object>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Object> entry) {
                String nombre = String.valueOf(entry.getValue(0)).toLowerCase();
                String[] palabras = texto.split("\\s+");
                for (String p : palabras) {
                    if (!nombre.contains(p)) return false;
                }
                return true;
            }
        };
        sorter.setRowFilter(rf);
    }



    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                GestorIdioma.getString("ERROR"),
                JOptionPane.ERROR_MESSAGE
        );
    }

}
