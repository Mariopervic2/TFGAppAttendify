package menuInformes.vista;

import menuInformes.controlador.MenuInformesEmpleadoControlador;
import modelo.UsuarioDTO;

import javax.swing.*;
import java.awt.*;
import java.time.YearMonth;
import java.util.List;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.time.format.TextStyle;
import java.util.Locale;

import varios.GestorIdioma;

public class MenuInformesEmpleadoVista extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelContainer;

    private JComboBox<Integer> cbAnios;
    private JPanel panelMeses;
    private JButton btnCerrar;

    private JEditorPane editorHtml;
    private JButton btnVolverDetalle;
    private JButton btnAbrirNavegador;
    private JButton btnExportarPdf;

    private MenuInformesEmpleadoControlador controlador;

    public MenuInformesEmpleadoVista(UsuarioDTO usuario) {
        super(GestorIdioma.getString("INFORMES_MENSUALES"));
        controlador = new MenuInformesEmpleadoControlador(this, usuario);
        initComponents();
        controlador.cargarAnios();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        panelContainer = new JPanel(cardLayout);

        JPanel panelSel = new JPanel(new BorderLayout(10, 10));
        panelSel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filtro.add(new JLabel(GestorIdioma.getString("ANIO") + ":"));
        cbAnios = new JComboBox<>();
        cbAnios.addActionListener((ActionEvent e) -> {
            Integer anio = (Integer) cbAnios.getSelectedItem();
            if (anio != null) controlador.cargarMesesPorAnio(anio);
        });
        filtro.add(cbAnios);
        panelSel.add(filtro, BorderLayout.NORTH);

        panelMeses = new JPanel(new GridLayout(0, 3, 10, 10));
        panelSel.add(new JScrollPane(panelMeses), BorderLayout.CENTER);

        JPanel footerSel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnCerrar = new JButton(GestorIdioma.getString("VOLVER_MENU"));
        btnCerrar.addActionListener(e -> dispose());
        footerSel.add(btnCerrar);
        panelSel.add(footerSel, BorderLayout.SOUTH);

        JPanel panelDet = new JPanel(new BorderLayout(10, 10));
        panelDet.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnVolverDetalle = new JButton("← " + GestorIdioma.getString("VOLVER"));
        btnAbrirNavegador = new JButton(GestorIdioma.getString("ABRIR_NAVEGADOR"));
        btnExportarPdf = new JButton(GestorIdioma.getString("EXPORTAR_PDF"));

        btnVolverDetalle.addActionListener(e -> cardLayout.show(panelContainer, "SELECCION"));
        btnAbrirNavegador.addActionListener(e -> controlador.abrirEnNavegador());
        btnExportarPdf.addActionListener(e -> controlador.exportarPdf());

        header.add(btnVolverDetalle);
        header.add(btnAbrirNavegador);
        header.add(btnExportarPdf);
        panelDet.add(header, BorderLayout.NORTH);

        editorHtml = new JEditorPane();
        editorHtml.setContentType("text/html");
        editorHtml.setEditable(false);
        panelDet.add(new JScrollPane(editorHtml), BorderLayout.CENTER);

        panelContainer.add(panelSel, "SELECCION");
        panelContainer.add(panelDet, "DETALLE");
        setContentPane(panelContainer);

        cardLayout.show(panelContainer, "SELECCION");
    }


    public void mostrarAnios(List<Integer> anios) {
        cbAnios.removeAllItems();
        for (Integer a : anios) cbAnios.addItem(a);
        if (cbAnios.getItemCount() > 0) cbAnios.setSelectedIndex(0);
    }

    public void mostrarMesesPorAnio(List<YearMonth> meses) {
        panelMeses.removeAll();
        Locale locale = GestorIdioma.getCurrentLocale();

        for (YearMonth ym : meses) {
            String nombreMes = ym.getMonth().getDisplayName(TextStyle.FULL, locale);
            String nombreMesCapitalizado = nombreMes.substring(0, 1).toUpperCase(locale) + nombreMes.substring(1);
            String texto = nombreMesCapitalizado + " " + ym.getYear();

            JButton btn = new JButton(texto);
            btn.addActionListener(e -> controlador.abrirInforme(ym));
            panelMeses.add(btn);
        }

        panelMeses.revalidate();
        panelMeses.repaint();
    }


    public void mostrarDetalleHtml(String html) {
        editorHtml.setText(html);
        editorHtml.setCaretPosition(0);
        cardLayout.show(panelContainer, "DETALLE");
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                GestorIdioma.getString("ERROR"),
                JOptionPane.ERROR_MESSAGE
        );
    }
}
