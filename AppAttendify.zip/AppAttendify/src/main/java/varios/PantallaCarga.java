package varios;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

import login.vista.LoginVista;

public class PantallaCarga extends JFrame {

    private JProgressBar barraProgreso;
    private JLabel lblCargando;
    private JLabel lblVersion;
    private JPanel panel;
    private Timer timer;
    private int progreso = 0;

    public PantallaCarga() {
        initComponents();
        iniciarCarga();
    }

    private void initComponents() {
        setTitle("Attendify");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        setShape(new RoundRectangle2D.Double(0, 0, 700, 500, 20, 20));

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                GradientPaint gp = new GradientPaint(0, 0, new Color(0, 61, 143),
                        0, getHeight(), new Color(0, 41, 103));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 2));

        JLabel lblLogo = new JLabel();
        lblLogo.setBounds(200, 50, 300, 300);
        try {
            ImageIcon originalIcon = new ImageIcon(getClass().getResource("/imagenes/attendify.png"));
            java.awt.Image img = originalIcon.getImage().getScaledInstance(300, 300, java.awt.Image.SCALE_SMOOTH);
            ImageIcon logo = new ImageIcon(img);
            lblLogo.setIcon(logo);
            lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        } catch (Exception e) {
            lblLogo.setText("Logo AttendIfy");
            lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 24));
            lblLogo.setForeground(Color.WHITE);
            lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
            System.err.println("Error al cargar la imagen: " + e.getMessage());
        }

        barraProgreso = new JProgressBar() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2d.setColor(new Color(240, 240, 240));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);

                int width = (int) (getWidth() * ((double) getValue() / getMaximum()));
                GradientPaint gp = new GradientPaint(0, 0, new Color(0, 230, 118),
                        width, 0, new Color(0, 200, 83));
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, width, getHeight(), 10, 10);

                g2d.setColor(Color.DARK_GRAY);
                String text = getValue() + "%";
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                int textWidth = g2d.getFontMetrics().stringWidth(text);
                g2d.drawString(text, getWidth() / 2 - textWidth / 2, getHeight() / 2 + 5);
            }
        };
        barraProgreso.setBounds(150, 370, 400, 25);
        barraProgreso.setStringPainted(false);
        barraProgreso.setBorderPainted(false);
        barraProgreso.setOpaque(false);

        lblCargando = new JLabel("Iniciando sistema...");
        lblCargando.setBounds(150, 400, 400, 30);
        lblCargando.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblCargando.setForeground(new Color(255, 255, 255, 220));
        lblCargando.setHorizontalAlignment(SwingConstants.CENTER);

        lblVersion = new JLabel("v1.0.0");
        lblVersion.setBounds(600, 460, 80, 30);
        lblVersion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblVersion.setForeground(new Color(255, 255, 255, 150));

        JLabel lblCopyright = new JLabel("© 2025 AttendIfy");
        lblCopyright.setBounds(20, 460, 150, 30);
        lblCopyright.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblCopyright.setForeground(new Color(255, 255, 255, 150));

        JLabel lblClose = new JLabel("×");
        lblClose.setBounds(670, 10, 20, 20);
        lblClose.setFont(new Font("Arial", Font.BOLD, 20));
        lblClose.setForeground(new Color(255, 255, 255, 200));
        lblClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                System.exit(0);
            }

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblClose.setForeground(Color.WHITE);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblClose.setForeground(new Color(255, 255, 255, 200));
            }
        });

        panel.add(lblLogo);
        panel.add(barraProgreso);
        panel.add(lblCargando);
        panel.add(lblVersion);
        panel.add(lblCopyright);
        panel.add(lblClose);

        add(panel);
    }

    private void iniciarCarga() {
        timer = new Timer(40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                progreso++;
                barraProgreso.setValue(progreso);

                if (progreso < 30) {
                    lblCargando.setText("Iniciando sistema...");
                } else if (progreso < 60) {
                    lblCargando.setText("Cargando componentes...");
                } else if (progreso < 90) {
                    lblCargando.setText("Conectando a la base de datos...");
                } else {
                    lblCargando.setText("Completando...");
                }

                if (progreso % 20 == 0) {
                    lblCargando.setForeground(new Color(255, 255, 255, 150));
                } else if (progreso % 10 == 0) {
                    lblCargando.setForeground(new Color(255, 255, 255, 220));
                }

                if (progreso == 100) {
                    timer.stop();
                    abrirLogin();
                }
            }
        });
        timer.start();
    }

    private void abrirLogin() {
        Timer fadeOut = new Timer(50, new ActionListener() {
            float opacity = 1.0f;

            @Override
            public void actionPerformed(ActionEvent e) {
                opacity -= 0.05f;
                if (opacity <= 0.0f) {
                    opacity = 0.0f;
                    ((Timer) e.getSource()).stop();
                    dispose();
                    java.awt.EventQueue.invokeLater(() -> {
                        new LoginVista().setVisible(true);
                    });
                }
                setOpacity(Math.max(0.0f, Math.min(opacity, 1.0f)));
            }
        });
        fadeOut.start();
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Error al aplicar look and feel: " + e.getMessage());
        }

        java.awt.EventQueue.invokeLater(() -> {
            new PantallaCarga().setVisible(true);
        });
    }
}