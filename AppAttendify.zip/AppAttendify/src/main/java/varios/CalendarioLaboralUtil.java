package varios;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.time.Duration;
import java.util.List;
import modelo.HorarioDiaTrabajoDTO;
import modelo.DiaFestivoDTO;
import modelo.VacacionesDTO;

public final class CalendarioLaboralUtil {
    private CalendarioLaboralUtil() { }

    public static int calcularMinutosEsperados(
            LocalDate fecha,
            List<HorarioDiaTrabajoDTO> horarios,
            List<DiaFestivoDTO> festivos,
            List<VacacionesDTO> vacaciones) {

        if (esFestivoOVacaciones(fecha, festivos, vacaciones)) {
            return 0;
        }

        DayOfWeek dow = fecha.getDayOfWeek();
        return horarios.stream()
                .filter(HorarioDiaTrabajoDTO::isActivo)
                .filter(h -> DayOfWeek.of(h.getIdDia()).equals(dow))
                .findFirst()
                .map(h -> {
                    long duracion = Duration.between(h.getHoraEntrada(), h.getHoraSalida()).toMinutes();
                    return (int) (duracion - h.getTiempoDescanso());
                })
                .orElse(0);
    }


    public static boolean esDiaLaborable(
            LocalDate fecha,
            List<HorarioDiaTrabajoDTO> horarios,
            List<DiaFestivoDTO> festivos,
            List<VacacionesDTO> vacaciones) {


        if (esFestivoOVacaciones(fecha, festivos, vacaciones)) {
            return false;
        }

        DayOfWeek dow = fecha.getDayOfWeek();
        return horarios.stream()
                .filter(HorarioDiaTrabajoDTO::isActivo)
                .anyMatch(h -> DayOfWeek.of(h.getIdDia()).equals(dow));
    }

    private static boolean esFestivoOVacaciones(
            LocalDate fecha,
            List<DiaFestivoDTO> festivos,
            List<VacacionesDTO> vacaciones) {
        if (festivos != null && festivos.stream().anyMatch(f -> f.getFecha().equals(fecha))) {
            return true;
        }
        if (vacaciones != null && vacaciones.stream().anyMatch(v ->
                !fecha.isBefore(v.getFechaInicio()) && !fecha.isAfter(v.getFechaFin()))) {
            return true;
        }
        return false;
    }
}
