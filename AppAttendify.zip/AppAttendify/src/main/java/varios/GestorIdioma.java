package varios;

import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JButton;

public class GestorIdioma {
    private static final String BUNDLE_PATH = "idiomas.messages";
    private static ResourceBundle messages;
    private static Locale currentLocale;

    static {
        currentLocale = new Locale("es", "ES");
        messages = ResourceBundle.getBundle(BUNDLE_PATH, currentLocale);
    }

    public static ResourceBundle cambiarIdioma(String language, String country) {
        currentLocale = new Locale(language, country);
        messages = ResourceBundle.getBundle(BUNDLE_PATH, currentLocale);
        return messages;
    }

    public static String getString(String key) {
        try {
            return messages.getString(key);
        } catch (Exception e) {
            System.err.println("Clave no encontrada: " + key);
            return key;
        }
    }

    public static void actualizarTexto(JComponent componente, String key) {
        String texto = getString(key);

        if (componente instanceof JLabel) {
            ((JLabel) componente).setText(texto);
        } else if (componente instanceof JButton) {
            ((JButton) componente).setText(texto);
        } else if (componente instanceof JMenu) {
            ((JMenu) componente).setText(texto);
        } else if (componente instanceof JMenuItem) {
            ((JMenuItem) componente).setText(texto);
        }
    }

    public static ResourceBundle getBundle() {
        return messages;
    }

    public static Locale getCurrentLocale() {
        return currentLocale;
    }

    public static boolean isSpanish() {
        return "es".equals(currentLocale.getLanguage());
    }

    public static boolean isEnglish() {
        return "en".equals(currentLocale.getLanguage());
    }
}