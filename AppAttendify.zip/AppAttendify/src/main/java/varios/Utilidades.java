package varios;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Utilidades {

    public static void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void mostrarInformacion(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean campoVacio(JTextField campo) {
        return campo.getText().trim().isEmpty();
    }

    public static boolean campoVacio(JPasswordField campo) {
        return new String(campo.getPassword()).trim().isEmpty();
    }

    public static void ajustarImagen(JLabel label, String rutaImagen) {
        ImageIcon imagen = new ImageIcon(rutaImagen);
        Image img = imagen.getImage();
        Image imgRedimensionada = img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        label.setIcon(new ImageIcon(imgRedimensionada));
    }
}