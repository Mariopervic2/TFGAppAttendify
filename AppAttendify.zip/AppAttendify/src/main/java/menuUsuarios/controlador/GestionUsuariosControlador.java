package menuUsuarios.controlador;

import accesoDatos.EmpleadoDAO;
import accesoDatos.UsuarioDAO;
import modelo.EmpleadoDTO;
import modelo.UsuarioDTO;
import menuUsuarios.vista.GestionUsuariosVista;
import varios.GestorIdioma;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GestionUsuariosControlador {
    private static final String KEY_DLG_TITLE_ERROR = "GU_DLG_TITLE_ERROR";
    private static final String KEY_DLG_TITLE_INFO = "GU_DLG_TITLE_INFO";
    private static final String KEY_MSG_ERROR_CARGAR_USUARIOS = "GU_MSG_ERROR_CARGAR_USUARIOS";
    private static final String KEY_MSG_ERROR_CARGAR_EMPLEADOS = "GU_MSG_ERROR_CARGAR_EMPLEADOS";
    private static final String KEY_MSG_USERNAME_INUSE = "GU_MSG_USERNAME_INUSE";
    private static final String KEY_MSG_USERNAME_INUSE_OTHER = "GU_MSG_USERNAME_INUSE_OTHER";
    private static final String KEY_MSG_SUCCESS_USUARIO_CREADO = "GU_MSG_SUCCESS_USUARIO_CREADO";
    private static final String KEY_MSG_FAIL_USUARIO_CREADO = "GU_MSG_FAIL_USUARIO_CREADO";
    private static final String KEY_MSG_ERROR_CREATING_USUARIO = "GU_MSG_ERROR_CREATING_USUARIO";
    private static final String KEY_MSG_SUCCESS_USUARIO_ACTUALIZ = "GU_MSG_SUCCESS_USUARIO_ACTUALIZ";
    private static final String KEY_MSG_FAIL_USUARIO_ACTUALIZ = "GU_MSG_FAIL_USUARIO_ACTUALIZ";
    private static final String KEY_MSG_ERROR_UPDATING_USUARIO = "GU_MSG_ERROR_UPDATING_USUARIO";
    private static final String KEY_MSG_SUCCESS_USUARIO_ELIMINADO = "GU_MSG_SUCCESS_USUARIO_ELIMINADO";
    private static final String KEY_MSG_FAIL_USUARIO_ELIMINADO = "GU_MSG_FAIL_USUARIO_ELIMINADO";
    private static final String KEY_MSG_ERROR_DELETING_USUARIO = "GU_MSG_ERROR_DELETING_USUARIO";

    private GestionUsuariosVista vista;
    private UsuarioDAO usuarioDAO;
    private EmpleadoDAO empleadoDAO;
    private JPanel contenedor;
    private JPanel panelAnterior;

    public GestionUsuariosControlador(Connection conexion, JPanel contenedor, JPanel panelAnterior) {
        this.usuarioDAO = new UsuarioDAO(conexion);
        this.empleadoDAO = new EmpleadoDAO(conexion);
        this.contenedor = contenedor;
        this.panelAnterior = panelAnterior;

        this.vista = new GestionUsuariosVista();
        this.vista.setControlador(this);

        cargarUsuarios();
    }

    public void mostrar() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        contenedor.add(vista, "menuUsuarios");
        cl.show(contenedor, "menuUsuarios");
    }

    public void volverMenuPrincipal() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, "principal");
    }

    public void cargarUsuarios() {
        try {
            List<UsuarioDTO> usuarios = usuarioDAO.obtenerTodosUsuarios();
            vista.actualizarTablaUsuarios(usuarios);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_ERROR_CARGAR_USUARIOS) + " " + e.getMessage(),
                    GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public List<EmpleadoDTO> obtenerEmpleados() {
        try {
            return empleadoDAO.obtenerTodosEmpleados();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_ERROR_CARGAR_EMPLEADOS) + " " + e.getMessage(),
                    GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return new ArrayList<>();
        }
    }

    public boolean crearUsuario(UsuarioDTO usuario) {
        try {
            if (usuarioDAO.existeUsername(usuario.getUsername(), null)) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_USERNAME_INUSE),
                        GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = usuarioDAO.crearUsuario(usuario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_USUARIO_CREADO),
                        GestorIdioma.getString(KEY_DLG_TITLE_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarUsuarios();
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_FAIL_USUARIO_CREADO),
                        GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                        JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_ERROR_CREATING_USUARIO) + " " + e.getMessage(),
                    GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean actualizarUsuario(UsuarioDTO usuario) {
        try {
            if (usuarioDAO.existeUsername(usuario.getUsername(), usuario.getIdUsuario())) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_USERNAME_INUSE_OTHER),
                        GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = usuarioDAO.actualizarUsuario(usuario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_USUARIO_ACTUALIZ),
                        GestorIdioma.getString(KEY_DLG_TITLE_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarUsuarios();
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_FAIL_USUARIO_ACTUALIZ),
                        GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                        JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_ERROR_UPDATING_USUARIO) + " " + e.getMessage(),
                    GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean eliminarUsuario(int idUsuario) {
        try {
            boolean resultado = usuarioDAO.eliminarUsuario(idUsuario);
            if (resultado) {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_SUCCESS_USUARIO_ELIMINADO),
                        GestorIdioma.getString(KEY_DLG_TITLE_INFO),
                        JOptionPane.INFORMATION_MESSAGE);
                cargarUsuarios();
            } else {
                JOptionPane.showMessageDialog(vista,
                        GestorIdioma.getString(KEY_MSG_FAIL_USUARIO_ELIMINADO),
                        GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                        JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString(KEY_MSG_ERROR_DELETING_USUARIO) + " " + e.getMessage(),
                    GestorIdioma.getString(KEY_DLG_TITLE_ERROR),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
