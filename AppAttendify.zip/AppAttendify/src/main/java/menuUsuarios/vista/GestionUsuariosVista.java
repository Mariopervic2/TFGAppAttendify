package menuUsuarios.vista;

import menuUsuarios.controlador.GestionUsuariosControlador;
import modelo.EmpleadoDTO;
import modelo.UsuarioDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class GestionUsuariosVista extends JPanel {
    private GestionUsuariosControlador controlador;
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;
    private JButton btnCrearUsuario;
    private JButton btnVolver;
    private JTextField txtBuscar;

    private static final String KEY_TITULO = "GESTION_USUARIOS_TITULO";
    private static final String KEY_BUSCAR_LABEL = "GESTION_USUARIOS_BUSCAR";
    private static final String KEY_BTN_CREAR = "GESTION_USUARIOS_BTN_CREAR";
    private static final String KEY_BTN_VOLVER = "GESTION_USUARIOS_BTN_VOLVER";
    private static final String[] KEY_COLUMNAS = {
            "GESTION_USUARIOS_COL_ID",
            "GESTION_USUARIOS_COL_EMPLEADO",
            "GESTION_USUARIOS_COL_USERNAME",
            "GESTION_USUARIOS_COL_PASSWORD",
            "GESTION_USUARIOS_COL_ROL",
            "GESTION_USUARIOS_COL_EDITAR",
            "GESTION_USUARIOS_COL_ELIMINAR"
    };

    public GestionUsuariosVista() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        inicializarComponentes();
        actualizarTextos();
    }

    private void inicializarComponentes() {
        JPanel panelNorte = new JPanel(new BorderLayout(5, 10));

        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel();
        lblTitulo.setFont(new Font("Dialog", Font.BOLD, 18));
        panelTitulo.add(lblTitulo);
        panelNorte.add(panelTitulo, BorderLayout.NORTH);

        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        txtBuscar = new JTextField(20);
        JLabel lblBuscar = new JLabel();
        panelBusqueda.add(lblBuscar, BorderLayout.WEST);
        panelBusqueda.add(txtBuscar, BorderLayout.CENTER);
        panelNorte.add(panelBusqueda, BorderLayout.CENTER);

        add(panelNorte, BorderLayout.NORTH);

        String[] columnas = new String[KEY_COLUMNAS.length];
        for (int i = 0; i < KEY_COLUMNAS.length; i++) {
            columnas[i] = GestorIdioma.getString(KEY_COLUMNAS[i]);
        }
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5 || column == 6;
            }
        };

        tablaUsuarios = new JTable(modeloTabla);
        JTableHeader header = tablaUsuarios.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD));
        header.setBackground(new Color(220, 220, 220));


        int[] widths = {40, 150, 100, 100, 100, 70, 70};
        for (int i = 0; i < widths.length; i++) {
            tablaUsuarios.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        tablaUsuarios.getColumnModel().getColumn(0).setMinWidth(0);
        tablaUsuarios.getColumnModel().getColumn(0).setMaxWidth(0);

        add(new JScrollPane(tablaUsuarios), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnCrearUsuario = new JButton();
        btnVolver = new JButton();
        panelBotones.add(btnCrearUsuario);
        panelBotones.add(btnVolver);
        add(panelBotones, BorderLayout.SOUTH);

        btnCrearUsuario.addActionListener((ActionEvent e) -> mostrarFormularioUsuario(null));
        btnVolver.addActionListener((ActionEvent e) -> controlador.volverMenuPrincipal());

        configurarFiltrado();
    }

    private void actualizarTextos() {
        JLabel lblTitulo = (JLabel) ((JPanel) ((JPanel) getComponent(0)).getComponent(0)).getComponent(0);
        lblTitulo.setText(GestorIdioma.getString(KEY_TITULO));
        JLabel lblBuscar = (JLabel) ((JPanel) ((JPanel) getComponent(0)).getComponent(1)).getComponent(0);
        lblBuscar.setText(GestorIdioma.getString(KEY_BUSCAR_LABEL));
        btnCrearUsuario.setText(GestorIdioma.getString(KEY_BTN_CREAR));
        btnVolver.setText(GestorIdioma.getString(KEY_BTN_VOLVER));

        for (int i = 0; i < KEY_COLUMNAS.length; i++) {
            tablaUsuarios.getColumnModel()
                    .getColumn(i)
                    .setHeaderValue(GestorIdioma.getString(KEY_COLUMNAS[i]));
        }
        tablaUsuarios.getTableHeader().repaint();
    }

    public void setControlador(GestionUsuariosControlador controlador) {
        this.controlador = controlador;
    }

    public void actualizarTablaUsuarios(List<UsuarioDTO> usuarios) {
        if (tablaUsuarios.getCellEditor() != null) tablaUsuarios.getCellEditor().stopCellEditing();
        modeloTabla.setRowCount(0);
        for (UsuarioDTO u : usuarios) {
            modeloTabla.addRow(new Object[]{
                    u.getIdUsuario(),
                    u.getNombreEmpleado(),
                    u.getUsername(),
                    "••••••",
                    u.getRol(),
                    u,
                    u
            });
        }
        tablaUsuarios.getColumnModel().getColumn(4).setCellRenderer(new RolCellRenderer());
        tablaUsuarios.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer(GestorIdioma.getString("GESTION_USUARIOS_COL_EDITAR")));
        tablaUsuarios.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(GestorIdioma.getString("GESTION_USUARIOS_COL_EDITAR")));
        tablaUsuarios.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer(GestorIdioma.getString("GESTION_USUARIOS_COL_ELIMINAR")));
        tablaUsuarios.getColumnModel().getColumn(6).setCellEditor(new ButtonEditor(GestorIdioma.getString("GESTION_USUARIOS_COL_ELIMINAR")));
    }

    private boolean confirmarEliminacion(UsuarioDTO usuario) {
        if (usuario == null) {
            JOptionPane.showMessageDialog(this,
                    GestorIdioma.getString("GESTION_USUARIOS_ERROR_INVALIDO"),
                    GestorIdioma.getString("DIALOGO_TITULO_ERROR"),
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        int opc = JOptionPane.showConfirmDialog(this,
                String.format(GestorIdioma.getString("GESTION_USUARIOS_CONFIRMAR_ELIMINAR"), usuario.getUsername()),
                GestorIdioma.getString("DIALOGO_TITULO_CONFIRMAR"),
                JOptionPane.YES_NO_OPTION);
        return opc == JOptionPane.YES_OPTION;
    }

    public void mostrarFormularioUsuario(UsuarioDTO usuario) {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), true);
        FormularioUsuarioPanel form = new FormularioUsuarioPanel(controlador, usuario, dialog);
        dialog.setContentPane(form);
        dialog.setTitle(usuario == null
                ? GestorIdioma.getString("GESTION_USUARIOS_FORM_CREAR")
                : GestorIdioma.getString("GESTION_USUARIOS_FORM_EDITAR"));
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String text) {
            super(text);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object v, boolean s, boolean f, int r, int c) {
            setText(getText());
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private final JButton button;
        private final String actionType;
        private UsuarioDTO current;

        public ButtonEditor(String actionType) {
            super(new JCheckBox());
            this.actionType = actionType;
            button = new JButton(actionType);
            button.addActionListener(e -> {
                if (actionType.equals(GestorIdioma.getString("GESTION_USUARIOS_COL_EDITAR"))) {
                    mostrarFormularioUsuario(current);
                } else {
                    if (confirmarEliminacion(current)) {
                        controlador.eliminarUsuario(current.getIdUsuario());
                    }
                }
                fireEditingStopped();
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            int modelRow = table.convertRowIndexToModel(row);
            current = (UsuarioDTO) table.getModel().getValueAt(modelRow, column);
            return button;
        }
    }

    class FormularioUsuarioPanel extends JPanel {
        private final GestionUsuariosControlador controlador;
        private final UsuarioDTO usuario;
        private final JDialog dialog;
        private JComboBox<RolItem> cmbRol;
        private JComboBox<EmpleadoDTO> cmbEmpleado;
        private JTextField txtUsername;
        private JPasswordField txtPassword;
        private JButton btnGuardar, btnCancelar;

        public FormularioUsuarioPanel(GestionUsuariosControlador controlador, UsuarioDTO usuario, JDialog dialog) {
            this.controlador = controlador;
            this.usuario = usuario;
            this.dialog = dialog;
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            inicializarFormulario();
            cargarDatos();
        }

        private void inicializarFormulario() {
            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            gbc.gridx = 0;
            gbc.gridy = 0;
            panel.add(new JLabel(GestorIdioma.getString("GESTION_USUARIOS_FORM_LABEL_EMPLEADO")), gbc);
            cmbEmpleado = new JComboBox<>();
            for (EmpleadoDTO e : controlador.obtenerEmpleados()) {
                cmbEmpleado.addItem(e);
            }
            gbc.gridx = 1;
            panel.add(cmbEmpleado, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            panel.add(new JLabel(GestorIdioma.getString("GESTION_USUARIOS_FORM_LABEL_USERNAME")), gbc);
            txtUsername = new JTextField(20);
            gbc.gridx = 1;
            panel.add(txtUsername, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            panel.add(new JLabel(GestorIdioma.getString("GESTION_USUARIOS_FORM_LABEL_PASSWORD")), gbc);
            txtPassword = new JPasswordField(20);
            gbc.gridx = 1;
            panel.add(txtPassword, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            panel.add(new JLabel(GestorIdioma.getString("GESTION_USUARIOS_FORM_LABEL_ROL")), gbc);
            cmbRol = new JComboBox<>(new RolItem[]{
                    new RolItem("Administrador", GestorIdioma.getString("GESTION_USUARIOS_FORM_OPC_ROL_ADMIN")),
                    new RolItem("Empleado", GestorIdioma.getString("GESTION_USUARIOS_FORM_OPC_ROL_EMPLEADO"))
            });
            gbc.gridx = 1;
            panel.add(cmbRol, gbc);

            add(panel, BorderLayout.CENTER);

            JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            btnGuardar = new JButton(GestorIdioma.getString("GESTION_USUARIOS_FORM_BTN_GUARDAR"));
            btnCancelar = new JButton(GestorIdioma.getString("GESTION_USUARIOS_FORM_BTN_CANCELAR"));
            btnGuardar.addActionListener(e -> guardarUsuario());
            btnCancelar.addActionListener(e -> dialog.dispose());
            botones.add(btnGuardar);
            botones.add(btnCancelar);
            add(botones, BorderLayout.SOUTH);
        }

        private void cargarDatos() {
            if (usuario != null) {
                int idEmp = usuario.getIdEmpleado();
                for (int i = 0; i < cmbEmpleado.getItemCount(); i++) {
                    if (cmbEmpleado.getItemAt(i).getIdEmpleado() == idEmp) {
                        cmbEmpleado.setSelectedIndex(i);
                        break;
                    }
                }
                txtUsername.setText(usuario.getUsername());
                txtPassword.setText(usuario.getPassword());
                for (int i = 0; i < cmbRol.getItemCount(); i++) {
                    if (cmbRol.getItemAt(i).getDatabaseValue().equals(usuario.getRol())) {
                        cmbRol.setSelectedIndex(i);
                        break;
                    }
                }
            }
        }

        private void guardarUsuario() {
            if (txtUsername.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("GESTION_USUARIOS_FORM_ERROR_USER_VACIO"),
                        GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (txtPassword.getPassword().length == 0) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("GESTION_USUARIOS_FORM_ERROR_PASS_VACIO"),
                        GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
                return;
            }
            UsuarioDTO dto = new UsuarioDTO();
            if (usuario != null) dto.setIdUsuario(usuario.getIdUsuario());
            EmpleadoDTO selEmp = (EmpleadoDTO) cmbEmpleado.getSelectedItem();
            dto.setIdEmpleado(selEmp != null ? selEmp.getIdEmpleado() : 0);
            dto.setUsername(txtUsername.getText().trim());
            dto.setPassword(new String(txtPassword.getPassword()));
            RolItem selectedRol = (RolItem) cmbRol.getSelectedItem();
            dto.setRol(selectedRol.getDatabaseValue());

            boolean exito = (usuario == null)
                    ? controlador.crearUsuario(dto)
                    : controlador.actualizarUsuario(dto);
            if (exito) dialog.dispose();
        }
    }

    private void configurarFiltrado() {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modeloTabla);
        tablaUsuarios.setRowSorter(sorter);
        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                filtrar(sorter);
            }

            public void removeUpdate(DocumentEvent e) {
                filtrar(sorter);
            }

            public void changedUpdate(DocumentEvent e) {
                filtrar(sorter);
            }

            private void filtrar(TableRowSorter<DefaultTableModel> sorter) {
                String texto = txtBuscar.getText().trim().toLowerCase();
                if (texto.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 1));
                }
            }
        });
    }

    class RolItem {
        private String databaseValue;
        private String displayValue;

        public RolItem(String databaseValue, String displayValue) {
            this.databaseValue = databaseValue;
            this.displayValue = displayValue;
        }

        public String getDatabaseValue() {
            return databaseValue;
        }

        @Override
        public String toString() {
            return displayValue;
        }
    }

    class RolCellRenderer extends JLabel implements TableCellRenderer {
        public RolCellRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            String rol = value instanceof String ? (String) value : "";
            if ("Administrador".equals(rol)) {
                setText(GestorIdioma.getString("GESTION_USUARIOS_FORM_OPC_ROL_ADMIN"));
            } else if ("Empleado".equals(rol)) {
                setText(GestorIdioma.getString("GESTION_USUARIOS_FORM_OPC_ROL_EMPLEADO"));
            } else {
                setText(rol);
            }
            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
            return this;
        }
    }
}