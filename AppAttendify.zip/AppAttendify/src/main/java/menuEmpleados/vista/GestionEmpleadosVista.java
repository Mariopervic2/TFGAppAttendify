package menuEmpleados.vista;

import menuEmpleados.controlador.GestionEmpleadosControlador;
import modelo.EmpleadoDTO;
import modelo.HorarioDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.RowFilter;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

public class GestionEmpleadosVista extends JPanel {
    private static final String KEY_TITLE = "GE_TITLE";
    private static final String[] KEY_COLS = {
            "GE_COL_ID", "GE_COL_NAME", "GE_COL_DNI",
            "GE_COL_EMAIL", "GE_COL_PUESTO",
            "GE_COL_EDIT", "GE_COL_DELETE"
    };
    private static final String KEY_BTN_CREATE = "GE_BTN_CREATE";
    private static final String KEY_BTN_BACK = "GE_BTN_BACK";
    private static final String KEY_CONFIRM_DELETE = "GE_CONFIRM_DELETE";
    private static final String KEY_MSG_LOAD_ERROR = "GE_MSG_LOAD_ERROR";
    private static final String KEY_DIALOG_ERROR = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOG_CONFIRM = "DIALOGO_TITULO_CONFIRMAR";
    private static final String KEY_FILTER_LABEL = "GE_FILTER_LABEL";

    private GestionEmpleadosControlador controlador;
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private JTextField txtFiltro;
    private JButton btnCrearEmpleado;
    private JButton btnVolver;

    public GestionEmpleadosVista() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));

        JLabel lblTitulo = new JLabel(GestorIdioma.getString(KEY_TITLE));
        lblTitulo.setFont(new Font("Dialog", Font.BOLD, 18));
        panelSuperior.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelFiltro.add(new JLabel(GestorIdioma.getString(KEY_FILTER_LABEL)));
        txtFiltro = new JTextField(20);
        panelFiltro.add(txtFiltro);
        panelSuperior.add(panelFiltro, BorderLayout.SOUTH);

        add(panelSuperior, BorderLayout.NORTH);

        String[] columnas = new String[KEY_COLS.length];
        for (int i = 0; i < KEY_COLS.length; i++) {
            columnas[i] = GestorIdioma.getString(KEY_COLS[i]);
        }
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return col == 5 || col == 6;
            }
        };
        tablaEmpleados = new JTable(modeloTabla);
        rowSorter = new TableRowSorter<>(modeloTabla);
        tablaEmpleados.setRowSorter(rowSorter);

        JTableHeader header = tablaEmpleados.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD));
        header.setBackground(new Color(220, 220, 220));

        tablaEmpleados.getColumnModel().getColumn(0).setMinWidth(0);
        tablaEmpleados.getColumnModel().getColumn(0).setMaxWidth(0);
        tablaEmpleados.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaEmpleados.getColumnModel().getColumn(2).setPreferredWidth(100);
        tablaEmpleados.getColumnModel().getColumn(3).setPreferredWidth(150);
        tablaEmpleados.getColumnModel().getColumn(4).setPreferredWidth(100);
        tablaEmpleados.getColumnModel().getColumn(5).setPreferredWidth(70);
        tablaEmpleados.getColumnModel().getColumn(6).setPreferredWidth(70);

        add(new JScrollPane(tablaEmpleados), BorderLayout.CENTER);

        txtFiltro.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String texto = txtFiltro.getText().trim();
                if (texto.length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 1));
                }
            }
        });

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnCrearEmpleado = new JButton(GestorIdioma.getString(KEY_BTN_CREATE));
        btnVolver = new JButton(GestorIdioma.getString(KEY_BTN_BACK));
        panelBotones.add(btnCrearEmpleado);
        panelBotones.add(btnVolver);
        add(panelBotones, BorderLayout.SOUTH);

        btnCrearEmpleado.addActionListener(e -> mostrarFormularioEmpleado(null));
        btnVolver.addActionListener(e -> controlador.volverMenuPrincipal());
    }

    public void setControlador(GestionEmpleadosControlador controlador) {
        this.controlador = controlador;
    }

    public void actualizarTablaEmpleados(List<EmpleadoDTO> empleados) {
        modeloTabla.setRowCount(0);
        for (EmpleadoDTO emp : empleados) {
            modeloTabla.addRow(new Object[]{
                    emp.getIdEmpleado(),
                    emp.getNombreCompleto(),
                    emp.getDni(),
                    emp.getEmail(),
                    emp.getPuesto(),
                    emp, emp
            });
        }
        tablaEmpleados.getColumnModel().getColumn(5)
                .setCellRenderer(new ButtonRenderer(GestorIdioma.getString(KEY_COLS[5])));
        tablaEmpleados.getColumnModel().getColumn(5)
                .setCellEditor(new ButtonEditor(GestorIdioma.getString(KEY_COLS[5])));
        tablaEmpleados.getColumnModel().getColumn(6)
                .setCellRenderer(new ButtonRenderer(GestorIdioma.getString(KEY_COLS[6])));
        tablaEmpleados.getColumnModel().getColumn(6)
                .setCellEditor(new ButtonEditor(GestorIdioma.getString(KEY_COLS[6])));
    }

    private boolean confirmarEliminacion(EmpleadoDTO emp) {
        int opcion = JOptionPane.showConfirmDialog(this,
                GestorIdioma.getString(KEY_CONFIRM_DELETE).replace("{0}", emp.getNombreCompleto()),
                GestorIdioma.getString(KEY_DIALOG_CONFIRM),
                JOptionPane.YES_NO_OPTION);
        return opcion == JOptionPane.YES_OPTION;
    }

    public void mostrarFormularioEmpleado(EmpleadoDTO empleado) {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), true);
        FormularioEmpleadoPanel form = new FormularioEmpleadoPanel(controlador, empleado, dialog);
        dialog.setContentPane(form);
        dialog.setTitle(empleado == null
                ? GestorIdioma.getString("FEP_TITLE_CREATE")
                : GestorIdioma.getString("FEP_TITLE_EDIT"));
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String text) {
            super(text);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            setText(getText());
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private final JButton button;
        private final String actionType;
        private EmpleadoDTO current;
        private boolean deleteInProgress = false;

        public ButtonEditor(String actionType) {
            super(new JCheckBox());
            this.actionType = actionType;
            this.button = new JButton(actionType);
            button.addActionListener(e -> {
                if (actionType.equals(GestorIdioma.getString(KEY_COLS[5]))) {
                    mostrarFormularioEmpleado(current);
                    fireEditingStopped();
                } else {
                    if (confirmarEliminacion(current)) {
                        deleteInProgress = true;
                        fireEditingStopped();
                        controlador.eliminarEmpleado(current.getIdEmpleado());
                    } else {
                        fireEditingStopped();
                    }
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            int modelRow = table.convertRowIndexToModel(row);
            current = (EmpleadoDTO) table.getModel().getValueAt(modelRow, column);
            deleteInProgress = false;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return current;
        }

        @Override
        public boolean stopCellEditing() {
            deleteInProgress = false;
            return super.stopCellEditing();
        }

        @Override
        public void cancelCellEditing() {
            deleteInProgress = false;
            super.cancelCellEditing();
        }
    }

    class FormularioEmpleadoPanel extends JPanel {
        private final GestionEmpleadosControlador controlador;
        private final EmpleadoDTO empleado;
        private final JDialog dialog;
        private JTextField txtNombre, txtApellidos, txtDni, txtTelefono, txtEmail, txtPuesto;
        private JComboBox<HorarioDTO> cmbHorario;
        private JButton btnGuardar, btnCancelar;

        public FormularioEmpleadoPanel(GestionEmpleadosControlador controlador,
                                       EmpleadoDTO empleado, JDialog dialog) {
            this.controlador = controlador;
            this.empleado = empleado;
            this.dialog = dialog;
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            inicializarFormulario();
            cargarDatos();
        }

        private void inicializarFormulario() {
            JPanel panelFormulario = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            gbc.gridx = 0;
            gbc.gridy = 0;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_NOMBRE")), gbc);
            txtNombre = new JTextField(20);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            panelFormulario.add(txtNombre, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.weightx = 0;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_APELLIDOS")), gbc);
            txtApellidos = new JTextField(20);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            panelFormulario.add(txtApellidos, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_DNI")), gbc);
            txtDni = new JTextField(20);
            gbc.gridx = 1;
            panelFormulario.add(txtDni, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_TELEFONO")), gbc);
            txtTelefono = new JTextField(20);
            gbc.gridx = 1;
            panelFormulario.add(txtTelefono, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_EMAIL")), gbc);
            txtEmail = new JTextField(20);
            gbc.gridx = 1;
            panelFormulario.add(txtEmail, gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_PUESTO")), gbc);
            txtPuesto = new JTextField(20);
            gbc.gridx = 1;
            panelFormulario.add(txtPuesto, gbc);

            gbc.gridx = 0;
            gbc.gridy = 6;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_LABEL_HORARIO")), gbc);

            cmbHorario = new JComboBox<>();
            cmbHorario.addItem(new HorarioDTO(0,
                    GestorIdioma.getString("FEP_OPT_NONE"),
                    0));

            try {
                for (HorarioDTO h : controlador.obtenerHorarios()) {
                    cmbHorario.addItem(h);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("FEP_MSG_LOAD_ERROR") + ": " + ex.getMessage(),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
            }

            gbc.gridx = 1;
            panelFormulario.add(cmbHorario, gbc);


            gbc.gridx = 0;
            gbc.gridy = 7;
            gbc.gridwidth = 2;
            panelFormulario.add(new JLabel(GestorIdioma.getString("FEP_NOTE_REQUIRED")), gbc);

            add(panelFormulario, BorderLayout.CENTER);

            JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            btnGuardar = new JButton(GestorIdioma.getString("FEP_BTN_SAVE"));
            btnCancelar = new JButton(GestorIdioma.getString("FEP_BTN_CANCEL"));
            btnGuardar.addActionListener(e -> guardarEmpleado());
            btnCancelar.addActionListener(e -> dialog.dispose());
            panelBotones.add(btnGuardar);
            panelBotones.add(btnCancelar);
            add(panelBotones, BorderLayout.SOUTH);
        }

        private void cargarDatos() {
            if (empleado != null) {
                txtNombre.setText(empleado.getNombre());
                txtApellidos.setText(empleado.getApellidos());
                txtDni.setText(empleado.getDni());
                txtTelefono.setText(empleado.getTelefono());
                txtEmail.setText(empleado.getEmail());
                txtPuesto.setText(empleado.getPuesto());
                if (empleado.getIdHorario() > 0) {
                    for (int i = 0; i < cmbHorario.getItemCount(); i++) {
                        if (cmbHorario.getItemAt(i).getIdHorario() == empleado.getIdHorario()) {
                            cmbHorario.setSelectedIndex(i);
                            break;
                        }
                    }
                } else cmbHorario.setSelectedIndex(0);
            }
        }

        private void guardarEmpleado() {
            if (txtNombre.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("FEP_MSG_NAME_REQUIRED"),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (txtApellidos.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("FEP_MSG_SURNAME_REQUIRED"),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (txtDni.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        GestorIdioma.getString("FEP_MSG_DNI_REQUIRED"),
                        GestorIdioma.getString(KEY_DIALOG_ERROR),
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            EmpleadoDTO dto = new EmpleadoDTO();
            if (empleado != null) dto.setIdEmpleado(empleado.getIdEmpleado());
            dto.setNombre(txtNombre.getText().trim());
            dto.setApellidos(txtApellidos.getText().trim());
            dto.setDni(txtDni.getText().trim());
            dto.setTelefono(txtTelefono.getText().trim());
            dto.setEmail(txtEmail.getText().trim());
            dto.setPuesto(txtPuesto.getText().trim());
            HorarioDTO sel = (HorarioDTO) cmbHorario.getSelectedItem();
            dto.setIdHorario(sel != null ? sel.getIdHorario() : 0);

            boolean exito = (empleado == null)
                    ? controlador.crearEmpleado(dto)
                    : controlador.actualizarEmpleado(dto);
            if (exito) dialog.dispose();
        }
    }
}
