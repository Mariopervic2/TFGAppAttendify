package menuEmpleados.controlador;

import accesoDatos.EmpleadoDAO;
import accesoDatos.HorarioDAO;
import modelo.HorarioDTO;
import modelo.EmpleadoDTO;
import menuEmpleados.vista.GestionEmpleadosVista;
import varios.GestorIdioma;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GestionEmpleadosControlador {
    private GestionEmpleadosVista vista;
    private EmpleadoDAO empleadoDAO;
    private HorarioDAO horarioDAO;
    private JPanel contenedor;
    private JPanel panelAnterior;

    public GestionEmpleadosControlador(Connection conexion, JPanel contenedor, JPanel panelAnterior) {
        this.empleadoDAO = new EmpleadoDAO(conexion);
        this.horarioDAO  = new HorarioDAO(conexion);
        this.contenedor = contenedor;
        this.panelAnterior = panelAnterior;

        this.vista = new GestionEmpleadosVista();
        this.vista.setControlador(this);

        cargarEmpleados();
    }

    public void mostrar() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        contenedor.add(vista, "menuEmpleados");
        cl.show(contenedor, "menuEmpleados");
    }

    public void volverMenuPrincipal() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, "principal");
    }

    public void cargarEmpleados() {
        try {
            List<EmpleadoDTO> empleados = empleadoDAO.obtenerTodosEmpleados();
            vista.actualizarTablaEmpleados(empleados);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar los empleados: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean crearEmpleado(EmpleadoDTO empleado) {
        try {
            if (empleadoDAO.existeDNI(empleado.getDni(), null)) {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("DNI_YA"),
                        "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = empleadoDAO.crearEmpleado(empleado);
            if (resultado) {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("EMPLEADO_CORRECTAMENTE"),
                        GestorIdioma.getString("DIALOGO_TITULO_INFO"), JOptionPane.INFORMATION_MESSAGE);
                cargarEmpleados();
            } else {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("ERROR_CREAR_EMPLE"),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, GestorIdioma.getString("ERR_GEN_EMPLE") + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean actualizarEmpleado(EmpleadoDTO empleado) {
        try {
            if (empleadoDAO.existeDNI(empleado.getDni(), empleado.getIdEmpleado())) {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("DNI_YA"),
                        "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            boolean resultado = empleadoDAO.actualizarEmpleado(empleado);
            if (resultado) {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("EMPLEADO_ACTU_BIEN"),
                        GestorIdioma.getString("DIALOGO_TITULO_INFO"), JOptionPane.INFORMATION_MESSAGE);
                cargarEmpleados();
            } else {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("EMPLEADO_ACTU_ERR"),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, GestorIdioma.getString("ERR_ACT_EMPLE") + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean eliminarEmpleado(int idEmpleado) {
        try {
            boolean resultado = empleadoDAO.eliminarEmpleado(idEmpleado);
            if (resultado) {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("EMP_ELIM_CORR"),
                        GestorIdioma.getString("DIALOGO_TITULO_INFO"), JOptionPane.INFORMATION_MESSAGE);
                cargarEmpleados();
            } else {
                JOptionPane.showMessageDialog(vista, GestorIdioma.getString("NO_ELIM_EMPLE"),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
            return resultado;
        } catch (SQLException e) {
            if (e.getMessage().contains("foreign key constraint") || e.getMessage().contains("constraint violation")) {
                JOptionPane.showMessageDialog(vista,
                        "No se puede eliminar el empleado porque tiene registros asociados.",
                        "Error de restricción", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error al eliminar el empleado: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        }
    }

    public List<HorarioDTO> obtenerHorarios() {
        try {
            return horarioDAO.obtenerTodosHorarios();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    "Error al cargar los horarios: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return new ArrayList<>();
        }
    }

}