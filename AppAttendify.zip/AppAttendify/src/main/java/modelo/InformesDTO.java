package modelo;

import java.time.YearMonth;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class InformesDTO {
    private int idEmpleado;
    private YearMonth mes;
    private String nombreEmpleado;
    private String horarioDescripcion;
    private double horasPrevistas;
    private double horasTrabajadas;
    private double horasExtra;
    private List<RegistroDTO> registrosDiarios;
    private int idHorario;

    public int getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(int idHorario) {
        this.idHorario = idHorario;
    }


    private Locale locale;
    private ResourceBundle bundle;
    private List<HorarioDiaTrabajoDTO> horarioDias;
    private List<DiaFestivoDTO> diasFestivos;
    private List<VacacionesDTO> vacaciones;

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public YearMonth getMes() {
        return mes;
    }

    public void setMes(YearMonth mes) {
        this.mes = mes;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getHorarioDescripcion() {
        return horarioDescripcion;
    }

    public void setHorarioDescripcion(String horarioDescripcion) {
        this.horarioDescripcion = horarioDescripcion;
    }

    public double getHorasPrevistas() {
        return horasPrevistas;
    }

    public void setHorasPrevistas(double horasPrevistas) {
        this.horasPrevistas = horasPrevistas;
    }

    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getHorasExtra() {
        return horasExtra;
    }

    public void setHorasExtra(double horasExtra) {
        this.horasExtra = horasExtra;
    }

    public List<RegistroDTO> getRegistrosDiarios() {
        return registrosDiarios;
    }

    public void setRegistrosDiarios(List<RegistroDTO> registrosDiarios) {
        this.registrosDiarios = registrosDiarios;
    }

    public Locale getLocale() {
        return locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    public ResourceBundle getBundle() {
        return bundle;
    }

    public void setBundle(ResourceBundle bundle) {
        this.bundle = bundle;
    }

    public List<HorarioDiaTrabajoDTO> getHorarioDias() {
        return horarioDias;
    }

    public void setHorarioDias(List<HorarioDiaTrabajoDTO> horarioDias) {
        this.horarioDias = horarioDias;
    }

    public List<DiaFestivoDTO> getDiasFestivos() {
        return diasFestivos;
    }

    public void setDiasFestivos(List<DiaFestivoDTO> diasFestivos) {
        this.diasFestivos = diasFestivos;
    }

    public List<VacacionesDTO> getVacaciones() {
        return vacaciones;
    }

    public void setVacaciones(List<VacacionesDTO> vacaciones) {
        this.vacaciones = vacaciones;
    }

    public String getHorarioNombre() {
        return getHorarioDescripcion();
    }
}
