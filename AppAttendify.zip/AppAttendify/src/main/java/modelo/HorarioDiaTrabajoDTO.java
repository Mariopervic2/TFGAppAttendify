package modelo;

import java.time.LocalTime;
import java.util.Objects;

public class HorarioDiaTrabajoDTO {
    private int idHorarioDiaTrabajo;
    private int idHorario;
    private int idDia;
    private LocalTime horaEntrada;
    private LocalTime horaSalida;
    private int tiempoDescanso;
    private String nombreDia;
    private boolean activo;

    public HorarioDiaTrabajoDTO() {
    }

    public int getIdHorarioDiaTrabajo() {
        return idHorarioDiaTrabajo;
    }

    public void setIdHorarioDiaTrabajo(int idHorarioDiaTrabajo) {
        this.idHorarioDiaTrabajo = idHorarioDiaTrabajo;
    }

    public int getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(int idHorario) {
        this.idHorario = idHorario;
    }

    public int getIdDia() {
        return idDia;
    }

    public void setIdDia(int idDia) {
        this.idDia = idDia;
    }

    public LocalTime getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(LocalTime horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(LocalTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public int getTiempoDescanso() {
        return tiempoDescanso;
    }

    public void setTiempoDescanso(int tiempoDescanso) {
        this.tiempoDescanso = tiempoDescanso;
    }

    public String getNombreDia() {
        return nombreDia;
    }

    public void setNombreDia(String nombreDia) {
        this.nombreDia = nombreDia;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HorarioDiaTrabajoDTO)) return false;
        HorarioDiaTrabajoDTO that = (HorarioDiaTrabajoDTO) o;
        return idHorarioDiaTrabajo == that.idHorarioDiaTrabajo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHorarioDiaTrabajo);
    }

    @Override
    public String toString() {
        return nombreDia + " [" + horaEntrada + "-" + horaSalida + ", descanso=" + tiempoDescanso + "min]";
    }
}