package modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HorarioDTO {
    private int idHorario;
    private String nombreHorario;
    private int horasMaxSemanales;
    private List<HorarioDiaTrabajoDTO> diasTrabajo;

    public HorarioDTO() {
        this.diasTrabajo = new ArrayList<>();
        this.horasMaxSemanales = 40;
    }

    public HorarioDTO(int idHorario, String nombreHorario, int horasMaxSemanales) {
        this.idHorario = idHorario;
        this.nombreHorario = nombreHorario;
        this.horasMaxSemanales = horasMaxSemanales;
        this.diasTrabajo = new ArrayList<>();
    }

    public int getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(int idHorario) {
        this.idHorario = idHorario;
    }

    public String getNombreHorario() {
        return nombreHorario;
    }

    public void setNombreHorario(String nombreHorario) {
        this.nombreHorario = nombreHorario;
    }

    public int getHorasMaxSemanales() {
        return horasMaxSemanales;
    }

    public void setHorasMaxSemanales(int horasMaxSemanales) {
        this.horasMaxSemanales = horasMaxSemanales;
    }

    public List<HorarioDiaTrabajoDTO> getDiasTrabajo() {
        return diasTrabajo;
    }

    public void setDiasTrabajo(List<HorarioDiaTrabajoDTO> diasTrabajo) {
        this.diasTrabajo = diasTrabajo;
    }

    public void agregarDiaTrabajo(HorarioDiaTrabajoDTO diaTrabajo) {
        this.diasTrabajo.add(diaTrabajo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HorarioDTO)) return false;
        HorarioDTO that = (HorarioDTO) o;
        return idHorario == that.idHorario;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHorario);
    }

    @Override
    public String toString() {
        return nombreHorario;
    }
}
