package modelo;

import java.time.LocalDate;

public class DiaFestivoDTO {
    private int idFestivo;
    private LocalDate fecha;
    private String nombre;

    public DiaFestivoDTO(int idFestivo, LocalDate fecha, String nombre) {
        this.idFestivo = idFestivo;
        this.fecha = fecha;
        this.nombre = nombre;
    }

    public DiaFestivoDTO() {
    }

    public int getIdFestivo() {
        return idFestivo;
    }

    public void setIdFestivo(int idFestivo) {
        this.idFestivo = idFestivo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Festivo: " + nombre + " (" + fecha + ")";
    }
}