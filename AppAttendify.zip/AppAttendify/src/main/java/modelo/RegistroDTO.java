package modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class RegistroDTO {
    private int idRegistro;
    private int idEmpleado;
    private LocalDate fecha;
    private LocalTime horaEntrada;
    private LocalTime horaSalida;
    private String estado;
    private String comentarios;
    private int minutosEsperados;
    private boolean correspondeTrabajar;
    private boolean festivo;

    public RegistroDTO() {
    }

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(LocalTime horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(LocalTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public int getMinutosEsperados() {
        return minutosEsperados;
    }

    public void setMinutosEsperados(int minutosEsperados) {
        this.minutosEsperados = minutosEsperados;
    }

    public boolean isCorrespondeTrabajar() {
        return correspondeTrabajar;
    }

    public void setCorrespondeTrabajar(boolean correspondeTrabajar) {
        this.correspondeTrabajar = correspondeTrabajar;
    }

    public boolean isFestivo() {
        return festivo;
    }

    public void setFestivo(boolean festivo) {
        this.festivo = festivo;
    }

    private boolean vacaciones;

    public boolean isVacaciones() {
        return vacaciones;
    }

    public void setVacaciones(boolean vacaciones) {
        this.vacaciones = vacaciones;
    }


}
