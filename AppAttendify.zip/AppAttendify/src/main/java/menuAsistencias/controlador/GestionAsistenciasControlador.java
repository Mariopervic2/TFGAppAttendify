package menuAsistencias.controlador;

import accesoDatos.RegistroDAO;
import accesoDatos.EmpleadoDAO;
import modelo.RegistroDTO;
import modelo.EmpleadoDTO;
import menuAsistencias.vista.GestionAsistenciasVista;
import varios.GestorIdioma;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class GestionAsistenciasControlador {
    private GestionAsistenciasVista vista;
    private RegistroDAO registroDAO;
    private EmpleadoDAO empleadoDAO;
    private JPanel contenedor;
    private JPanel panelAnterior;

    public GestionAsistenciasControlador(Connection conexion, JPanel contenedor, JPanel panelAnterior) {
        this.registroDAO = new RegistroDAO(conexion);
        this.empleadoDAO = new EmpleadoDAO(conexion);
        this.contenedor = contenedor;
        this.panelAnterior = panelAnterior;

        this.vista = new GestionAsistenciasVista();
        this.vista.setControlador(this);

        cargarRegistros();
    }

    public void mostrar() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        contenedor.add(vista, "menuAsistencias");
        cl.show(contenedor, "menuAsistencias");
    }

    public void volverMenuPrincipal() {
        CardLayout cl = (CardLayout) contenedor.getLayout();
        cl.show(contenedor, "principal");
    }

    public void cargarRegistros() {
        try {
            List<RegistroDTO> registros = registroDAO.obtenerTodosRegistros();
            vista.actualizarTablaRegistros(registros);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    "Error al cargar registros: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean crearRegistroManual(RegistroDTO registro) {
        try {
            if (registro.getHoraEntrada() != null && registro.getHoraSalida() != null
                    && registroDAO.haySolapamiento(
                    registro.getIdEmpleado(),
                    registro.getFecha(),
                    registro.getHoraEntrada(),
                    registro.getHoraSalida(),
                    null)) {
                JOptionPane.showMessageDialog(null,
                        GestorIdioma.getString("YA_ESA_HORA"),
                        GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
                return false;
            }
            boolean exito = registroDAO.crearRegistroManual(registro);
            if (exito) {
                cargarRegistros();
                JOptionPane.showMessageDialog(null,
                        GestorIdioma.getString("ASISTENCIA_REG"), GestorIdioma.getString("DIALOGO_TITULO_INFO"),
                        JOptionPane.INFORMATION_MESSAGE);
            }
            return exito;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    GestorIdioma.getString("ERROR_REG") + e.getMessage(),
                    GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean actualizarRegistro(RegistroDTO registro) {
        try {
            if (registro.getHoraEntrada() != null && registro.getHoraSalida() != null
                    && registroDAO.haySolapamiento(
                    registro.getIdEmpleado(),
                    registro.getFecha(),
                    registro.getHoraEntrada(),
                    registro.getHoraSalida(),
                    registro.getIdRegistro())) {
                JOptionPane.showMessageDialog(null,
                        GestorIdioma.getString("REG_YAESAHORA"),
                        GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
                return false;
            }
            boolean exito = registroDAO.actualizarRegistro(registro);
            if (exito) {
                cargarRegistros();
                JOptionPane.showMessageDialog(null,
                        "" +
                                GestorIdioma.getString("ASIS_EDITADA"), GestorIdioma.getString("DIALOGO_TITULO_INFO"),
                        JOptionPane.INFORMATION_MESSAGE);
            }
            return exito;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    GestorIdioma.getString("ERROR_ACT_REG") + e.getMessage(),
                    GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }


    public boolean eliminarRegistro(int idRegistro) {
        try {
            boolean exito = registroDAO.eliminarRegistro(idRegistro);
            if (exito) cargarRegistros();
            return exito;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString("ERROR_ELIM_REG") + e.getMessage(),
                    GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public List<EmpleadoDTO> obtenerEmpleados() {
        try {
            return empleadoDAO.obtenerTodosEmpleados();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista,
                    GestorIdioma.getString("ERROR_OBT_EMPLE") + e.getMessage(),
                    GestorIdioma.getString("DIALOGO_TITULO_ERROR"), JOptionPane.ERROR_MESSAGE);
            return new ArrayList<>();
        }
    }

}
