package menuAsistencias.controlador;

import accesoDatos.DiaFestivoDAO;
import accesoDatos.VacacionesDAO;
import accesoDatos.RegistroDAO;
import modelo.UsuarioDTO;
import menuAsistencias.vista.MenuAsistenciasVistaEmpleados;

import java.time.LocalDate;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MenuAsistenciasControladorEmpleados {
    private static final Map<Integer, MenuAsistenciasVistaEmpleados> ventanasAbiertas = new ConcurrentHashMap<>();

    private UsuarioDTO usuario;
    private DiaFestivoDAO diaFestivoDAO;
    private VacacionesDAO vacacionesDAO;
    private RegistroDAO registroDAO;

    public static boolean mostrarVentana(UsuarioDTO usuario) {
        if (ventanasAbiertas.containsKey(usuario.getIdEmpleado())) {
            MenuAsistenciasVistaEmpleados ventanaExistente = ventanasAbiertas.get(usuario.getIdEmpleado());
            ventanaExistente.toFront();
            ventanaExistente.requestFocus();
            return false;
        } else {
            new MenuAsistenciasControladorEmpleados(usuario);
            return true;
        }
    }


    public MenuAsistenciasControladorEmpleados(UsuarioDTO usuario) {
        this.usuario = usuario;
        this.diaFestivoDAO = new DiaFestivoDAO();
        this.vacacionesDAO = new VacacionesDAO();
        this.registroDAO = new RegistroDAO();

        MenuAsistenciasVistaEmpleados vista = new MenuAsistenciasVistaEmpleados(usuario, this);

        ventanasAbiertas.put(usuario.getIdEmpleado(), vista);

        vista.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                ventanasAbiertas.remove(usuario.getIdEmpleado());
            }
        });

        vista.setVisible(true);
    }

    public boolean menuAsistenciasVistaEmpleadosHayRegistroPendienteHoy() {
        LocalDate hoy = LocalDate.now();
        return registroDAO.existeRegistroPendiente(usuario.getIdEmpleado(), hoy);
    }

    public boolean esDiaFestivo() {
        LocalDate hoy = LocalDate.now();
        return diaFestivoDAO.esFechaFestiva(hoy);
    }

    public boolean esVacaciones() {
        LocalDate hoy = LocalDate.now();
        return vacacionesDAO.estaDeVacaciones(usuario.getIdEmpleado(), hoy);
    }

    public boolean menuAsistenciasVistaEmpleadosFicharEntrada() {
        LocalDate hoy = LocalDate.now();

        if (menuAsistenciasVistaEmpleadosHayRegistroPendienteHoy()) {
            return false;
        }

        return registroDAO.crearRegistroEntrada(usuario.getIdEmpleado(), hoy);
    }

    public boolean menuAsistenciasVistaEmpleadosFicharSalida() {
        LocalDate hoy = LocalDate.now();
        if (!menuAsistenciasVistaEmpleadosHayRegistroPendienteHoy()) {
            return false;
        }
        return registroDAO.completarRegistroSalida(usuario.getIdEmpleado(), hoy);
    }
}