package menuAsistencias.vista;

import modelo.UsuarioDTO;
import varios.GestorIdioma;
import menuAsistencias.controlador.MenuAsistenciasControladorEmpleados;

import javax.swing.*;
import java.awt.*;

public class MenuAsistenciasVistaEmpleados extends JFrame {

    private static final String KEY_TITLE               = "TITULO_ASISTENCIAS";
    private static final String KEY_BTN_CHECK_IN        = "FICHAR_ENTRADA";
    private static final String KEY_BTN_CHECK_OUT       = "FICHAR_SALIDA";
    private static final String KEY_MSG_IN_SUCCESS      = "ENTRADA_REGISTRADA";
    private static final String KEY_MSG_IN_ERROR        = "ERROR_FICHAR_ENTRADA";
    private static final String KEY_MSG_OUT_SUCCESS     = "SALIDA_REGISTRADA";
    private static final String KEY_MSG_OUT_ERROR       = "ERROR_FICHAR_SALIDA";
    private static final String KEY_DIALOG_ERROR_TITLE  = "ERROR";
    private static final String KEY_DIALOG_CONFIRM      = "CONFIRMAR";
    private static final String KEY_MSG_HOLIDAY_CONFIRM = "HOY_ES_FESTIVO_CONFIRMAR";
    private static final String KEY_MSG_VACATION_CONFIRM = "HOY_SON_TUS_VACACIONES_CONFIRMAR";

    private UsuarioDTO usuarioActual;
    private JButton btnFicharEntrada;
    private JButton btnFicharSalida;
    private MenuAsistenciasControladorEmpleados controlador;


    public MenuAsistenciasVistaEmpleados(UsuarioDTO usuario, MenuAsistenciasControladorEmpleados controlador) {
        this.usuarioActual = usuario;
        this.controlador = controlador;
        initComponents();
        actualizarEstadoBotones();
    }

    private void initComponents() {
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/IconoAttendify.png")).getImage());
        setTitle(GestorIdioma.getString(KEY_TITLE));
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(1, 2, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        btnFicharEntrada = new JButton(GestorIdioma.getString(KEY_BTN_CHECK_IN));
        btnFicharSalida  = new JButton(GestorIdioma.getString(KEY_BTN_CHECK_OUT));

        btnFicharEntrada.addActionListener(e -> procesarFicharEntrada());
        btnFicharSalida.addActionListener(e -> procesarFicharSalida());

        panel.add(btnFicharEntrada);
        panel.add(btnFicharSalida);
        add(panel);
    }

    private void procesarFicharEntrada() {
        boolean debeConfirmar = false;
        String mensajeConfirmacion = "";


        if (controlador.esDiaFestivo()) {
            debeConfirmar = true;
            mensajeConfirmacion = GestorIdioma.getString(KEY_MSG_HOLIDAY_CONFIRM);
        }

        else if (controlador.esVacaciones()) {
            debeConfirmar = true;
            mensajeConfirmacion = GestorIdioma.getString(KEY_MSG_VACATION_CONFIRM);
        }


        if (debeConfirmar) {
            int respuesta = JOptionPane.showConfirmDialog(
                    this,
                    mensajeConfirmacion,
                    GestorIdioma.getString(KEY_DIALOG_CONFIRM),
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );


            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
        }


        if (controlador.menuAsistenciasVistaEmpleadosFicharEntrada()) {
            JOptionPane.showMessageDialog(
                    this,
                    GestorIdioma.getString(KEY_MSG_IN_SUCCESS)
            );
            actualizarEstadoBotones();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    GestorIdioma.getString(KEY_MSG_IN_ERROR),
                    GestorIdioma.getString(KEY_DIALOG_ERROR_TITLE),
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    private void procesarFicharSalida() {
        if (controlador.menuAsistenciasVistaEmpleadosFicharSalida()) {
            JOptionPane.showMessageDialog(
                    this,
                    GestorIdioma.getString(KEY_MSG_OUT_SUCCESS)
            );
            actualizarEstadoBotones();
            dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    GestorIdioma.getString(KEY_MSG_OUT_ERROR),
                    GestorIdioma.getString(KEY_DIALOG_ERROR_TITLE),
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void actualizarEstadoBotones() {
        boolean hayPendiente = controlador
                .menuAsistenciasVistaEmpleadosHayRegistroPendienteHoy();
        btnFicharEntrada.setEnabled(!hayPendiente);
        btnFicharSalida.setEnabled(hayPendiente);
    }
}