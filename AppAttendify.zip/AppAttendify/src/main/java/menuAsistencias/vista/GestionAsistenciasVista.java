package menuAsistencias.vista;

import menuAsistencias.controlador.GestionAsistenciasControlador;
import modelo.RegistroDTO;
import modelo.EmpleadoDTO;
import varios.GestorIdioma;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class GestionAsistenciasVista extends JPanel {
    private static final String KEY_SEARCH_LABEL       = "GA_LABEL_SEARCH";
    private static final String KEY_MONTH_LABEL        = "GA_LABEL_MONTH";
    private static final String KEY_YEAR_LABEL         = "GA_LABEL_YEAR";
    private static final String[] KEY_COLS             = {
            "GA_COL_EMP", "GA_COL_DATE", "GA_COL_IN", "GA_COL_OUT",
            "GA_COL_STATUS", "GA_COL_EDIT", "GA_COL_DELETE"
    };
    private static final Map<String,String> STATUS_KEYS = Map.of(
            "Pendiente", "FR_STATUS_PENDING",
            "Completado", "FR_STATUS_COMPLETED",
            "Falta"     , "FR_STATUS_ABSENT"
    );

    private static final String KEY_BTN_REGISTER       = "GA_BTN_REGISTER";
    private static final String KEY_BTN_BACK           = "GA_BTN_BACK";
    private static final String KEY_CONFIRM_DELETE     = "GA_CONFIRM_DELETE";
    private static final String KEY_DIALOG_ERROR       = "DIALOGO_TITULO_ERROR";
    private static final String KEY_DIALOG_CONFIRM       = "DIALOGO_TITULO_CONFIRM";

    private GestionAsistenciasControlador controlador;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField txtBuscar;
    private JSpinner spinnerMes, spinnerAnio;
    private JButton btnRegistrarManual, btnVolver;

    public GestionAsistenciasVista() {
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        initComponents();
    }

    private void initComponents() {
        JPanel panelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT,10,5));
        panelFiltros.add(new JLabel(GestorIdioma.getString(KEY_SEARCH_LABEL)));
        txtBuscar = new JTextField(15);
        panelFiltros.add(txtBuscar);
        panelFiltros.add(new JLabel(GestorIdioma.getString(KEY_MONTH_LABEL)));
        spinnerMes = new JSpinner(new SpinnerNumberModel(
                LocalDate.now().getMonthValue(),1,12,1));
        panelFiltros.add(spinnerMes);
        panelFiltros.add(new JLabel(GestorIdioma.getString(KEY_YEAR_LABEL)));
        spinnerAnio = new JSpinner(new SpinnerNumberModel(
                LocalDate.now().getYear(),2000,2100,1));
        panelFiltros.add(spinnerAnio);
        add(panelFiltros, BorderLayout.NORTH);

        String[] cols = new String[KEY_COLS.length];
        for (int i=0;i<KEY_COLS.length;i++) {
            cols[i] = GestorIdioma.getString(KEY_COLS[i]);
        }
        modeloTabla = new DefaultTableModel(cols,0) {
            @Override public boolean isCellEditable(int r,int c){
                return c==5||c==6;
            }
        };
        tablaRegistros = new JTable(modeloTabla);
        int[] widths = {150,80,60,60,80,70,70};
        for(int i=0;i<widths.length;i++){
            tablaRegistros.getColumnModel().getColumn(i)
                    .setPreferredWidth(widths[i]);
        }
        JTableHeader header = tablaRegistros.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD));
        header.setBackground(new Color(220,220,220));

        sorter = new TableRowSorter<>(modeloTabla);
        tablaRegistros.setRowSorter(sorter);

        JScrollPane scroll = new JScrollPane(tablaRegistros);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,5));
        btnRegistrarManual = new JButton(GestorIdioma.getString(KEY_BTN_REGISTER));
        btnVolver         = new JButton(GestorIdioma.getString(KEY_BTN_BACK));
        panelBotones.add(btnRegistrarManual);
        panelBotones.add(btnVolver);
        add(panelBotones, BorderLayout.SOUTH);

        txtBuscar.getDocument().addDocumentListener(new DocumentListener(){
            public void insertUpdate(DocumentEvent e){ filtrar(); }
            public void removeUpdate(DocumentEvent e){ filtrar(); }
            public void changedUpdate(DocumentEvent e){ filtrar(); }
        });
        spinnerMes.addChangeListener(e->filtrar());
        spinnerAnio.addChangeListener(e->filtrar());
    }

    public void setControlador(GestionAsistenciasControlador controlador) {
        this.controlador = controlador;
        btnRegistrarManual.addActionListener(e->mostrarFormularioRegistro(null));
        btnVolver.addActionListener(e->controlador.volverMenuPrincipal());

        tablaRegistros.getColumnModel().getColumn(5)
                .setCellRenderer(new ButtonRenderer(GestorIdioma.getString(KEY_COLS[5])));
        tablaRegistros.getColumnModel().getColumn(5)
                .setCellEditor(new ButtonEditor(GestorIdioma.getString(KEY_COLS[5])));
        tablaRegistros.getColumnModel().getColumn(6)
                .setCellRenderer(new ButtonRenderer(GestorIdioma.getString(KEY_COLS[6])));
        tablaRegistros.getColumnModel().getColumn(6)
                .setCellEditor(new ButtonEditor(GestorIdioma.getString(KEY_COLS[6])));
    }

    public void actualizarTablaRegistros(List<RegistroDTO> regs) {
        modeloTabla.setRowCount(0);
        DateTimeFormatter dfDate = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter dfTime = DateTimeFormatter.ofPattern("HH:mm");
        for (RegistroDTO r : regs) {
            String nombre = controlador.obtenerEmpleados().stream()
                    .filter(e -> e.getIdEmpleado() == r.getIdEmpleado())
                    .map(EmpleadoDTO::getNombreCompleto)
                    .findFirst().orElse("");

            String clave = STATUS_KEYS.getOrDefault(r.getEstado(), null);
            String estadoMostrar = clave != null
                    ? GestorIdioma.getString(clave)
                    : r.getEstado();

            modeloTabla.addRow(new Object[]{
                    nombre,
                    r.getFecha().format(dfDate),
                    r.getHoraEntrada() != null ? r.getHoraEntrada().format(dfTime) : "",
                    r.getHoraSalida()  != null ? r.getHoraSalida().format(dfTime)  : "",
                    estadoMostrar,
                    r,
                    r
            });
        }
        filtrar();
    }


    private void filtrar() {
        RowFilter<DefaultTableModel,Object> rf = new RowFilter<DefaultTableModel,Object>() {
            public boolean include(Entry<? extends DefaultTableModel,?> e) {
                String text = txtBuscar.getText().trim().toLowerCase();
                String name = String.valueOf(e.getValue(0)).toLowerCase();
                if (!name.contains(text)) return false;
                RegistroDTO r = (RegistroDTO)e.getValue(5);
                int m = (Integer)spinnerMes.getValue();
                int y = (Integer)spinnerAnio.getValue();
                LocalDate d = r.getFecha();
                return d.getMonthValue()==m && d.getYear()==y;
            }
        };
        sorter.setRowFilter(rf);
    }

    private void mostrarFormularioRegistro(RegistroDTO registro) {
        JDialog dialog = new JDialog(
                (Frame)SwingUtilities.getWindowAncestor(this), true);
        FormularioRegistroPanel form = new FormularioRegistroPanel(
                controlador, registro, dialog);
        dialog.setContentPane(form);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String text){ super(text); }
        @Override public Component getTableCellRendererComponent(JTable t,Object v,
                                                                 boolean s, boolean f,int r,int c){
            setText(getText()); return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private final JButton button;
        private RegistroDTO current;
        private boolean isPushed;
        private int row, col;

        public ButtonEditor(String type) {
            super(new JCheckBox());
            button = new JButton(type);
            button.setOpaque(true);
            button.addActionListener(e -> {
                isPushed = true;
                fireEditingStopped();
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable t, Object v,
                                                     boolean s, int r, int c) {
            isPushed = false;
            row = r;
            col = c;
            current = (RegistroDTO)v;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                SwingUtilities.invokeLater(() -> {
                    if (button.getText().equals(GestorIdioma.getString(KEY_COLS[5]))) {
                        mostrarFormularioRegistro(current);
                    } else {
                        int opt = JOptionPane.showConfirmDialog(
                                GestionAsistenciasVista.this,
                                GestorIdioma.getString(KEY_CONFIRM_DELETE),
                                GestorIdioma.getString(KEY_DIALOG_CONFIRM),
                                JOptionPane.YES_NO_OPTION);
                        if (opt == JOptionPane.YES_OPTION) {
                            controlador.eliminarRegistro(current.getIdRegistro());
                        }
                    }
                });
            }
            isPushed = false;
            return current;
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped() {
            try {
                super.fireEditingStopped();
            } catch (ArrayIndexOutOfBoundsException ex) {
                cancelCellEditing();
            }
        }
    }

    class FormularioRegistroPanel extends JPanel {
        private static final String KEY_LABEL_EMP      = "FR_LABEL_EMP";
        private static final String KEY_LABEL_DATE     = "FR_LABEL_DATE";
        private static final String KEY_LABEL_IN       = "FR_LABEL_IN";
        private static final String KEY_LABEL_OUT      = "FR_LABEL_OUT";
        private static final String KEY_LABEL_STATUS   = "FR_LABEL_STATUS";
        private static final String KEY_LABEL_COMMENTS = "FR_LABEL_COMMENTS";
        private static final String KEY_BTN_SAVE       = "FR_BTN_SAVE";
        private static final String KEY_BTN_CANCEL     = "FR_BTN_CANCEL";
        private static final String KEY_ERR_TIME       = "FR_ERR_TIME";

        private final GestionAsistenciasControlador ctrl;
        private final RegistroDTO registro;
        private final JDialog dialog;
        private JComboBox<EmpleadoDTO> cmbEmpleado;
        private JSpinner spinnerFecha, spinnerEntrada, spinnerSalida;
        private JComboBox<EstadoItem> cmbEstado;
        private JTextField txtComentarios;
        private JButton btnGuardar, btnCancelar;
        private JCheckBox chkNocturno;

        public FormularioRegistroPanel(GestionAsistenciasControlador ctrl,
                                       RegistroDTO registro, JDialog dialog) {
            this.ctrl     = ctrl;
            this.registro = registro!=null?registro:new RegistroDTO();
            this.dialog   = dialog;
            setLayout(new BorderLayout(10,10));
            setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
            initForm();
            loadData();
        }

        private class EstadoItem {
            private final String valorEsp;
            private final String keyLabel;

            public EstadoItem(String valorEsp, String keyLabel) {
                this.valorEsp = valorEsp;
                this.keyLabel = keyLabel;
            }
            @Override public String toString() {
                return GestorIdioma.getString(keyLabel);
            }
            public String getValorEsp() {
                return valorEsp;
            }
        }


        private void initForm() {
            JPanel p = new JPanel(new GridLayout(0,2,5,5));
            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_EMP)));
            cmbEmpleado = new JComboBox<>();
            for(EmpleadoDTO e: ctrl.obtenerEmpleados()) cmbEmpleado.addItem(e);
            p.add(cmbEmpleado);

            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_DATE)));
            spinnerFecha = new JSpinner(new SpinnerDateModel());
            spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "yyyy-MM-dd"));
            p.add(spinnerFecha);

            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_IN)));
            spinnerEntrada = new JSpinner(new SpinnerDateModel());
            spinnerEntrada.setEditor(new JSpinner.DateEditor(spinnerEntrada, "HH:mm"));
            p.add(spinnerEntrada);

            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_OUT)));
            spinnerSalida = new JSpinner(new SpinnerDateModel());
            spinnerSalida.setEditor(new JSpinner.DateEditor(spinnerSalida, "HH:mm"));
            p.add(spinnerSalida);

            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_STATUS)));
            cmbEstado = new JComboBox<>(new EstadoItem[]{
                    new EstadoItem("Pendiente", "FR_STATUS_PENDING"),
                    new EstadoItem("Completado", "FR_STATUS_COMPLETED"),
                    new EstadoItem("Falta"     , "FR_STATUS_ABSENT")
            });
            p.add(cmbEstado);

            p.add(new JLabel(GestorIdioma.getString(KEY_LABEL_COMMENTS)));
            txtComentarios = new JTextField(20);
            p.add(txtComentarios);

            p.add(new JLabel(GestorIdioma.getString("TURNO_NOCTURNO")));
            chkNocturno = new JCheckBox(GestorIdioma.getString("ES_TURNO_NOCTURNO"));
            p.add(chkNocturno);

            add(p,BorderLayout.CENTER);

            JPanel pb = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            btnGuardar = new JButton(GestorIdioma.getString(KEY_BTN_SAVE));
            btnCancelar= new JButton(GestorIdioma.getString(KEY_BTN_CANCEL));
            pb.add(btnGuardar);
            pb.add(btnCancelar);
            add(pb,BorderLayout.SOUTH);

            btnGuardar.addActionListener(e->guardar());
            btnCancelar.addActionListener(e->dialog.dispose());
        }

        private void loadData() {
            if (registro.getIdRegistro()!=0) {
                for(int i=0;i<cmbEmpleado.getItemCount();i++){
                    if(cmbEmpleado.getItemAt(i).getIdEmpleado()
                            ==registro.getIdEmpleado()){
                        cmbEmpleado.setSelectedIndex(i); break;
                    }
                }
                spinnerFecha.setValue(java.sql.Date.valueOf(registro.getFecha()));
                if(registro.getHoraEntrada()!=null)
                    spinnerEntrada.setValue(java.sql.Time.valueOf(registro.getHoraEntrada()));
                if(registro.getHoraSalida()!=null)
                    spinnerSalida.setValue(java.sql.Time.valueOf(registro.getHoraSalida()));
                String est = registro.getEstado();
                for (int i = 0; i < cmbEstado.getItemCount(); i++) {
                    EstadoItem it = cmbEstado.getItemAt(i);
                    if (it.getValorEsp().equals(est)) {
                        cmbEstado.setSelectedIndex(i);
                        break;
                    }
                }

                txtComentarios.setText(registro.getComentarios());
            }
        }

        private void guardar() {
            EmpleadoDTO e = (EmpleadoDTO)cmbEmpleado.getSelectedItem();
            registro.setIdEmpleado(e.getIdEmpleado());
            registro.setFecha(
                    new java.sql.Date(
                            ((java.util.Date)spinnerFecha.getValue()).getTime())
                            .toLocalDate());
            registro.setHoraEntrada(
                    new java.sql.Time(
                            ((java.util.Date)spinnerEntrada.getValue()).getTime())
                            .toLocalTime());
            registro.setHoraSalida(
                    new java.sql.Time(
                            ((java.util.Date)spinnerSalida.getValue()).getTime())
                            .toLocalTime());

            EstadoItem sel = (EstadoItem)cmbEstado.getSelectedItem();
            registro.setEstado(sel.getValorEsp());
            registro.setComentarios(txtComentarios.getText().trim());

            if (registro.getHoraSalida().isBefore(registro.getHoraEntrada())) {
                if (!chkNocturno.isSelected()) {
                    JOptionPane.showMessageDialog(this,
                            GestorIdioma.getString("VERIFICA_CAS_NOCTURNO"),
                            GestorIdioma.getString(KEY_DIALOG_ERROR),
                            JOptionPane.ERROR_MESSAGE);
                    return;
                } else {
                    registro.setHoraSalida(registro.getHoraSalida().plusHours(24));
                }
            }

            boolean ok = registro.getIdRegistro()==0
                    ? ctrl.crearRegistroManual(registro)
                    : ctrl.actualizarRegistro(registro);
            if (ok) dialog.dispose();
        }
    }

}
