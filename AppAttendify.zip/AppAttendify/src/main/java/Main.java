
import javax.swing.UIManager;

import varios.PantallaCarga;

public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Error al cargar el look and feel: " + e.getMessage());
        }

        java.awt.EventQueue.invokeLater(() -> {
            new PantallaCarga().setVisible(true);
        });
    }
}